-- Provio Internal Audit & Governance — Supabase PostgreSQL Schema
-- Run this script in the Supabase SQL Editor to provision tables for multi-universe,
-- auditable entities, engagements, controls testing (DEA/OET), workpapers, and issues.

-- 1. Universes
CREATE TABLE IF NOT EXISTS audit_universes (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  lead_sponsor TEXT,
  coverage_pct NUMERIC DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Auditable Entities (Multi-Entity Universe)
CREATE TABLE IF NOT EXISTS audit_entities (
  id TEXT PRIMARY KEY,
  universe_id TEXT REFERENCES audit_universes(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  business_unit TEXT NOT NULL,
  inherent_risk TEXT NOT NULL CHECK (inherent_risk IN ('critical', 'high', 'medium', 'low')),
  regulatory_tier TEXT NOT NULL,
  frequency_months INTEGER DEFAULT 12,
  last_audited_date DATE,
  next_audit_target DATE,
  lead_owner TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'scheduled',
  scope_notes TEXT,
  sira_score JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Audit Engagements (Audit Files)
CREATE TABLE IF NOT EXISTS audit_engagements (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  dept TEXT NOT NULL,
  entity_id TEXT REFERENCES audit_entities(id),
  universe_id TEXT REFERENCES audit_universes(id),
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('in_progress', 'overdue', 'upcoming', 'concluded_this_year', 'concluded_prior')),
  stage TEXT NOT NULL CHECK (stage IN ('planning', 'scoping', 'fieldwork', 'review', 'reporting', 'mgmt_comments', 'signoff')),
  lead_auditor_id TEXT NOT NULL,
  lead_auditor_name TEXT NOT NULL,
  steps JSONB DEFAULT '{"fieldwork": "not_started", "review": "not_started", "signoff": "not_started"}'::jsonb,
  scope_summary TEXT,
  sample_size INTEGER DEFAULT 60,
  exceptions_count INTEGER DEFAULT 0,
  rating TEXT CHECK (rating IN ('Satisfactory', 'Needs Improvement', 'Unsatisfactory')),
  
  -- Controls Testing Metrics (DEA & OET)
  controls_total INTEGER DEFAULT 0,
  controls_tested INTEGER DEFAULT 0,
  dea JSONB DEFAULT '{"status": "not_started", "effective": 0, "ineffective": 0}'::jsonb,
  oet JSONB DEFAULT '{"status": "not_started", "effective": 0, "ineffective": 0}'::jsonb,
  
  -- Report Issuance Lifecycle
  report_issued BOOLEAN DEFAULT FALSE,
  report_issued_date DATE,
  report_summary TEXT,
  report_author TEXT,
  report_cae_signoff TEXT,
  executive_opinion TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Key Controls & Testing Matrices
CREATE TABLE IF NOT EXISTS audit_controls (
  id TEXT PRIMARY KEY,
  audit_id TEXT REFERENCES audit_engagements(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  name TEXT NOT NULL,
  objective TEXT NOT NULL,
  control_type TEXT CHECK (control_type IN ('Preventive', 'Detective', 'Corrective')),
  frequency TEXT,
  owner TEXT,
  dea_status TEXT DEFAULT 'Pending Walkthrough',
  dea_notes TEXT,
  oet_status TEXT DEFAULT 'Not Started',
  sample_size INTEGER DEFAULT 0,
  sample_exceptions INTEGER DEFAULT 0,
  oet_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Working Papers
CREATE TABLE IF NOT EXISTS audit_workpapers (
  id TEXT PRIMARY KEY,
  audit_id TEXT REFERENCES audit_engagements(id) ON DELETE CASCADE,
  ref TEXT NOT NULL,
  name TEXT NOT NULL,
  lead TEXT NOT NULL,
  status TEXT DEFAULT 'Draft' CHECK (status IN ('Draft', 'In Review', 'Reviewed', 'Signed off')),
  tested_sample_count INTEGER DEFAULT 0,
  exceptions_count INTEGER DEFAULT 0,
  signoff_lead TEXT,
  signoff_date DATE,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Observations & Corrective Action Plans (CAP)
CREATE TABLE IF NOT EXISTS audit_observations (
  id TEXT PRIMARY KEY,
  audit_id TEXT REFERENCES audit_engagements(id),
  title TEXT NOT NULL,
  dept TEXT NOT NULL,
  owner TEXT,
  severity TEXT NOT NULL CHECK (severity IN ('critical', 'high', 'medium', 'low')),
  approval TEXT NOT NULL DEFAULT 'Pending review',
  report TEXT NOT NULL,
  closure_date DATE,
  overdue BOOLEAN DEFAULT FALSE,
  due_date DATE NOT NULL,
  rectification_text TEXT,
  root_cause TEXT,
  impact TEXT,
  report_issued BOOLEAN DEFAULT FALSE, -- Promoted to official issues register only upon report issuance
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. Review Comments & Notes
CREATE TABLE IF NOT EXISTS audit_review_comments (
  id BIGSERIAL PRIMARY KEY,
  doc_id TEXT NOT NULL,
  doc_title TEXT NOT NULL,
  author TEXT NOT NULL,
  role TEXT NOT NULL,
  comment TEXT NOT NULL,
  status TEXT DEFAULT 'open' CHECK (status IN ('open', 'resolved')),
  initials TEXT,
  replies JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. Visual Methodology Logic Nodes
CREATE TABLE IF NOT EXISTS methodology_logic_nodes (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT,
  parameters JSONB,
  pos_x INTEGER,
  pos_y INTEGER,
  connected_to JSONB,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security (RLS)
ALTER TABLE audit_universes ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_entities ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_engagements ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_controls ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_workpapers ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_observations ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_review_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE methodology_logic_nodes ENABLE ROW LEVEL SECURITY;

-- Allow authenticated and anon read/write for demo development (restrict in production)
CREATE POLICY "Allow public read audit_universes" ON audit_universes FOR ALL USING (true);
CREATE POLICY "Allow public read audit_entities" ON audit_entities FOR ALL USING (true);
CREATE POLICY "Allow public read audit_engagements" ON audit_engagements FOR ALL USING (true);
CREATE POLICY "Allow public read audit_controls" ON audit_controls FOR ALL USING (true);
CREATE POLICY "Allow public read audit_workpapers" ON audit_workpapers FOR ALL USING (true);
CREATE POLICY "Allow public read audit_observations" ON audit_observations FOR ALL USING (true);
CREATE POLICY "Allow public read audit_review_comments" ON audit_review_comments FOR ALL USING (true);
CREATE POLICY "Allow public read methodology_logic_nodes" ON methodology_logic_nodes FOR ALL USING (true);
