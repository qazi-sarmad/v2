import { createClient, SupabaseClient } from '@supabase/supabase-js';

/**
 * Validates whether a given string is a valid HTTP or HTTPS URL.
 * Safely guards against non-URL strings, bash commands, empty values, and malformed strings.
 */
export function isValidHttpUrl(urlString?: string | null): boolean {
  if (!urlString || typeof urlString !== 'string') return false;
  const trimmed = urlString.trim().replace(/^['"]|['"]$/g, '');
  if (!trimmed.startsWith('http://') && !trimmed.startsWith('https://')) {
    return false;
  }
  if (trimmed.includes(' ') || trimmed.includes('\n') || trimmed.includes('\r')) {
    return false;
  }
  if (trimmed.includes('YOUR_') || trimmed.includes('<') || trimmed.includes('openssl')) {
    return false;
  }
  try {
    const parsed = new URL(trimmed);
    return (parsed.protocol === 'http:' || parsed.protocol === 'https:') && Boolean(parsed.hostname);
  } catch {
    return false;
  }
}

/**
 * Validates whether a key looks like a plausible Supabase key.
 */
export function isValidSupabaseKey(keyString?: string | null): boolean {
  if (!keyString || typeof keyString !== 'string') return false;
  const trimmed = keyString.trim().replace(/^['"]|['"]$/g, '');
  if (trimmed.length < 20) return false;
  if (trimmed.includes('YOUR_') || trimmed.includes('<') || trimmed.includes('openssl')) {
    return false;
  }
  return true;
}

// Retrieve custom credentials from localStorage if available
function getStoredCredentials(): { url: string; key: string } {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const url = localStorage.getItem('provio_supabase_url') || '';
      const key = localStorage.getItem('provio_supabase_key') || '';
      return { url, key };
    }
  } catch {
    // localStorage might be unavailable
  }
  return { url: '', key: '' };
}

// Default project credentials directly configured per enterprise specification
export const PROVIO_DEFAULT_SUPABASE_URL = 'https://pjnnydcfxjstachetvnz.supabase.co';
export const PROVIO_DEFAULT_SUPABASE_KEY = 'sb_publishable_80ziA7PlS27zkAwl5TqJeQ_21ffFfop';

// Resolve active URL and Key (prefers stored, then env if valid, then enterprise default)
const stored = getStoredCredentials();
const rawEnvUrl = (import.meta.env.VITE_SUPABASE_URL || '').trim().replace(/^['"]|['"]$/g, '');
const rawEnvKey = (import.meta.env.VITE_SUPABASE_ANON_KEY || '').trim().replace(/^['"]|['"]$/g, '');

let resolvedUrl = PROVIO_DEFAULT_SUPABASE_URL;
let resolvedKey = PROVIO_DEFAULT_SUPABASE_KEY;
let resolvedSource: 'default' | 'env' | 'storage' = 'default';

if (isValidHttpUrl(stored.url) && isValidSupabaseKey(stored.key)) {
  resolvedUrl = stored.url;
  resolvedKey = stored.key;
  resolvedSource = 'storage';
} else if (isValidHttpUrl(rawEnvUrl) && isValidSupabaseKey(rawEnvKey)) {
  resolvedUrl = rawEnvUrl;
  resolvedKey = rawEnvKey;
  resolvedSource = 'env';
}

const activeUrl = resolvedUrl;
const activeKey = resolvedKey;

let clientInstance: SupabaseClient | null = null;
let clientError: string | null = null;

if (isValidHttpUrl(activeUrl) && isValidSupabaseKey(activeKey)) {
  try {
    clientInstance = createClient(activeUrl, activeKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    });
  } catch (err: any) {
    clientError = err?.message || 'Failed to initialize Supabase client';
    clientInstance = null;
  }
} else {
  clientError = 'Supabase credentials missing or invalid.';
}

export const supabase: SupabaseClient | null = clientInstance;
export const isSupabaseConfigured = Boolean(clientInstance && !clientError);
export const supabaseConfigError: string | null = clientError;

export interface SupabaseConfigStatus {
  isConfigured: boolean;
  url: string;
  hasAnonKey: boolean;
  error: string | null;
  source: 'default' | 'env' | 'storage' | 'none';
}

export function getSupabaseStatus(): SupabaseConfigStatus {
  return {
    isConfigured: isSupabaseConfigured,
    url: activeUrl,
    hasAnonKey: Boolean(activeKey && isValidSupabaseKey(activeKey)),
    error: clientError,
    source: resolvedSource,
  };
}

/**
 * Saves user credentials directly in browser storage and reloads connection safely.
 */
export function saveCustomSupabaseConfig(url: string, key: string): { success: boolean; message: string } {
  if (!isValidHttpUrl(url)) {
    return {
      success: false,
      message: 'Invalid URL. Must start with https:// (e.g. https://your-ref.supabase.co).',
    };
  }
  if (!isValidSupabaseKey(key)) {
    return {
      success: false,
      message: 'Invalid Anon Key. Please paste the public anon/client_api_key from Supabase.',
    };
  }

  try {
    localStorage.setItem('provio_supabase_url', url.trim());
    localStorage.setItem('provio_supabase_key', key.trim());
    return {
      success: true,
      message: 'Configuration saved! Reloading client...',
    };
  } catch (err: any) {
    return {
      success: false,
      message: err?.message || 'Failed to save to localStorage',
    };
  }
}

export function clearCustomSupabaseConfig(): void {
  try {
    localStorage.removeItem('provio_supabase_url');
    localStorage.removeItem('provio_supabase_key');
  } catch {
    // Ignore error
  }
}

export async function testSupabaseConnection(): Promise<{ success: boolean; message: string }> {
  if (!supabase) {
    return {
      success: false,
      message: clientError || 'Supabase is not configured. Provide VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY.',
    };
  }

  try {
    const { error } = await supabase.from('audit_universes').select('id').limit(1);
    if (error) {
      // 42P01 = PostgreSQL relation does not exist yet
      if (error.code === '42P01') {
        return {
          success: true,
          message: 'Connection successful! (Tables not yet created; run the SQL schema in your Supabase SQL Editor).',
        };
      }
      return {
        success: false,
        message: `Supabase error (${error.code}): ${error.message}`,
      };
    }
    return {
      success: true,
      message: 'Successfully connected and verified Supabase database!',
    };
  } catch (err: any) {
    return {
      success: false,
      message: err?.message || 'Failed to connect to Supabase endpoint.',
    };
  }
}
