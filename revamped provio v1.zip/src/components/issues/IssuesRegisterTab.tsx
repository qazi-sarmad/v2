import React, { useState, useMemo } from 'react';
import { useTheme, FONTS, HOVER_EASE, HOVER_DUR } from '../../context/ThemeContext';
import { useApp } from '../../context/AppContext';
import { Icon } from '../common/Icons';
import { Observation } from '../../types';

export function IssuesRegisterTab() {
  const { t } = useTheme();
  const { departments, setSelectedObservation, setSelectedAuditForModal, audits, showToast } = useApp();

  const [registerScope, setRegisterScope] = useState<'issued' | 'drafts'>('issued');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [search, setSearch] = useState('');

  const allObservations = useMemo(() => departments.flatMap((d) => d.observations), [departments]);

  const scopedObservations = useMemo(() => {
    return allObservations.filter((obs) => {
      if (registerScope === 'issued') {
        return obs.reportIssued !== false && !obs.isDraft;
      } else {
        return obs.reportIssued === false || obs.isDraft;
      }
    });
  }, [allObservations, registerScope]);

  const filtered = useMemo(() => {
    return scopedObservations.filter((obs) => {
      if (severityFilter !== 'all' && obs.severity !== severityFilter) return false;
      if (statusFilter === 'overdue' && !obs.overdue) return false;
      if (statusFilter === 'approved' && obs.approval !== 'Approved') return false;
      if (statusFilter === 'pending' && obs.approval === 'Approved') return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        return (
          obs.title.toLowerCase().includes(q) ||
          (obs.owner && obs.owner.toLowerCase().includes(q)) ||
          (obs.dept && obs.dept.toLowerCase().includes(q)) ||
          obs.report.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [scopedObservations, severityFilter, statusFilter, search]);

  return (
    <div style={{ padding: '32px 48px', maxWidth: 1360, margin: '0 auto' }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 24, flexWrap: 'wrap', gap: 16 }}>
        <div>
          <div style={{ fontFamily: FONTS.serif, fontSize: 26, fontWeight: 600, marginBottom: 4 }}>
            Issues & Corrective Action Plan (CAP) Register
          </div>
          <p style={{ color: t.textSecondary, fontSize: 13.5 }}>
            Consolidated repository of audit findings, root causes, management commitments, and formal closure sign-offs.
          </p>
        </div>

        <button
          onClick={() => showToast('Exported consolidated CAP register to spreadsheet')}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 6,
            padding: '8px 14px',
            borderRadius: 9,
            border: `1px solid ${t.hairlineStrong}`,
            background: t.card,
            color: t.textPrimary,
            fontSize: 12.5,
            fontWeight: 600,
            cursor: 'pointer',
          }}
        >
          Export CAP Ledger
        </button>
      </div>

      {/* Register View Selector & Governance Law 1 Note */}
      <div className="mb-5 flex flex-col md:flex-row md:items-center justify-between gap-4 p-3 rounded-xl bg-[#141B26] border border-slate-800">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setRegisterScope('issued')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              registerScope === 'issued'
                ? 'bg-teal-500 text-slate-950 shadow-md shadow-teal-500/20'
                : 'text-slate-400 hover:text-white bg-slate-800/60'
            }`}
          >
            Formal Board Issues Register ({allObservations.filter((o) => o.reportIssued !== false && !o.isDraft).length})
          </button>
          <button
            onClick={() => setRegisterScope('drafts')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              registerScope === 'drafts'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white bg-slate-800/60'
            }`}
          >
            Fieldwork Draft Findings ({allObservations.filter((o) => o.reportIssued === false || o.isDraft).length})
          </button>
        </div>
        <div className="text-[11px] text-slate-400">
          <span className="text-teal-400 font-semibold">Governance Rule:</span> Findings remain in draft within working papers and only populate the Board Issues Register once the audit report is finalized and issued.
        </div>
      </div>

      {/* Filter and search bar */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 14,
          padding: '10px 18px',
          borderRadius: 12,
          background: t.card,
          border: `1px solid ${t.hairline}`,
          marginBottom: 20,
          flexWrap: 'wrap',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, flex: 1, minWidth: 200 }}>
          {Icon.search(t.textSecondary)}
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search findings, owners, audits..."
            style={{
              width: '100%',
              background: 'none',
              border: 'none',
              outline: 'none',
              color: t.textPrimary,
              fontSize: 13,
              fontFamily: FONTS.sans,
            }}
          />
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: 11.5, color: t.textSecondary }}>Severity:</span>
          {(['all', 'critical', 'high', 'medium'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setSeverityFilter(s)}
              style={{
                padding: '4px 10px',
                borderRadius: 6,
                border: 'none',
                background: severityFilter === s ? t.cardSunken : 'transparent',
                color: severityFilter === s ? t.textPrimary : t.textSecondary,
                fontSize: 11.5,
                fontWeight: severityFilter === s ? 600 : 400,
                cursor: 'pointer',
                textTransform: 'capitalize',
              }}
            >
              {s}
            </button>
          ))}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: 11.5, color: t.textSecondary }}>Status:</span>
          {(['all', 'overdue', 'pending', 'approved'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              style={{
                padding: '4px 10px',
                borderRadius: 6,
                border: 'none',
                background: statusFilter === st ? t.cardSunken : 'transparent',
                color: statusFilter === st ? t.textPrimary : t.textSecondary,
                fontSize: 11.5,
                fontWeight: statusFilter === st ? 600 : 400,
                cursor: 'pointer',
                textTransform: 'capitalize',
              }}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div
        style={{
          background: t.card,
          border: `1px solid ${t.hairline}`,
          borderRadius: 14,
          overflow: 'hidden',
          boxShadow: '0 2px 10px rgba(0,0,0,0.04)',
        }}
      >
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '100px 2.2fr 1.2fr 1.2fr 140px 120px',
            padding: '12px 18px',
            background: t.cardSunken,
            borderBottom: `1px solid ${t.hairline}`,
            fontSize: 11,
            fontWeight: 700,
            color: t.textSecondary,
            letterSpacing: 0.3,
            textTransform: 'uppercase',
          }}
        >
          <div>Severity</div>
          <div>Observation & Finding Title</div>
          <div>Department</div>
          <div>Action Owner</div>
          <div>Target Due Date</div>
          <div>Status</div>
        </div>

        <div>
          {filtered.map((obs) => {
            const isCrit = obs.severity === 'critical';
            const isHigh = obs.severity === 'high';
            const col = isCrit ? t.cinnabar : isHigh ? (t.mode === 'dark' ? '#E59866' : '#C6521E') : t.textSecondary;

            return (
              <div
                key={obs.id}
                onClick={() => setSelectedObservation(obs)}
                style={{
                  display: 'grid',
                  gridTemplateColumns: '100px 2.2fr 1.2fr 1.2fr 140px 120px',
                  alignItems: 'center',
                  padding: '14px 18px',
                  borderBottom: `1px solid ${t.hairline}`,
                  cursor: 'pointer',
                  transition: `background ${HOVER_DUR} ${HOVER_EASE}`,
                }}
                onMouseEnter={(e) => (e.currentTarget.style.background = t.cardSunken)}
                onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}
              >
                <div>
                  <span
                    style={{
                      fontSize: 10,
                      fontWeight: 700,
                      color: col,
                      padding: '2px 7px',
                      borderRadius: 4,
                      background: `${col}15`,
                      border: `1px solid ${col}35`,
                      textTransform: 'uppercase',
                    }}
                  >
                    {obs.severity}
                  </span>
                </div>

                <div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: t.textPrimary }}>
                    {obs.title}
                  </div>
                  <div style={{ fontSize: 11, color: t.textSecondary }}>
                    Ref: {obs.report}
                  </div>
                </div>

                <div style={{ fontSize: 12, color: t.textSecondary }}>
                  {obs.department || obs.dept}
                </div>

                <div style={{ fontSize: 12, fontWeight: 500 }}>
                  {obs.owner || 'Assigned Lead'}
                </div>

                <div style={{ fontSize: 12, fontWeight: 600, color: obs.overdue ? t.cinnabar : t.textPrimary }}>
                  {obs.dueDate}
                </div>

                <div>
                  <span
                    style={{
                      fontSize: 10.5,
                      fontWeight: 600,
                      color: obs.overdue ? t.cinnabar : obs.approval === 'Approved' ? t.verdigris : t.blueAccent,
                      padding: '2px 8px',
                      borderRadius: 4,
                      background: obs.overdue ? `${t.cinnabar}15` : `${t.verdigris}15`,
                      border: `1px solid ${obs.overdue ? t.cinnabar : t.verdigris}35`,
                    }}
                  >
                    {obs.overdue ? 'OVERDUE' : obs.approval}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
