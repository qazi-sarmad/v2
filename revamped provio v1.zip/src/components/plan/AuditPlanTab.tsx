import React from 'react';
import { useTheme, FONTS, HOVER_EASE, HOVER_DUR } from '../../context/ThemeContext';
import { useApp } from '../../context/AppContext';
import { Icon } from '../common/Icons';

export function AuditPlanTab() {
  const { t } = useTheme();
  const { entities, audits, people, showToast, setActiveTab } = useApp();

  return (
    <div style={{ padding: '32px 48px', maxWidth: 1360, margin: '0 auto' }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 24, flexWrap: 'wrap', gap: 16 }}>
        <div>
          <div style={{ fontFamily: FONTS.serif, fontSize: 26, fontWeight: 600, marginBottom: 4 }}>
            Annual Audit Plan & Mandate Charter
          </div>
          <p style={{ color: t.textSecondary, fontSize: 13.5 }}>
            Resource capacity modeling, statutory audit committee charter commitments, and multi-year coverage.
          </p>
        </div>

        <button
          onClick={() => showToast('Generated formal 2026 Audit Mandate & Resource Allocation Report')}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 6,
            padding: '8px 16px',
            borderRadius: 9,
            border: 'none',
            background: t.verdigris,
            color: t.mode === 'dark' ? '#12151C' : '#FFFFFF',
            fontSize: 12.5,
            fontWeight: 600,
            cursor: 'pointer',
          }}
        >
          Download Mandate PDF
        </button>
      </div>

      {/* Plan Summary Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 28 }}>
        <div style={{ padding: '20px 22px', borderRadius: 14, background: t.card, border: `1px solid ${t.hairline}` }}>
          <div style={{ fontSize: 11.5, color: t.textSecondary, marginBottom: 4 }}>TOTAL AUDIT CAPACITY</div>
          <div style={{ fontFamily: FONTS.serif, fontSize: 26, fontWeight: 700 }}>1,840 Auditor Days</div>
          <div style={{ fontSize: 11.5, color: t.verdigris, marginTop: 4 }}>1,480 Days Direct Fieldwork (80.4%)</div>
        </div>

        <div style={{ padding: '20px 22px', borderRadius: 14, background: t.card, border: `1px solid ${t.hairline}` }}>
          <div style={{ fontSize: 11.5, color: t.textSecondary, marginBottom: 4 }}>ANNUAL AUDIT COMMITMENTS</div>
          <div style={{ fontFamily: FONTS.serif, fontSize: 26, fontWeight: 700 }}>{audits.length} Planned Audits</div>
          <div style={{ fontSize: 11.5, color: t.textSecondary, marginTop: 4 }}>100% of Critical Inherent Risk Entities</div>
        </div>

        <div style={{ padding: '20px 22px', borderRadius: 14, background: t.card, border: `1px solid ${t.hairline}` }}>
          <div style={{ fontSize: 11.5, color: t.textSecondary, marginBottom: 4 }}>AUDIT TEAM ROSTER</div>
          <div style={{ fontFamily: FONTS.serif, fontSize: 26, fontWeight: 700 }}>{people.length} Certified Professionals</div>
          <div style={{ fontSize: 11.5, color: t.textSecondary, marginTop: 4 }}>CIA, CISA, CPA, CRMA Credentials</div>
        </div>
      </div>

      {/* Division Allocation Model */}
      <div style={{ background: t.card, borderRadius: 16, border: `1px solid ${t.hairline}`, padding: 24, marginBottom: 28 }}>
        <div style={{ fontFamily: FONTS.serif, fontSize: 18, fontWeight: 600, marginBottom: 6 }}>
          2026 Fieldwork Resource Distribution by Division
        </div>
        <div style={{ fontSize: 12.5, color: t.textSecondary, marginBottom: 20 }}>
          Assigned FTE days calculated per the CAE Visual Logic risk-weighted algorithm.
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {[
            { dept: 'Retail Banking Division', days: 480, pct: 32, leads: 'Riya Anand' },
            { dept: 'Treasury & Balance Sheet Management', days: 360, pct: 24, leads: 'Devraj Mehta' },
            { dept: 'Deposit Operations & Clearing', days: 280, pct: 19, leads: 'Tariq Al-Mansoor' },
            { dept: 'Technology & Cyber Risk Assurance', days: 340, pct: 23, leads: 'Elena Rostova' },
            { dept: 'Procurement & Third-Party Vendor', days: 180, pct: 12, leads: 'Devraj Mehta' },
          ].map((item) => (
            <div key={item.dept} style={{ padding: '14px 16px', borderRadius: 10, background: t.cardSunken, border: `1px solid ${t.hairline}` }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                <div>
                  <span style={{ fontSize: 13.5, fontWeight: 600 }}>{item.dept}</span>
                  <span style={{ fontSize: 11.5, color: t.textSecondary, marginLeft: 10 }}>Lead: {item.leads}</span>
                </div>
                <span style={{ fontSize: 13, fontWeight: 700, color: t.verdigris }}>
                  {item.days} Days ({item.pct}%)
                </span>
              </div>
              <div style={{ width: '100%', height: 6, borderRadius: 3, background: t.hairline, overflow: 'hidden' }}>
                <div style={{ width: `${item.pct * 2.5}%`, height: '100%', background: t.verdigris, borderRadius: 3 }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
