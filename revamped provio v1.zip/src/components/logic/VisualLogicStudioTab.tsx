import React, { useState } from 'react';
import { useTheme, FONTS, SPRING, HOVER_EASE, HOVER_DUR } from '../../context/ThemeContext';
import { useApp } from '../../context/AppContext';
import { Icon } from '../common/Icons';
import { LogicNode } from '../../types';
import { Lock, ShieldAlert, Sparkles, CheckCircle2, UserCheck, KeyRound } from 'lucide-react';

export function VisualLogicStudioTab() {
  const { t } = useTheme();
  const {
    logicNodes,
    updateNodeParam,
    selectedNodeForEdit,
    setSelectedNodeForEdit,
    isSimulatingLogic,
    runLogicSimulation,
    simulationResults,
    activeUser,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'canvas' | 'rules' | 'versions'>('canvas');
  const [methodologyVersion, setMethodologyVersion] = useState('Meridian IA Methodology v3.2 (Approved 2026)');

  // RBAC Enforcement (Requirement 8):
  // "CAE Visual Methodology & Logic Studio: Why is it editable if I'm using the default Audit Lead Riya Anand profile? Shouldn't it only be visible to either CAE, or clients' admin?"
  const isCAEOrAdmin = activeUser.permissions.canEditMethodology && activeUser.level <= 1;

  const getCategoryColor = (cat: LogicNode['category']) => {
    switch (cat) {
      case 'trigger':
        return t.blueAccent;
      case 'sampling':
        return t.verdigris;
      case 'gate':
        return t.mode === 'dark' ? '#E59866' : '#C6521E';
      case 'escalation':
        return t.cinnabar;
      case 'signoff':
        return t.verdigris;
      default:
        return t.textSecondary;
    }
  };

  const handlePublish = () => {
    if (!isCAEOrAdmin) {
      showToast('Access Denied: Only Chief Audit Executive (Marcus Vance) or Client Admin can publish methodology versions.');
      return;
    }
    showToast(`Published & locked "${methodologyVersion}" to active tenant governance.`);
  };

  return (
    <div style={{ padding: '32px 48px', maxWidth: 1360, margin: '0 auto', position: 'relative' }}>
      {/* Title & Actions */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 20, flexWrap: 'wrap', gap: 16 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
            <span style={{ fontFamily: FONTS.serif, fontSize: 26, fontWeight: 600 }}>
              CAE Visual Methodology & Logic Studio
            </span>
            {isCAEOrAdmin ? (
              <span
                style={{
                  fontSize: 11,
                  fontWeight: 700,
                  color: t.verdigris,
                  padding: '2px 8px',
                  borderRadius: 5,
                  background: `${t.verdigris}15`,
                  border: `1px solid ${t.verdigris}35`,
                }}
              >
                CAE Full Editing Authority
              </span>
            ) : (
              <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30">
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                Read-Only Inspection Mode
              </span>
            )}
          </div>
          <p style={{ color: t.textSecondary, fontSize: 13.5 }}>
            Configure and adapt audit testing methodologies, statistical sampling algorithms, maker-checker gates, and escalation logic visually.
          </p>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button
            onClick={runLogicSimulation}
            disabled={isSimulatingLogic}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 7,
              padding: '8px 16px',
              borderRadius: 9,
              border: 'none',
              background: isSimulatingLogic ? t.cardSunken : t.verdigris,
              color: isSimulatingLogic ? t.textSecondary : (t.mode === 'dark' ? '#12151C' : '#FFFFFF'),
              fontSize: 12.5,
              fontWeight: 600,
              cursor: isSimulatingLogic ? 'default' : 'pointer',
              boxShadow: '0 4px 14px rgba(0,0,0,0.18)',
              transition: `all 0.2s ${HOVER_EASE}`,
            }}
          >
            {isSimulatingLogic ? (
              <span>Simulating...</span>
            ) : (
              <>
                {Icon.play(t.mode === 'dark' ? '#12151C' : '#FFFFFF')}
                <span>Test-Run Logic Simulation</span>
              </>
            )}
          </button>

          <button
            onClick={handlePublish}
            disabled={!isCAEOrAdmin}
            style={{
              padding: '8px 14px',
              borderRadius: 9,
              border: `1px solid ${isCAEOrAdmin ? t.hairlineStrong : t.hairline}`,
              background: isCAEOrAdmin ? t.card : t.cardSunken,
              color: isCAEOrAdmin ? t.textPrimary : t.textSecondary,
              fontSize: 12.5,
              fontWeight: 600,
              cursor: isCAEOrAdmin ? 'pointer' : 'not-allowed',
              opacity: isCAEOrAdmin ? 1 : 0.6,
            }}
            title={isCAEOrAdmin ? 'Publish methodology release' : 'Requires CAE authorization'}
          >
            Publish Version
          </button>
        </div>
      </div>

      {/* RBAC Notice Banner for Non-CAE User */}
      {!isCAEOrAdmin && (
        <div className="mb-6 p-4 rounded-xl bg-gradient-to-r from-[#211A1D] to-[#17141F] border border-amber-500/30 text-xs text-amber-200 flex items-start gap-3 shadow-md">
          <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="font-semibold text-white flex items-center gap-2">
              <span>Read-Only Governance Purview · Active Profile: <strong>{activeUser.name} ({activeUser.roleTitle})</strong></span>
            </h4>
            <p className="opacity-90 leading-relaxed">
              Under IIA International Standards and Meridian Audit Charter Section 4.2, methodology logic nodes, statistical confidence levels, and mandatory escalation gates are strictly reserved for the <strong>Chief Audit Executive (CAE)</strong> or authorized <strong>Client Tenant Administrator</strong>. You may inspect node configurations and run simulations, but parameter modifications are locked.
            </p>
          </div>
        </div>
      )}

      {/* Simulation Banner Result if available */}
      {simulationResults && (
        <div
          style={{
            padding: '14px 20px',
            borderRadius: 12,
            background: `${t.verdigris}14`,
            border: `1.5px solid ${t.verdigris}50`,
            marginBottom: 20,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            animation: 'riseIn 0.2s ease',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div
              style={{
                width: 28,
                height: 28,
                borderRadius: '50%',
                background: t.verdigris,
                color: t.card,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              {Icon.check('#FFFFFF')}
            </div>
            <div>
              <div style={{ fontSize: 13, fontWeight: 700, color: t.verdigris }}>
                Logic Engine Verified Nominal · {simulationResults.executionTimeMs}ms Execution
              </div>
              <div style={{ fontSize: 12, color: t.textPrimary }}>
                {simulationResults.summary}
              </div>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 16, fontSize: 12, color: t.textSecondary }}>
            <span>Evaluated: <strong style={{ color: t.textPrimary }}>{simulationResults.evaluatedEntities} Entities</strong></span>
            <span>Sample Target: <strong style={{ color: t.verdigris }}>{simulationResults.sampleSizeOutput} files</strong></span>
            <span>Confidence: <strong style={{ color: t.textPrimary }}>{simulationResults.confidencePct}%</strong></span>
          </div>
        </div>
      )}

      {/* Visual Canvas Container */}
      <div
        style={{
          background: t.card,
          border: `1px solid ${t.hairline}`,
          borderRadius: 18,
          padding: 24,
          minHeight: 520,
          position: 'relative',
          overflow: 'hidden',
          backgroundImage: `radial-gradient(${t.hairlineStrong} 1px, transparent 1px)`,
          backgroundSize: '24px 24px',
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <div style={{ fontSize: 12, color: t.textSecondary }}>
            Active Methodology Pipeline: <strong style={{ color: t.textPrimary }}>{methodologyVersion}</strong> · {isCAEOrAdmin ? 'Click any node to configure parameters' : 'Click any node to inspect parameters (Read-Only)'}
          </div>
          <div style={{ display: 'flex', gap: 12, fontSize: 11, color: t.textSecondary }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: t.blueAccent }} />
              Intake Trigger
            </span>
            <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: t.verdigris }} />
              Sampling Calculation
            </span>
            <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: t.cinnabar }} />
              Gatekeeper & Escalation
            </span>
          </div>
        </div>

        {/* Nodes Grid / Flow */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: 20,
            marginTop: 10,
          }}
        >
          {logicNodes.map((node) => {
            const catColor = getCategoryColor(node.category);
            const isSelected = selectedNodeForEdit?.id === node.id;
            return (
              <div
                key={node.id}
                onClick={() => setSelectedNodeForEdit(node)}
                style={{
                  background: isSelected
                    ? (t.mode === 'dark' ? 'rgba(111,166,148,0.14)' : 'rgba(78,135,120,0.08)')
                    : t.cardSunken,
                  border: isSelected
                    ? `1.5px solid ${t.verdigris}`
                    : `1px solid ${t.hairline}`,
                  borderRadius: 14,
                  padding: '18px 20px',
                  cursor: 'pointer',
                  boxShadow: isSelected ? '0 8px 24px rgba(0,0,0,0.12)' : '0 2px 8px rgba(0,0,0,0.04)',
                  transition: `transform 0.2s ${HOVER_EASE}, border-color 0.2s ease`,
                  transform: isSelected ? 'scale(1.02)' : 'scale(1)',
                  position: 'relative',
                }}
              >
                {/* Node Category Marker */}
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
                  <span
                    style={{
                      fontSize: 10,
                      fontWeight: 700,
                      color: catColor,
                      padding: '2px 7px',
                      borderRadius: 4,
                      background: `${catColor}15`,
                      border: `1px solid ${catColor}35`,
                      textTransform: 'uppercase',
                      letterSpacing: 0.3,
                    }}
                  >
                    {node.category}
                  </span>
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-400 font-semibold">
                    {!isCAEOrAdmin && <Lock className="w-3 h-3 text-amber-400/80" />}
                    <span>{node.parameters.length} Parameters</span>
                  </div>
                </div>

                <div style={{ fontSize: 14.5, fontWeight: 600, marginBottom: 6 }}>
                  {node.title}
                </div>
                <div style={{ fontSize: 12, color: t.textSecondary, lineHeight: 1.4, marginBottom: 14 }}>
                  {node.description}
                </div>

                {/* Live Parameter Previews */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {node.parameters.slice(0, 3).map((p) => (
                    <div
                      key={p.key}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        fontSize: 11.5,
                        padding: '4px 8px',
                        borderRadius: 6,
                        background: t.card,
                        border: `1px solid ${t.hairline}`,
                      }}
                    >
                      <span style={{ color: t.textSecondary }}>{p.label}</span>
                      <span style={{ fontWeight: 600, color: t.textPrimary }}>
                        {p.type === 'toggle'
                          ? p.value ? 'Enforced' : 'Off'
                          : String(p.value) + (p.unit ? ` ${p.unit}` : '')}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Click affordance hint */}
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'flex-end',
                    marginTop: 12,
                    fontSize: 11,
                    color: isCAEOrAdmin ? t.verdigris : t.textSecondary,
                    fontWeight: 600,
                  }}
                >
                  {isCAEOrAdmin ? 'Configure values →' : 'Inspect parameters (Locked) →'}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Parameter Configuration Dialogue Box (Drawer / Modal) */}
      {selectedNodeForEdit && (
        <div
          onClick={() => setSelectedNodeForEdit(null)}
          style={{
            position: 'fixed',
            inset: 0,
            background: t.overlay,
            backdropFilter: 'blur(3px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 100,
            animation: 'fadeIn 0.15s ease',
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              width: 560,
              maxHeight: '82vh',
              background: t.card,
              borderRadius: 18,
              border: `1px solid ${t.hairlineStrong}`,
              boxShadow: '0 32px 72px rgba(0,0,0,0.45)',
              overflow: 'hidden',
              display: 'flex',
              flexDirection: 'column',
              animation: `riseIn 0.25s ${SPRING}`,
            }}
          >
            {/* Dialogue Header */}
            <div
              style={{
                padding: '20px 24px',
                borderBottom: `1px solid ${t.hairline}`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}
            >
              <div>
                <div style={{ fontSize: 11, color: t.textSecondary, fontWeight: 600, letterSpacing: 0.3 }}>
                  METHODOLOGY NODE CONFIGURATION {isCAEOrAdmin ? '· AUTHORIZED EDIT' : '· READ-ONLY'}
                </div>
                <div style={{ fontSize: 16.5, fontWeight: 600 }}>{selectedNodeForEdit.title}</div>
              </div>
              <button
                onClick={() => setSelectedNodeForEdit(null)}
                style={{
                  background: 'none',
                  border: 'none',
                  color: t.textSecondary,
                  cursor: 'pointer',
                  fontSize: 18,
                  padding: 4,
                }}
              >
                ×
              </button>
            </div>

            {/* Form Fields for Node Parameters */}
            <div style={{ overflowY: 'auto', padding: '20px 24px', display: 'flex', flexDirection: 'column', gap: 16 }}>
              {!isCAEOrAdmin && (
                <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/25 text-[11px] text-amber-200 flex items-center gap-2">
                  <Lock className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>Parameters are locked against edits under the active persona. CAE sign-off required.</span>
                </div>
              )}

              <p style={{ fontSize: 12.5, color: t.textSecondary, lineHeight: 1.5, background: t.cardSunken, padding: '10px 14px', borderRadius: 8 }}>
                {selectedNodeForEdit.description}
              </p>

              {selectedNodeForEdit.parameters.map((param) => {
                return (
                  <div
                    key={param.key}
                    style={{
                      padding: '12px 14px',
                      borderRadius: 10,
                      background: t.cardSunken,
                      border: `1px solid ${t.hairline}`,
                    }}
                  >
                    <label style={{ fontSize: 12, fontWeight: 600, color: t.textPrimary, display: 'block', marginBottom: 6 }}>
                      {param.label}
                    </label>

                    {param.type === 'select' && (
                      <select
                        disabled={!isCAEOrAdmin}
                        value={param.value}
                        onChange={(e) => updateNodeParam(selectedNodeForEdit.id, param.key, e.target.value)}
                        style={{
                          width: '100%',
                          padding: '7px 10px',
                          borderRadius: 7,
                          background: t.card,
                          border: `1px solid ${t.hairlineStrong}`,
                          color: t.textPrimary,
                          fontSize: 12.5,
                          outline: 'none',
                          opacity: isCAEOrAdmin ? 1 : 0.7,
                          cursor: isCAEOrAdmin ? 'pointer' : 'not-allowed',
                        }}
                      >
                        {param.options?.map((opt) => (
                          <option key={String(opt.value)} value={opt.value}>
                            {opt.label}
                          </option>
                        ))}
                      </select>
                    )}

                    {param.type === 'number' && (
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <input
                          type="number"
                          disabled={!isCAEOrAdmin}
                          value={param.value}
                          onChange={(e) => updateNodeParam(selectedNodeForEdit.id, param.key, Number(e.target.value))}
                          style={{
                            width: 140,
                            padding: '7px 10px',
                            borderRadius: 7,
                            background: t.card,
                            border: `1px solid ${t.hairlineStrong}`,
                            color: t.textPrimary,
                            fontSize: 12.5,
                            outline: 'none',
                            opacity: isCAEOrAdmin ? 1 : 0.7,
                            cursor: isCAEOrAdmin ? 'text' : 'not-allowed',
                          }}
                        />
                        {param.unit && <span style={{ fontSize: 12, color: t.textSecondary }}>{param.unit}</span>}
                      </div>
                    )}

                    {param.type === 'toggle' && (
                      <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: isCAEOrAdmin ? 'pointer' : 'not-allowed' }}>
                        <input
                          type="checkbox"
                          disabled={!isCAEOrAdmin}
                          checked={param.value}
                          onChange={(e) => updateNodeParam(selectedNodeForEdit.id, param.key, e.target.checked)}
                          style={{ accentColor: t.verdigris }}
                        />
                        <span style={{ fontSize: 12.5, color: t.textPrimary }}>
                          {param.value ? 'Rule Enforced & Mandatory' : 'Optional / Disabled'}
                        </span>
                      </label>
                    )}
                  </div>
                );
              })}
            </div>

            <div style={{ padding: '16px 24px', borderTop: `1px solid ${t.hairline}`, display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
              <button
                onClick={() => setSelectedNodeForEdit(null)}
                style={{
                  padding: '8px 18px',
                  borderRadius: 8,
                  border: 'none',
                  background: t.verdigris,
                  color: t.mode === 'dark' ? '#12151C' : '#FFFFFF',
                  fontSize: 12.5,
                  fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                {isCAEOrAdmin ? 'Apply Node Parameters' : 'Close Inspection'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
