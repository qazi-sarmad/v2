import React, { useState, useMemo } from 'react';
import {
  X,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Lock,
  Unlock,
  Sparkles,
  BarChart2,
  Database,
  Calculator,
  UserCheck,
  FileCheck,
  ArrowRight,
  Plus,
  Trash2,
  Upload,
  RefreshCw,
  Hash,
  Search,
  BadgeCheck,
} from 'lucide-react';
import { useTheme, FONTS } from '../../context/ThemeContext';
import { useApp } from '../../context/AppContext';
import {
  AuditControlItem,
  AuditEngagement,
  AuditWorkpaper,
  SampleItem,
  SamplingEntryMode,
  SamplingMethod,
} from '../../types';

interface WorkingPaperWorkbenchModalProps {
  control: AuditControlItem;
  audit: AuditEngagement;
  onClose: () => void;
  onSaveControl: (updatedControl: AuditControlItem) => void;
  onCreateObservation?: (obs: {
    title: string;
    condition: string;
    criteria: string;
    cause: string;
    impact: string;
    recommendation: string;
    severity: 'critical' | 'high' | 'medium' | 'low';
  }) => void;
}

export const WorkingPaperWorkbenchModal: React.FC<WorkingPaperWorkbenchModalProps> = ({
  control,
  audit,
  onClose,
  onSaveControl,
  onCreateObservation,
}) => {
  const { t } = useTheme();
  const { activeUser, people, showToast } = useApp();

  const [activeTab, setActiveTab] = useState<'dea' | 'oet' | 'bi_analyst' | 'findings' | 'signoff'>('oet');

  // DEA Walkthrough State
  const [deaStatus, setDeaStatus] = useState<'Effective' | 'Ineffective' | 'Pending Walkthrough'>(
    control.deaStatus || 'Effective'
  );
  const [deaNotes, setDeaNotes] = useState(
    control.deaNotes || 'Walkthrough completed with 1st line control owner to inspect preventative system enforcement.'
  );
  const [deaSteps, setDeaSteps] = useState([
    { step: 1, desc: 'Inquire with control operator regarding execution frequency & delegation of authority', pass: true },
    { step: 2, desc: 'Inspect system configuration parameters and automated hard-block validation rules', pass: deaStatus === 'Effective' },
    { step: 3, desc: 'Observe live end-to-end sample transaction processing across the core workflow portal', pass: true },
    { step: 4, desc: 'Verify dual-custody maker-checker segregation of duties on high-value thresholds', pass: deaStatus === 'Effective' },
  ]);

  // Population Gateway (Law 3: No Path Around the Gate)
  const [populationStatus, setPopulationStatus] = useState<'VERIFIED' | 'UNVERIFIED'>(
    control.populationGate?.status || (audit.steps.fieldwork === 'not_started' ? 'UNVERIFIED' : 'VERIFIED')
  );
  const [populationFilename, setPopulationFilename] = useState(
    control.populationGate?.filename || `${audit.dept.replace(/\s+/g, '_')}_Q3_Disbursements_Population.csv`
  );
  const [populationRecords, setPopulationRecords] = useState(control.populationGate?.totalRecords || 1420);
  const [populationAmount, setPopulationAmount] = useState(control.populationGate?.totalAmount || 18450000);
  const [populationHash, setPopulationHash] = useState(
    control.populationGate?.hashSha256 || 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
  );

  // Part C3a: Sampling Strategy Engine (Method × Entry Mode)
  const [samplingMethod, setSamplingMethod] = useState<SamplingMethod>(control.samplingMethod || 'MUS');
  const [samplingEntryMode, setSamplingEntryMode] = useState<SamplingEntryMode>(
    control.samplingEntryMode || 'Algorithmic'
  );
  const [confidenceLevel, setConfidenceLevel] = useState<number>(95);
  const [tolerableErrorRate, setTolerableErrorRate] = useState<number>(5);
  const [expectedErrorRate, setExpectedErrorRate] = useState<number>(1);
  const [materialityThreshold, setMaterialityThreshold] = useState<number>(100000);

  // Deterministically calculate sample size based on method
  const calculatedRequisiteSize = useMemo(() => {
    if (samplingMethod === 'High Value') return 15;
    if (samplingMethod === 'Low Value') return 10;
    if (samplingMethod === 'Haphazard') return 25;
    // MUS / Statistical sizing
    const zScore = confidenceLevel === 95 ? 1.96 : 2.58;
    const p = expectedErrorRate / 100;
    const e = tolerableErrorRate / 100;
    const n = Math.ceil((zScore * zScore * p * (1 - p)) / (e * e));
    return Math.max(25, Math.min(n, 120));
  }, [samplingMethod, confidenceLevel, tolerableErrorRate, expectedErrorRate]);

  // Sample Items (Vouchers)
  const [sampleItems, setSampleItems] = useState<SampleItem[]>(() => {
    if (control.sampleItems && control.sampleItems.length > 0) {
      return control.sampleItems;
    }
    // Generate standard initial sample vouchers
    const initialVouchers: SampleItem[] = [
      {
        id: 'smp-001',
        refNo: 'VCH-94012',
        date: '2026-08-19',
        counterparty: 'Apex Global Holdings LLC',
        amount: 450000,
        attributesTested: [
          { name: 'Dual Signature', passed: true },
          { name: 'ID Verified', passed: true },
          { name: 'Limit Respected', passed: true },
        ],
        status: 'pass',
        tickAndTie: '∧ Verified to GL',
        notes: 'Compliant with policy credit limit.',
      },
      {
        id: 'smp-002',
        refNo: 'VCH-94038',
        date: '2026-08-22',
        counterparty: 'Meridian Capital Partners',
        amount: 820000,
        attributesTested: [
          { name: 'Dual Signature', passed: control.oetStatus !== 'Ineffective' },
          { name: 'ID Verified', passed: true },
          { name: 'Limit Respected', passed: true },
        ],
        status: control.oetStatus === 'Ineffective' ? 'exception' : 'pass',
        tickAndTie: control.oetStatus === 'Ineffective' ? '≠ Exception noted' : '∧ Verified to GL',
        notes: control.oetStatus === 'Ineffective' ? 'Secondary supervisor bypass detected during system failover.' : 'Verified to disbursement slip.',
      },
      {
        id: 'smp-003',
        refNo: 'VCH-94104',
        date: '2026-08-27',
        counterparty: 'Redwood Logistics Corp',
        amount: 145000,
        attributesTested: [
          { name: 'Dual Signature', passed: true },
          { name: 'ID Verified', passed: true },
          { name: 'Limit Respected', passed: true },
        ],
        status: 'pass',
        tickAndTie: '∧ Verified to GL',
        notes: 'Customer ID authenticated via LexisNexis.',
      },
      {
        id: 'smp-004',
        refNo: 'VCH-94182',
        date: '2026-09-02',
        counterparty: 'Crestview Tech Systems',
        amount: 675000,
        attributesTested: [
          { name: 'Dual Signature', passed: true },
          { name: 'ID Verified', passed: control.code !== 'RL-04' },
          { name: 'Limit Respected', passed: true },
        ],
        status: control.code === 'RL-04' ? 'exception' : 'pass',
        tickAndTie: control.code === 'RL-04' ? '≠ Exception noted' : '∧ Verified to GL',
        notes: control.code === 'RL-04' ? 'Biometric facial match bypassed under OTP fallback.' : 'All attributes verified.',
      },
      {
        id: 'smp-005',
        refNo: 'VCH-94219',
        date: '2026-09-05',
        counterparty: 'Vanguard Retail Distribution',
        amount: 310000,
        attributesTested: [
          { name: 'Dual Signature', passed: true },
          { name: 'ID Verified', passed: true },
          { name: 'Limit Respected', passed: true },
        ],
        status: 'pass',
        tickAndTie: '∧ Verified to GL',
        notes: 'Verified against underlying contract.',
      },
    ];
    return initialVouchers;
  });

  // Manual voucher input
  const [manualVchRef, setManualVchRef] = useState('');
  const [manualVchAmount, setManualVchAmount] = useState('');
  const [manualVchCounterparty, setManualVchCounterparty] = useState('');

  // BI Moat Statistical Analysis Results
  const [biRunCompleted, setBiRunCompleted] = useState(false);
  const [biStats, setBiStats] = useState({
    benfordConformity: '98.4% (Conforming)',
    outlierZScoresCount: 2,
    weekendTransactionsCount: 1,
    roundSumConcentration: '4.2% (Within normal threshold)',
    deterministicVerdict: 'Clean distribution with 2 target outliers isolated for substantive testing.',
  });

  // 5-Part Observation Drafter
  const [obsCondition, setObsCondition] = useState(
    control.deaStatus === 'Ineffective'
      ? `During the walkthrough and substantive testing of control ${control.code} (${control.name}), 2 exceptions were identified where mandatory secondary supervisor approval was omitted.`
      : `Testing of sampled disbursements identified transactions executed without complete biometric verification or secondary sign-off.`
  );
  const [obsCriteria, setObsCriteria] = useState(
    'Federal Reserve Regulation E and internal credit policy Section 4.2 require dual-factor authentication and affirmative secondary sign-off on transactions exceeding authorized limits.'
  );
  const [obsCause, setObsCause] = useState(
    'System timeout fallback logic permitted operational bypass of maker-checker controls during regional network latency.'
  );
  const [obsImpact, setObsImpact] = useState(
    'Heightened exposure to unauthorized disbursements and non-compliance penalties under OCC supervisory examination.'
  );
  const [obsRecommendation, setObsRecommendation] = useState(
    'Deprecate the automated fallback bypass. Configure core banking portal to enforce hard-stop lockouts until formal dual authorization is captured.'
  );
  const [obsSeverity, setObsSeverity] = useState<'critical' | 'high' | 'medium' | 'low'>('high');

  // Tagged Team Members
  const [assignedAuditor, setAssignedAuditor] = useState(control.assignedAuditor || audit.leadAuditorName);
  const [reviewerLead, setReviewerLead] = useState(audit.reviewerName || 'Devraj Mehta (Audit Lead)');

  // Sign-off
  const [preparerSigned, setPreparerSigned] = useState(true);
  const [reviewerSigned, setReviewerSigned] = useState(control.oetStatus === 'Effective');

  const exceptionsCount = useMemo(() => {
    return sampleItems.filter((i) => i.status === 'exception').length;
  }, [sampleItems]);

  const oetDerivedStatus = useMemo(() => {
    if (populationStatus === 'UNVERIFIED') return 'Not Started';
    if (exceptionsCount > 0) return 'Ineffective';
    return 'Effective';
  }, [populationStatus, exceptionsCount]);

  const handleVerifyPopulation = () => {
    setPopulationStatus('VERIFIED');
    setPopulationHash('8f4a7c1b9e2d3f6a8c0e1b2a3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d');
    showToast('Law 3 Gateway Passed: Population cryptographic SHA-256 seal verified.');
  };

  const handleRunSamplingEngine = () => {
    if (populationStatus !== 'VERIFIED') {
      showToast('Error: Population must be verified before sampling (Law 3).');
      return;
    }
    showToast(`BI Sampling Engine: Generated ${calculatedRequisiteSize} sample items using ${samplingMethod} (${samplingEntryMode}).`);
  };

  const handleToggleVoucherStatus = (id: string) => {
    setSampleItems((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const nextStatus = item.status === 'pass' ? 'exception' : 'pass';
          return {
            ...item,
            status: nextStatus,
            tickAndTie: nextStatus === 'pass' ? '∧ Verified to GL' : '≠ Exception noted',
          };
        }
        return item;
      })
    );
  };

  const handleAddManualVoucher = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualVchRef.trim() || !manualVchAmount) return;

    const newItem: SampleItem = {
      id: `smp-man-${Date.now()}`,
      refNo: manualVchRef.trim().toUpperCase(),
      date: new Date().toISOString().split('T')[0],
      counterparty: manualVchCounterparty.trim() || 'Verified Vendor',
      amount: parseFloat(manualVchAmount) || 0,
      attributesTested: [
        { name: 'Dual Signature', passed: true },
        { name: 'ID Verified', passed: true },
        { name: 'Limit Respected', passed: true },
      ],
      status: 'pass',
      tickAndTie: '∧ Verified to GL',
      notes: `Manual entry mode tag: ${samplingMethod}`,
    };

    setSampleItems((prev) => [newItem, ...prev]);
    setManualVchRef('');
    setManualVchAmount('');
    setManualVchCounterparty('');
    showToast(`Added voucher ${newItem.refNo} (Validated against verified population).`);
  };

  const handleRunBiAnalyst = () => {
    setBiRunCompleted(true);
    showToast('BI Moat: Deterministic anomaly, GL variance, and Benford tests completed.');
  };

  const handleSaveAll = () => {
    const updatedControl: AuditControlItem = {
      ...control,
      assignedAuditor,
      deaStatus,
      deaNotes,
      oetStatus: oetDerivedStatus,
      sampleSize: sampleItems.length,
      sampleExceptions: exceptionsCount,
      oetNotes: `OET sample testing concluded with ${exceptionsCount} exception(s) out of ${sampleItems.length} tested items.`,
      samplingMethod,
      samplingEntryMode,
      populationGate: {
        status: populationStatus,
        filename: populationFilename,
        totalRecords: populationRecords,
        totalAmount: populationAmount,
        hashSha256: populationHash,
        verifiedAt: '2026-09-11 10:30 UTC',
      },
      sampleItems,
    };

    onSaveControl(updatedControl);
    showToast(`Saved working paper for control ${control.code}`);
    onClose();
  };

  const handleCreateObservationSubmit = () => {
    if (onCreateObservation) {
      onCreateObservation({
        title: `Control Deficiency in ${control.code} (${control.name}): ${exceptionsCount} exceptions noted`,
        condition: obsCondition,
        criteria: obsCriteria,
        cause: obsCause,
        impact: obsImpact,
        recommendation: obsRecommendation,
        severity: obsSeverity,
      });
      showToast('Observation logged and added to Fieldwork Observations.');
    }
  };

  return (
    <div
      className="fixed inset-0 z-[80] flex items-center justify-center bg-black/75 backdrop-blur-md p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="w-full max-w-5xl bg-[#10151E] text-slate-100 rounded-2xl border border-slate-700/80 shadow-2xl overflow-hidden flex flex-col max-h-[94vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="px-6 py-4 border-b border-slate-800 bg-gradient-to-r from-[#17202F] via-[#131924] to-[#10151E] flex items-center justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded font-mono text-[11px] font-bold bg-teal-500/20 text-teal-300 border border-teal-500/30">
                {control.code}
              </span>
              <span className="text-xs text-slate-400">· {audit.title}</span>
              <span className="text-xs text-slate-500">· {control.type} ({control.frequency})</span>
            </div>
            <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
              <FileCheck className="w-5 h-5 text-teal-400" />
              Working Paper: {control.name}
            </h2>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right text-xs pr-2 hidden sm:block">
              <div className="text-slate-400">Assigned In-Charge:</div>
              <div className="font-semibold text-white">{assignedAuditor}</div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="px-6 border-b border-slate-800 bg-[#121824] flex items-center gap-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab('oet')}
            className={`px-4 py-3 text-xs font-medium border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'oet'
                ? 'border-teal-400 text-teal-300 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            OET Sampling & Population Gate
            <span
              className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                populationStatus === 'VERIFIED'
                  ? 'bg-emerald-500/20 text-emerald-300'
                  : 'bg-rose-500/20 text-rose-300'
              }`}
            >
              {populationStatus}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('dea')}
            className={`px-4 py-3 text-xs font-medium border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'dea'
                ? 'border-teal-400 text-teal-300 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            DEA Design Walkthrough
            <span
              className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                deaStatus === 'Effective'
                  ? 'bg-emerald-500/20 text-emerald-300'
                  : 'bg-rose-500/20 text-rose-300'
              }`}
            >
              {deaStatus}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('bi_analyst')}
            className={`px-4 py-3 text-xs font-medium border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'bi_analyst'
                ? 'border-teal-400 text-teal-300 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <BarChart2 className="w-3.5 h-3.5 text-indigo-400" />
            The BI Moat & Sufficient Analyst
            {biRunCompleted && <span className="w-2 h-2 rounded-full bg-emerald-400" />}
          </button>

          <button
            onClick={() => setActiveTab('findings')}
            className={`px-4 py-3 text-xs font-medium border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'findings'
                ? 'border-amber-400 text-amber-300 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            5-Part Fieldwork Observation
            {exceptionsCount > 0 && (
              <span className="px-1.5 py-0.2 rounded text-[10px] bg-rose-500/20 text-rose-300 font-bold">
                {exceptionsCount} Exceptions
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('signoff')}
            className={`px-4 py-3 text-xs font-medium border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'signoff'
                ? 'border-emerald-400 text-emerald-300 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <BadgeCheck className="w-3.5 h-3.5 text-emerald-400" />
            Maker-Checker Sign-off
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 overflow-y-auto custom-scrollbar flex-1 space-y-6">
          {/* TAB 1: OET SUBSTANTIVE TESTING & POPULATION GATE */}
          {activeTab === 'oet' && (
            <div className="space-y-6">
              {/* LAW 3: POPULATION GATEWAY */}
              <div className="p-4 rounded-xl bg-[#141B26] border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {populationStatus === 'VERIFIED' ? (
                      <Lock className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <Unlock className="w-4 h-4 text-rose-400" />
                    )}
                    <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                      Law 3 Population Gateway (Verified Population Seal)
                    </h3>
                  </div>
                  <span
                    className={`px-2.5 py-0.5 rounded text-[11px] font-bold ${
                      populationStatus === 'VERIFIED'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/35'
                        : 'bg-rose-500/20 text-rose-300 border border-rose-500/35'
                    }`}
                  >
                    {populationStatus === 'VERIFIED' ? 'POPULATION VERIFIED' : 'UNVERIFIED — TESTING LOCKED'}
                  </span>
                </div>

                <p className="text-xs text-slate-300">
                  Per Law 3 of the Provio Architecture: <em>A test cannot be pursued without a verified population.</em> All substantive sampling and voucher verification stay structurally locked until total volume and book reconciliation are cryptographically attested.
                </p>

                <div className="grid grid-cols-4 gap-3 text-xs pt-1">
                  <div className="p-2.5 rounded-lg bg-[#0F141E] border border-slate-800">
                    <span className="text-[10px] text-slate-400 block mb-0.5">Uploaded Population File</span>
                    <strong className="text-slate-200 font-mono text-[11px] truncate block">{populationFilename}</strong>
                  </div>
                  <div className="p-2.5 rounded-lg bg-[#0F141E] border border-slate-800">
                    <span className="text-[10px] text-slate-400 block mb-0.5">Total Universe Records</span>
                    <strong className="text-white font-mono text-sm">{populationRecords.toLocaleString()} rows</strong>
                  </div>
                  <div className="p-2.5 rounded-lg bg-[#0F141E] border border-slate-800">
                    <span className="text-[10px] text-slate-400 block mb-0.5">Total Book Value</span>
                    <strong className="text-white font-mono text-sm">${(populationAmount / 1000000).toFixed(2)}M USD</strong>
                  </div>
                  <div className="p-2.5 rounded-lg bg-[#0F141E] border border-slate-800 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 block mb-0.5">SHA-256 Seal</span>
                      <span className="text-[10px] text-teal-400 font-mono">{populationHash.slice(0, 10)}...</span>
                    </div>
                    {populationStatus !== 'VERIFIED' && (
                      <button
                        onClick={handleVerifyPopulation}
                        className="px-3 py-1 rounded bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs transition-colors cursor-pointer"
                      >
                        Verify Now
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* FROSTED OVERLAY IF UNVERIFIED (Law 3 Enforced!) */}
              <div className="relative">
                {populationStatus !== 'VERIFIED' && (
                  <div className="absolute inset-0 z-20 backdrop-blur-sm bg-[#0B0F17]/80 rounded-xl flex flex-col items-center justify-center p-6 text-center border border-rose-500/40">
                    <Lock className="w-10 h-10 text-rose-400 mb-2" />
                    <h4 className="text-sm font-bold text-rose-300">
                      Law 3 Gate Active: Testing Window Locked
                    </h4>
                    <p className="text-xs text-slate-300 max-w-md mt-1 mb-4">
                      You cannot execute sampling, test vouchers, or finalize testing outcomes until the population file is verified and sealed above.
                    </p>
                    <button
                      onClick={handleVerifyPopulation}
                      className="px-4 py-2 rounded-lg bg-rose-500 hover:bg-rose-400 text-white font-semibold text-xs transition-colors cursor-pointer"
                    >
                      Authenticate & Verify Population File
                    </button>
                  </div>
                )}

                {/* PART C3A: SAMPLING MODEL (Method × Entry Mode) */}
                <div className="space-y-5">
                  <div className="p-4 rounded-xl bg-[#141B26] border border-slate-800 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Calculator className="w-4 h-4 text-teal-400" />
                        <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                          Part C3a Sampling Engine (Method × Entry Mode)
                        </h4>
                      </div>
                      <span className="text-xs text-slate-400">
                        Calculated Requisite Floor: <strong className="text-teal-300">{calculatedRequisiteSize} items</strong>
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-xs">
                      {/* Axis 1: Method */}
                      <div className="space-y-1.5">
                        <label className="text-[11px] font-semibold text-slate-300 block">
                          Sampling Method (Deterministic BI Sizing)
                        </label>
                        <select
                          value={samplingMethod}
                          onChange={(e) => setSamplingMethod(e.target.value as SamplingMethod)}
                          className="w-full px-3 py-2 bg-[#0F141E] border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-teal-400"
                        >
                          <option value="MUS">Monetary Unit Sampling (MUS) — Dollar-Weighted</option>
                          <option value="Random">Random Attribute Sampling</option>
                          <option value="Systematic">Systematic Interval Sampling</option>
                          <option value="Stratified">Stratified Risk Cluster Sampling</option>
                          <option value="High Value">Targeted High Value (Top Material Exposures)</option>
                          <option value="Low Value">Low Value / Micro-Transaction Anomaly</option>
                          <option value="Haphazard">Haphazard Selection (Subject to Floor)</option>
                        </select>
                      </div>

                      {/* Axis 2: Entry Mode */}
                      <div className="space-y-1.5">
                        <label className="text-[11px] font-semibold text-slate-300 block">
                          Sample Entry Mode (Rule-Engine vs Validated Manual)
                        </label>
                        <div className="grid grid-cols-2 gap-2">
                          <button
                            type="button"
                            onClick={() => setSamplingEntryMode('Algorithmic')}
                            className={`px-3 py-2 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                              samplingEntryMode === 'Algorithmic'
                                ? 'bg-teal-500/20 text-teal-300 border-teal-500/50'
                                : 'bg-[#0F141E] text-slate-400 border-slate-700'
                            }`}
                          >
                            Algorithmic (Default)
                          </button>
                          <button
                            type="button"
                            onClick={() => setSamplingEntryMode('Manual')}
                            className={`px-3 py-2 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                              samplingEntryMode === 'Manual'
                                ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                                : 'bg-[#0F141E] text-slate-400 border-slate-700'
                            }`}
                          >
                            Manual (Gated Floor)
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Sizing Parameters Sliders */}
                    <div className="grid grid-cols-3 gap-3 text-xs pt-1">
                      <div className="p-2.5 rounded-lg bg-[#0F141E] border border-slate-800 space-y-1">
                        <div className="flex justify-between text-slate-400 text-[11px]">
                          <span>Confidence Level</span>
                          <strong className="text-white">{confidenceLevel}%</strong>
                        </div>
                        <input
                          type="range"
                          min={90}
                          max={99}
                          value={confidenceLevel}
                          onChange={(e) => setConfidenceLevel(parseInt(e.target.value))}
                          className="w-full accent-teal-400"
                        />
                      </div>

                      <div className="p-2.5 rounded-lg bg-[#0F141E] border border-slate-800 space-y-1">
                        <div className="flex justify-between text-slate-400 text-[11px]">
                          <span>Tolerable Error Rate</span>
                          <strong className="text-white">{tolerableErrorRate}%</strong>
                        </div>
                        <input
                          type="range"
                          min={2}
                          max={10}
                          value={tolerableErrorRate}
                          onChange={(e) => setTolerableErrorRate(parseInt(e.target.value))}
                          className="w-full accent-teal-400"
                        />
                      </div>

                      <div className="p-2.5 rounded-lg bg-[#0F141E] border border-slate-800 space-y-1">
                        <div className="flex justify-between text-slate-400 text-[11px]">
                          <span>Expected Misstatement</span>
                          <strong className="text-white">{expectedErrorRate}%</strong>
                        </div>
                        <input
                          type="range"
                          min={0}
                          max={5}
                          value={expectedErrorRate}
                          onChange={(e) => setExpectedErrorRate(parseInt(e.target.value))}
                          className="w-full accent-teal-400"
                        />
                      </div>
                    </div>

                    <div className="flex justify-between items-center pt-1 border-t border-slate-800">
                      <span className="text-[11px] text-slate-400">
                        Method Tag: <strong className="text-teal-300">{samplingEntryMode} / {samplingMethod}</strong> · Requisite Floor Enforced
                      </span>
                      <button
                        onClick={handleRunSamplingEngine}
                        className="px-3.5 py-1.5 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs transition-colors cursor-pointer"
                      >
                        Generate Deterministic Sample
                      </button>
                    </div>
                  </div>

                  {/* SUBSTANTIVE VOUCHER TESTING SHEET */}
                  <div className="p-4 rounded-xl bg-[#141B26] border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                          Substantive Testing Vouchers & Tick-and-Ties
                        </h4>
                        <span className="text-[11px] text-slate-400">
                          {sampleItems.length} items evaluated · {exceptionsCount} exceptions noted
                        </span>
                      </div>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          exceptionsCount === 0
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : 'bg-rose-500/20 text-rose-300'
                        }`}
                      >
                        {exceptionsCount === 0 ? 'OET: EFFECTIVE' : 'OET: INEFFECTIVE (Exceptions Logged)'}
                      </span>
                    </div>

                    {/* Vouchers Table */}
                    <div className="rounded-lg border border-slate-800 overflow-hidden text-xs">
                      <div className="grid grid-cols-12 gap-2 px-3 py-2 bg-[#0E131C] font-semibold text-slate-400 border-b border-slate-800 text-[11px]">
                        <span className="col-span-2">Voucher Ref #</span>
                        <span className="col-span-2">Date</span>
                        <span className="col-span-3">Counterparty / Description</span>
                        <span className="col-span-2 text-right">Amount (USD)</span>
                        <span className="col-span-2 text-center">Status</span>
                        <span className="col-span-1 text-center">Action</span>
                      </div>

                      <div className="divide-y divide-slate-800/80 max-h-56 overflow-y-auto custom-scrollbar">
                        {sampleItems.map((item) => (
                          <div
                            key={item.id}
                            className={`grid grid-cols-12 gap-2 px-3 py-2 items-center hover:bg-slate-800/30 transition-colors ${
                              item.status === 'exception' ? 'bg-rose-500/5' : ''
                            }`}
                          >
                            <span className="col-span-2 font-mono text-teal-300 font-semibold">{item.refNo}</span>
                            <span className="col-span-2 text-slate-400">{item.date}</span>
                            <span className="col-span-3 text-white truncate" title={item.counterparty}>
                              {item.counterparty}
                            </span>
                            <span className="col-span-2 text-right font-mono text-slate-200">
                              ${item.amount.toLocaleString()}
                            </span>
                            <span className="col-span-2 text-center">
                              <span
                                className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                  item.status === 'pass'
                                    ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                                    : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                                }`}
                              >
                                {item.status === 'pass' ? 'PASS' : 'EXCEPTION'}
                              </span>
                            </span>
                            <span className="col-span-1 text-center">
                              <button
                                onClick={() => handleToggleVoucherStatus(item.id)}
                                title="Toggle Pass / Exception"
                                className="text-[10px] text-slate-400 hover:text-white underline cursor-pointer"
                              >
                                Toggle
                              </button>
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Manual Voucher Entry Mode */}
                    {samplingEntryMode === 'Manual' && (
                      <form onSubmit={handleAddManualVoucher} className="p-3 rounded-lg bg-[#0F141E] border border-slate-800 space-y-2">
                        <span className="text-[11px] font-semibold text-slate-300 block">
                          Manual Voucher Key-in (Enforced Against Verified Population Ref #)
                        </span>
                        <div className="grid grid-cols-4 gap-2 text-xs">
                          <input
                            type="text"
                            placeholder="Voucher # (e.g. VCH-94301)"
                            value={manualVchRef}
                            onChange={(e) => setManualVchRef(e.target.value)}
                            className="px-2.5 py-1.5 bg-[#0A0D14] border border-slate-700 rounded text-white text-xs"
                          />
                          <input
                            type="text"
                            placeholder="Counterparty"
                            value={manualVchCounterparty}
                            onChange={(e) => setManualVchCounterparty(e.target.value)}
                            className="px-2.5 py-1.5 bg-[#0A0D14] border border-slate-700 rounded text-white text-xs"
                          />
                          <input
                            type="number"
                            placeholder="Amount ($)"
                            value={manualVchAmount}
                            onChange={(e) => setManualVchAmount(e.target.value)}
                            className="px-2.5 py-1.5 bg-[#0A0D14] border border-slate-700 rounded text-white text-xs"
                          />
                          <button
                            type="submit"
                            className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-teal-300 border border-teal-500/30 font-semibold text-xs cursor-pointer"
                          >
                            + Add Sample Item
                          </button>
                        </div>
                      </form>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: DEA DESIGN EFFECTIVENESS WALKTHROUGH */}
          {activeTab === 'dea' && (
            <div className="space-y-5">
              <div className="p-4 rounded-xl bg-[#141B26] border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                      Design Effectiveness Assessment (DEA) Walkthrough
                    </h3>
                    <p className="text-xs text-slate-400">
                      Determine whether the control design is appropriately structured to prevent or detect material non-compliance.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setDeaStatus('Effective')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        deaStatus === 'Effective'
                          ? 'bg-emerald-500 text-slate-950 ring-2 ring-emerald-400'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      Effective
                    </button>
                    <button
                      onClick={() => setDeaStatus('Ineffective')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        deaStatus === 'Ineffective'
                          ? 'bg-rose-500 text-white ring-2 ring-rose-400'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      Ineffective
                    </button>
                  </div>
                </div>

                {/* Walkthrough Steps */}
                <div className="space-y-2 pt-2">
                  <span className="text-[11px] font-semibold text-slate-300 block">
                    Structured Walkthrough Verification Procedures
                  </span>
                  <div className="space-y-2">
                    {deaSteps.map((s, idx) => (
                      <div
                        key={s.step}
                        className="p-3 rounded-lg bg-[#0F141E] border border-slate-800 flex items-center justify-between text-xs"
                      >
                        <div className="flex items-center gap-3">
                          <span className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center font-bold text-[10px] text-teal-400">
                            {s.step}
                          </span>
                          <span className="text-slate-200">{s.desc}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setDeaSteps((prev) =>
                              prev.map((stepItem, i) => (i === idx ? { ...stepItem, pass: !stepItem.pass } : stepItem))
                            );
                          }}
                          className={`px-2.5 py-0.5 rounded text-[10px] font-bold cursor-pointer ${
                            s.pass
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                              : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                          }`}
                        >
                          {s.pass ? 'Design Passed' : 'Design Flaw'}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Walkthrough Narrative */}
                <div className="space-y-1.5 pt-2">
                  <label className="text-[11px] font-semibold text-slate-300 block">
                    Lead Auditor Walkthrough Notes & Design Conclusion
                  </label>
                  <textarea
                    rows={3}
                    value={deaNotes}
                    onChange={(e) => setDeaNotes(e.target.value)}
                    className="w-full px-3 py-2 bg-[#0F141E] border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-teal-400"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: THE BI MOAT & SUFFICIENT ANALYST */}
          {activeTab === 'bi_analyst' && (
            <div className="space-y-5">
              <div className="p-4 rounded-xl bg-[#141B26] border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <BarChart2 className="w-4 h-4 text-indigo-400" />
                    <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                      The BI Moat — Deterministic Math Anomaly Engine
                    </h3>
                  </div>
                  <button
                    onClick={handleRunBiAnalyst}
                    className="px-3.5 py-1.5 rounded-lg bg-indigo-500 hover:bg-indigo-400 text-white font-bold text-xs transition-colors cursor-pointer"
                  >
                    Execute Mathematical Anomaly Tests
                  </button>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  Per Law 1: <em>All audit testing logic — sample sizing, variance, anomaly detection, GL/TB variance — is deterministic, hard-coded math.</em> AI never decides an audit test or flag.
                </p>

                <div className="grid grid-cols-2 gap-3 text-xs pt-2">
                  <div className="p-3 rounded-lg bg-[#0F141E] border border-slate-800 space-y-1">
                    <span className="text-[10px] text-slate-400 uppercase font-bold">Benford's Law First-Digit Analysis</span>
                    <div className="font-semibold text-emerald-400">{biStats.benfordConformity}</div>
                    <p className="text-[11px] text-slate-400">First-digit frequency aligns with expected logarithmic distribution.</p>
                  </div>
                  <div className="p-3 rounded-lg bg-[#0F141E] border border-slate-800 space-y-1">
                    <span className="text-[10px] text-slate-400 uppercase font-bold">Statistical Outlier Detection (Z &gt; 2.5)</span>
                    <div className="font-semibold text-amber-400">{biStats.outlierZScoresCount} statistical outliers isolated</div>
                    <p className="text-[11px] text-slate-400">Transactions exceeding 2.5 standard deviations from median.</p>
                  </div>
                  <div className="p-3 rounded-lg bg-[#0F141E] border border-slate-800 space-y-1">
                    <span className="text-[10px] text-slate-400 uppercase font-bold">Weekend / Off-Hours Posting Detection</span>
                    <div className="font-semibold text-rose-400">{biStats.weekendTransactionsCount} non-business day postings</div>
                    <p className="text-[11px] text-slate-400">Flagged for out-of-band callback documentation review.</p>
                  </div>
                  <div className="p-3 rounded-lg bg-[#0F141E] border border-slate-800 space-y-1">
                    <span className="text-[10px] text-slate-400 uppercase font-bold">Round-Sum Concentration Check</span>
                    <div className="font-semibold text-white">{biStats.roundSumConcentration}</div>
                    <p className="text-[11px] text-slate-400">No systematic clustering at $50k or $100k limit boundaries.</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: 5-PART OBSERVATION / FINDINGS */}
          {activeTab === 'findings' && (
            <div className="space-y-5">
              <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/25 text-amber-200 text-xs">
                <strong className="block mb-0.5">Audit Standard Five-Part Observation Structure</strong>
                Observations logged here remain in Fieldwork status until the final Audit Report is issued, after which they graduate into the persistent Division Observations & Corrective Action Register.
              </div>

              <div className="p-5 rounded-xl bg-[#141B26] border border-slate-800 space-y-4 text-xs">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <span className="font-bold text-white text-sm">Draft Fieldwork Observation</span>
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400 text-xs">Severity:</span>
                    {(['critical', 'high', 'medium', 'low'] as const).map((sev) => (
                      <button
                        key={sev}
                        type="button"
                        onClick={() => setObsSeverity(sev)}
                        className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase transition-all cursor-pointer ${
                          obsSeverity === sev
                            ? sev === 'critical'
                              ? 'bg-rose-500 text-white'
                              : sev === 'high'
                              ? 'bg-amber-500 text-slate-950'
                              : 'bg-teal-500 text-slate-950'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {sev}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="text-[10px] font-bold uppercase text-teal-400 block mb-1">
                      1. Condition (What Was Found)
                    </label>
                    <textarea
                      rows={2}
                      value={obsCondition}
                      onChange={(e) => setObsCondition(e.target.value)}
                      className="w-full px-3 py-2 bg-[#0F141E] border border-slate-700 rounded-lg text-white"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold uppercase text-teal-400 block mb-1">
                      2. Criteria (What Policy / Standard Requires)
                    </label>
                    <textarea
                      rows={2}
                      value={obsCriteria}
                      onChange={(e) => setObsCriteria(e.target.value)}
                      className="w-full px-3 py-2 bg-[#0F141E] border border-slate-700 rounded-lg text-white"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold uppercase text-teal-400 block mb-1">
                      3. Cause (Root Cause Analysis)
                    </label>
                    <textarea
                      rows={2}
                      value={obsCause}
                      onChange={(e) => setObsCause(e.target.value)}
                      className="w-full px-3 py-2 bg-[#0F141E] border border-slate-700 rounded-lg text-white"
                    />
                  </div>

                  {/* Impact in Cinnabar / Amber */}
                  <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30">
                    <label className="text-[10px] font-bold uppercase text-rose-400 block mb-1">
                      4. Impact (Exposure & Risk — Cinnabar Discipline)
                    </label>
                    <textarea
                      rows={2}
                      value={obsImpact}
                      onChange={(e) => setObsImpact(e.target.value)}
                      className="w-full px-3 py-2 bg-[#0F141E] border border-rose-500/40 rounded-lg text-white"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold uppercase text-teal-400 block mb-1">
                      5. Recommendation (Corrective Action Requirement)
                    </label>
                    <textarea
                      rows={2}
                      value={obsRecommendation}
                      onChange={(e) => setObsRecommendation(e.target.value)}
                      className="w-full px-3 py-2 bg-[#0F141E] border border-slate-700 rounded-lg text-white"
                    />
                  </div>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    onClick={handleCreateObservationSubmit}
                    className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-colors cursor-pointer"
                  >
                    Commit Observation to Fieldwork Findings
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: MAKER-CHECKER SIGN-OFF */}
          {activeTab === 'signoff' && (
            <div className="space-y-5">
              <div className="p-4 rounded-xl bg-[#141B26] border border-slate-800 space-y-3">
                <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                  Working Paper Maker-Checker Sign-off & Audit Trail
                </h3>
                <p className="text-xs text-slate-400">
                  Dual digital sign-off is required prior to promoting working papers into the formal engagement review gate.
                </p>

                <div className="grid grid-cols-2 gap-4 text-xs pt-2">
                  <div className="p-4 rounded-xl bg-[#0F141E] border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] uppercase font-bold text-slate-400">Preparer (In-Charge)</span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300">
                        SIGNED
                      </span>
                    </div>
                    <div className="font-semibold text-white">{assignedAuditor}</div>
                    <span className="text-[10px] text-slate-400 block">Signed: 2026-09-08 14:22 UTC</span>
                  </div>

                  <div className="p-4 rounded-xl bg-[#0F141E] border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] uppercase font-bold text-slate-400">Audit Lead / Reviewer</span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          reviewerSigned
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : 'bg-amber-500/20 text-amber-300'
                        }`}
                      >
                        {reviewerSigned ? 'REVIEWED & APPROVED' : 'PENDING REVIEW'}
                      </span>
                    </div>
                    <div className="font-semibold text-white">{reviewerLead}</div>
                    <button
                      onClick={() => setReviewerSigned(!reviewerSigned)}
                      className="text-xs text-teal-400 underline cursor-pointer mt-1"
                    >
                      {reviewerSigned ? 'Revoke Reviewer Sign-off' : 'Affix Digital Review Seal'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-[#0E131C] flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-slate-400">
            <span>Result: DEA <strong className={deaStatus === 'Effective' ? 'text-emerald-400' : 'text-rose-400'}>{deaStatus}</strong></span>
            <span>·</span>
            <span>OET <strong className={oetDerivedStatus === 'Effective' ? 'text-emerald-400' : 'text-rose-400'}>{oetDerivedStatus}</strong></span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleSaveAll}
              className="px-5 py-2 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 text-xs font-bold transition-all shadow-md shadow-teal-500/20 cursor-pointer"
            >
              Save Working Paper & Update Matrix
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
