import React, { useState } from 'react';
import {
  X,
  FileText,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Send,
  Users,
  Layers,
  ChevronRight,
  Sparkles,
  Download,
  Printer,
  Check,
  Building,
  Target,
  BarChart3,
  Sliders,
  MessageSquare,
  BadgeCheck,
  FileCheck,
  Plus,
  FolderOpen,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { AuditControlItem, AuditWorkpaper, Person, StepStatus } from '../../types';
import { WorkingPaperWorkbenchModal } from './WorkingPaperWorkbenchModal';
import { NewWorkingPaperModal } from './NewWorkingPaperModal';

export function AuditFileModal() {
  const {
    selectedAuditForModal,
    setSelectedAuditForModal,
    scopedEntityForAudit,
    toggleAuditStep,
    issueAuditReport,
    departments,
    activeUser,
    people,
    setReviewDrawerOpen,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'overview' | 'controls' | 'workpapers' | 'observations' | 'report'>('overview');
  const [executiveOpinion, setExecutiveOpinion] = useState<'Satisfactory' | 'Needs Improvement' | 'Unsatisfactory'>('Needs Improvement');
  const [reportSummary, setReportSummary] = useState(
    'Based on the audit procedures performed, the internal control environment requires improvement due to documented exceptions in customer identification sign-offs and biometric authentication failover controls. Corrective actions have been agreed upon with divisional leadership.'
  );
  const [isIssuing, setIsIssuing] = useState(false);

  // Workbench & New Working Paper Modals
  const [workbenchControl, setWorkbenchControl] = useState<AuditControlItem | null>(null);
  const [newWpModalOpen, setNewWpModalOpen] = useState(false);

  // Tagged Team Members from Universe
  const [taggedUsers, setTaggedUsers] = useState<Person[]>(() => {
    if (!selectedAuditForModal) return [];
    const lead = people.find((p) => p.name === selectedAuditForModal.leadAuditorName) || people[0];
    const others = people.filter((p) => p.id !== lead?.id).slice(0, 2);
    return [lead, ...others].filter(Boolean) as Person[];
  });

  if (!selectedAuditForModal) return null;
  const audit = selectedAuditForModal;

  // Local Controls State for live updates
  const [localControls, setLocalControls] = useState<AuditControlItem[]>(() => {
    return audit.controlsList && audit.controlsList.length > 0
      ? audit.controlsList
      : [
          {
            id: 'ctrl_01',
            code: 'CTRL-01',
            name: 'Mandatory Customer Identification Verification (CIP)',
            objective: 'Ensure government ID and SSN match prior to facility approval.',
            type: 'Preventive',
            frequency: 'Automated Real-time',
            owner: audit.leadAuditorName,
            assignedAuditor: audit.leadAuditorName,
            deaStatus: 'Effective',
            deaNotes: 'Design walkthrough validated automated API call to LexisNexis.',
            oetStatus: 'Effective',
            sampleSize: audit.sampleSize || 25,
            sampleExceptions: 0,
            oetNotes: 'All sample files verified without discrepancies.',
          },
          {
            id: 'ctrl_02',
            code: 'CTRL-02',
            name: 'Maker-Checker Supervisor Checklist Verification',
            objective: 'Ensure senior loan officer signs off on exceptions before disbursement.',
            type: 'Detective',
            frequency: 'Daily',
            owner: audit.leadAuditorName,
            assignedAuditor: audit.leadAuditorName,
            deaStatus: 'Ineffective',
            deaNotes: 'Design flaw: System allows supervisor bypass during network latency.',
            oetStatus: 'Ineffective',
            sampleSize: audit.sampleSize || 25,
            sampleExceptions: audit.exceptionsCount || 2,
            oetNotes: 'Documented exceptions identified during substantive testing.',
          },
        ];
  });

  // Local Working Papers State
  const [localWorkpapers, setLocalWorkpapers] = useState<AuditWorkpaper[]>(() => {
    return audit.workpapersList && audit.workpapersList.length > 0
      ? audit.workpapersList
      : [
          {
            id: 'wp_01',
            ref: 'WP-101',
            name: 'Strategic Scoping, Mandate & SIRA Evaluation',
            lead: audit.leadAuditorName,
            status: 'Signed off',
            testedSampleCount: 0,
            exceptionsCount: 0,
            signoffLead: 'Marcus Vance (CAE)',
            signoffDate: '2026-08-20',
            notes: 'Scoping charter approved by Internal Audit Leadership.',
          },
          {
            id: 'wp_02',
            ref: 'WP-102',
            name: 'Design Effectiveness Assessment (DEA) Walkthrough Matrix',
            lead: audit.leadAuditorName,
            status: 'Signed off',
            testedSampleCount: audit.controlsTotal || 14,
            exceptionsCount: 2,
            signoffLead: 'Marcus Vance (CAE)',
            signoffDate: '2026-08-25',
            notes: 'DEA Walkthrough completed across all 14 identified key controls.',
          },
          {
            id: 'wp_03',
            ref: 'WP-103',
            name: 'Operating Effectiveness Testing (OET) & Substantive Sampling',
            lead: audit.leadAuditorName,
            status: 'In Review',
            testedSampleCount: audit.sampleSize || 25,
            exceptionsCount: audit.exceptionsCount || 2,
            notes: 'Substantive attribute testing completed with 2 exceptions noted.',
          },
        ];
  });

  // Tagged Team Members State
  const [leadAuditorName, setLeadAuditorName] = useState(audit.leadAuditorName);
  const [reviewerName, setReviewerName] = useState(audit.reviewerName || 'Devraj Mehta (Audit Lead)');
  const [assignedStaff, setAssignedStaff] = useState<string[]>(
    audit.assignedTeam || ['Tariq Al-Mansoor', 'Riya Anand']
  );

  // Findings related to this audit
  const relatedObservations = departments.flatMap((d) =>
    d.observations.filter(
      (o) => String(o.reportId) === String(audit.id) || o.report.toLowerCase().includes(audit.title.toLowerCase().slice(0, 15))
    )
  );

  const controls = audit.controlsList || [
    {
      id: 'ctrl_01',
      code: 'CTRL-01',
      name: 'Mandatory Customer Identification Verification (CIP)',
      objective: 'Ensure government ID and SSN match prior to facility approval.',
      type: 'Preventive',
      frequency: 'Automated Real-time',
      owner: audit.leadAuditorName,
      deaStatus: 'Effective',
      deaNotes: 'Design walkthrough validated automated API call to LexisNexis.',
      oetStatus: 'Effective',
      sampleSize: audit.sampleSize,
      sampleExceptions: 0,
      oetNotes: 'All sample files verified without discrepancies.',
    },
    {
      id: 'ctrl_02',
      code: 'CTRL-02',
      name: 'Maker-Checker Supervisor Checklist Verification',
      objective: 'Ensure senior loan officer signs off on exceptions before disbursement.',
      type: 'Detective',
      frequency: 'Daily',
      owner: audit.leadAuditorName,
      deaStatus: 'Ineffective',
      deaNotes: 'Design flaw: System allows supervisor bypass during network latency.',
      oetStatus: 'Ineffective',
      sampleSize: audit.sampleSize,
      sampleExceptions: audit.exceptionsCount || 2,
      oetNotes: 'Documented exceptions identified during substantive testing.',
    },
  ];

  const workpapers = audit.workpapersList || [
    {
      id: 'wp_01',
      ref: 'WP-101',
      name: 'Strategic Scoping, Mandate & SIRA Evaluation',
      lead: audit.leadAuditorName,
      status: 'Signed off',
      testedSampleCount: 0,
      exceptionsCount: 0,
      signoffLead: 'Marcus Vance (CAE)',
      signoffDate: '2026-08-20',
      notes: 'Scoping charter approved by Internal Audit Leadership.',
    },
    {
      id: 'wp_02',
      ref: 'WP-102',
      name: 'Design Effectiveness Assessment (DEA) Walkthrough Matrix',
      lead: audit.leadAuditorName,
      status: 'Signed off',
      testedSampleCount: audit.controlsTotal || 14,
      exceptionsCount: 2,
      signoffLead: 'Marcus Vance (CAE)',
      signoffDate: '2026-08-25',
      notes: 'DEA Walkthrough completed across all 14 identified key controls.',
    },
    {
      id: 'wp_03',
      ref: 'WP-103',
      name: 'Operating Effectiveness Testing (OET) & Substantive Sampling',
      lead: audit.leadAuditorName,
      status: audit.steps.fieldwork === 'reviewed' ? 'Reviewed' : 'In Review',
      testedSampleCount: audit.sampleSize,
      exceptionsCount: audit.exceptionsCount,
      signoffLead: 'Devraj Mehta (Reviewer)',
      notes: 'Statistical sample testing performed using Monetary Unit Sampling (MUS).',
    },
    {
      id: 'wp_04',
      ref: 'WP-104',
      name: 'Exceptions Root Cause Analysis & Management Action Plan (CAP)',
      lead: audit.leadAuditorName,
      status: audit.reportIssued ? 'Signed off' : 'Draft',
      testedSampleCount: audit.exceptionsCount,
      exceptionsCount: audit.exceptionsCount,
      notes: 'Draft findings reviewed with business owner.',
    },
  ];

  const handleFinalizeAndIssue = () => {
    setIsIssuing(true);
    setTimeout(() => {
      issueAuditReport(audit.id, {
        opinion: executiveOpinion,
        summary: reportSummary,
        distribution: ['Board Audit Committee', 'Chief Risk Officer', 'Divisional Executive'],
      });
      setIsIssuing(false);
    }, 800);
  };

  const getStepBadge = (stepStatus?: StepStatus) => {
    if (stepStatus === 'reviewed') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
          <CheckCircle2 className="w-3 h-3" /> Reviewed
        </span>
      );
    }
    if (stepStatus === 'in_progress') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-500/15 text-amber-300 border border-amber-500/30">
          <Clock className="w-3 h-3 animate-spin" /> In Progress
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-medium bg-slate-800 text-slate-400">
        Not Started
      </span>
    );
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 backdrop-blur-sm p-4 animate-in fade-in duration-200"
      onClick={() => setSelectedAuditForModal(null)}
    >
      <div
        className="w-full max-w-5xl bg-[#111622] text-slate-100 rounded-2xl border border-slate-700/80 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="px-6 py-5 border-b border-slate-800 bg-gradient-to-r from-[#17202F] via-[#141B28] to-[#111622] flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-teal-500/15 text-teal-300 border border-teal-500/30">
                Official Audit File
              </span>
              <span className="text-xs text-slate-400">· {audit.dept}</span>
              {audit.reportIssued ? (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/35 flex items-center gap-1">
                  <BadgeCheck className="w-3 h-3" /> Final Report Issued & Sign-off Granted
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-500/15 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                  <Clock className="w-3 h-3" /> Active Engagement ({audit.stage})
                </span>
              )}
            </div>
            <h2 className="text-xl font-semibold text-white tracking-tight">
              {audit.title}
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setReviewDrawerOpen(true)}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-teal-300 border border-teal-500/30 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
              title="Open Review Comments Popout"
            >
              <MessageSquare className="w-3.5 h-3.5 text-teal-400" />
              Review Comments Popout
            </button>
            <button
              onClick={() => setSelectedAuditForModal(null)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/70 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation (Constituent Report Generation Tab Included!) */}
        <div className="px-6 border-b border-slate-800 bg-[#131924] flex items-center gap-1 overflow-x-auto">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-3 text-xs font-medium border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'overview'
                ? 'border-teal-400 text-teal-300 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            Scoping & SIRA Charter
          </button>
          <button
            onClick={() => setActiveTab('controls')}
            className={`px-4 py-3 text-xs font-medium border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'controls'
                ? 'border-teal-400 text-teal-300 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            Controls Matrix (DEA & OET)
            <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-800 text-slate-300">
              {audit.controlsTested || 14}/{audit.controlsTotal || 14}
            </span>
          </button>
          <button
            onClick={() => setActiveTab('workpapers')}
            className={`px-4 py-3 text-xs font-medium border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'workpapers'
                ? 'border-teal-400 text-teal-300 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCheck className="w-3.5 h-3.5" />
            Working Papers
            <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-800 text-slate-300">
              {workpapers.length}
            </span>
          </button>
          <button
            onClick={() => setActiveTab('observations')}
            className={`px-4 py-3 text-xs font-medium border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'observations'
                ? 'border-teal-400 text-teal-300 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            Fieldwork Observations
            <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-amber-500/20 text-amber-300">
              {relatedObservations.length}
            </span>
          </button>
          <button
            onClick={() => setActiveTab('report')}
            className={`px-4 py-3 text-xs font-medium border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'report'
                ? 'border-emerald-400 text-emerald-300 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5 text-emerald-400" />
            Audit Report & Final Issuance
            {audit.reportIssued && (
              <Check className="w-3 h-3 text-emerald-400 stroke-[3]" />
            )}
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 overflow-y-auto custom-scrollbar flex-1 space-y-6">
          {/* TAB 1: OVERVIEW & SCOPING */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Top Key Metrics */}
              <div className="grid grid-cols-4 gap-3">
                <div className="p-3.5 rounded-xl bg-[#151C28] border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Lead Auditor</span>
                  <div className="text-sm font-semibold text-white">{audit.leadAuditorName}</div>
                  <span className="text-[10px] text-teal-400">Independent In-Charge</span>
                </div>
                <div className="p-3.5 rounded-xl bg-[#151C28] border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Timeframe</span>
                  <div className="text-sm font-semibold text-white">{audit.start} – {audit.end}</div>
                  <span className="text-[10px] text-slate-400">Scheduled Execution Window</span>
                </div>
                <div className="p-3.5 rounded-xl bg-[#151C28] border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Sampling Engine</span>
                  <div className="text-sm font-semibold text-white">{audit.sampleSize} Sample Items</div>
                  <span className="text-[10px] text-teal-400">95% Statistical Confidence (MUS)</span>
                </div>
                <div className="p-3.5 rounded-xl bg-[#151C28] border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Exceptions Identified</span>
                  <div className="text-sm font-semibold text-amber-400">{audit.exceptionsCount || relatedObservations.length} Findings</div>
                  <span className="text-[10px] text-amber-400/80">Pending Final Report Issuance</span>
                </div>
              </div>

              {/* SIRA - Strategic Inherent Risk Assessment Scorecard */}
              <div className="p-5 rounded-xl bg-[#141B26] border border-slate-800/90 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Target className="w-4 h-4 text-teal-400" />
                    <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
                      Strategic Inherent Risk Assessment (SIRA) Scorecard
                    </h3>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-400">Composite Inherent Score:</span>
                    <span className="px-2.5 py-0.5 rounded-md text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      {audit.siraScore?.composite || 88} / 100 (HIGH RISK)
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-4 gap-3 text-xs">
                  <div className="p-3 rounded-lg bg-[#0F141E] border border-slate-800">
                    <div className="flex justify-between text-slate-400 mb-1">
                      <span>Financial Exposure</span>
                      <strong className="text-white">{audit.siraScore?.financial || 4}/5</strong>
                    </div>
                    <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-amber-500 rounded-full" style={{ width: `${((audit.siraScore?.financial || 4) / 5) * 100}%` }} />
                    </div>
                  </div>
                  <div className="p-3 rounded-lg bg-[#0F141E] border border-slate-800">
                    <div className="flex justify-between text-slate-400 mb-1">
                      <span>Regulatory Scrutiny</span>
                      <strong className="text-rose-400">{audit.siraScore?.regulatory || 5}/5</strong>
                    </div>
                    <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-rose-500 rounded-full" style={{ width: `${((audit.siraScore?.regulatory || 5) / 5) * 100}%` }} />
                    </div>
                  </div>
                  <div className="p-3 rounded-lg bg-[#0F141E] border border-slate-800">
                    <div className="flex justify-between text-slate-400 mb-1">
                      <span>Operational Complexity</span>
                      <strong className="text-white">{audit.siraScore?.operational || 4}/5</strong>
                    </div>
                    <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-teal-500 rounded-full" style={{ width: `${((audit.siraScore?.operational || 4) / 5) * 100}%` }} />
                    </div>
                  </div>
                  <div className="p-3 rounded-lg bg-[#0F141E] border border-slate-800">
                    <div className="flex justify-between text-slate-400 mb-1">
                      <span>Reputational Impact</span>
                      <strong className="text-white">{audit.siraScore?.reputational || 4}/5</strong>
                    </div>
                    <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-indigo-500 rounded-full" style={{ width: `${((audit.siraScore?.reputational || 4) / 5) * 100}%` }} />
                    </div>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-[#0E131C] border border-slate-800/80 text-xs text-slate-300">
                  <span className="font-semibold text-teal-400 mr-2">SIRA Methodology Rationale:</span>
                  {audit.siraScore?.rationale || 'High consumer portfolio volume subject to continuous OCC and CFPB examination. Quantitative weighting enforces annual audit frequency.'}
                </div>
              </div>

              {/* Scope Charter */}
              <div className="p-5 rounded-xl bg-[#141B26] border border-slate-800 space-y-3">
                <h3 className="text-xs font-semibold text-white uppercase tracking-wider flex items-center gap-2">
                  <FileText className="w-4 h-4 text-teal-400" />
                  Audit Scope & Objective Summary
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {audit.scopeSummary}
                </p>
                <div className="flex items-center gap-4 text-xs text-slate-400 pt-2 border-t border-slate-800">
                  <span>Linked Auditable Entity: <strong className="text-slate-200">{scopedEntityForAudit?.name || audit.entityId}</strong></span>
                  <span>Regulatory Tier: <strong className="text-slate-200">{scopedEntityForAudit?.regulatoryTier || 'Tier 1 - CFPB & OCC'}</strong></span>
                </div>
              </div>

              {/* Tagged Universe Personnel & Audit Team */}
              <div className="p-5 rounded-xl bg-[#141B26] border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xs font-semibold text-white uppercase tracking-wider flex items-center gap-2">
                      <Users className="w-4 h-4 text-teal-400" />
                      Assigned Audit Team & Tagged Universe Personnel
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      All auditors working across this universe can be tagged to this audit for testing and reviews.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <select
                      onChange={(e) => {
                        if (!e.target.value) return;
                        const person = people.find((p) => p.id === e.target.value);
                        if (person && !taggedUsers.some((u) => u.id === person.id)) {
                          setTaggedUsers((prev) => [...prev, person]);
                          showToast(`Tagged ${person.name} (${person.roleTitle}) to audit`);
                        }
                        e.target.value = '';
                      }}
                      defaultValue=""
                      className="px-2.5 py-1.5 rounded-lg bg-[#0F141E] border border-slate-700 text-xs text-teal-300 focus:outline-none cursor-pointer"
                    >
                      <option value="" disabled>+ Tag Universe User...</option>
                      {people.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} — {p.roleTitle}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2.5">
                  {taggedUsers.map((u) => (
                    <div
                      key={u.id}
                      className="p-3 rounded-lg bg-[#0F141E] border border-slate-800 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-full bg-teal-500/20 border border-teal-500/40 text-teal-300 font-bold text-xs flex items-center justify-center">
                          {u.initials || u.name.slice(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <div className="text-xs font-semibold text-white">{u.name}</div>
                          <div className="text-[10px] text-slate-400">{u.roleTitle}</div>
                        </div>
                      </div>
                      {u.name !== audit.leadAuditorName && (
                        <button
                          onClick={() => {
                            setTaggedUsers((prev) => prev.filter((tu) => tu.id !== u.id));
                            showToast(`Untagged ${u.name}`);
                          }}
                          className="text-slate-500 hover:text-rose-400 text-xs cursor-pointer p-1"
                          title="Remove user tag"
                        >
                          ✕
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Engagement Step Progression Bar (Auto-updates based on real working papers / documentation) */}
              <div className="p-5 rounded-xl bg-[#141B26] border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
                      Governance Phase Gates & Sign-offs
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      Auto-computes from real working papers, population testing, and executive report status.
                    </p>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-teal-500/10 text-teal-300 border border-teal-500/30">
                    REAL-TIME GOVERNANCE GATE
                  </span>
                </div>

                <div className="grid grid-cols-4 gap-2.5">
                  {[
                    {
                      key: 'planning',
                      name: 'Planning & SIRA',
                      status: audit.scopeSummary ? 'reviewed' : 'in_progress',
                      detail: audit.scopeSummary ? 'Scoping & SIRA Scored' : 'Charter in Progress',
                      targetTab: 'overview',
                    },
                    {
                      key: 'fieldwork',
                      name: 'Fieldwork (DEA & OET)',
                      status:
                        audit.controlsTested >= (audit.controlsTotal || 14) && audit.controlsTested > 0
                          ? 'reviewed'
                          : audit.controlsTested > 0
                          ? 'in_progress'
                          : 'not_started',
                      detail:
                        audit.controlsTested >= (audit.controlsTotal || 14) && audit.controlsTested > 0
                          ? 'All Controls Tested'
                          : `${audit.controlsTested || 0}/${audit.controlsTotal || 14} Controls Tested`,
                      targetTab: 'controls',
                    },
                    {
                      key: 'review',
                      name: 'Maker-Checker Review',
                      status:
                        audit.controlsTested >= (audit.controlsTotal || 14) && audit.controlsTested > 0
                          ? 'reviewed'
                          : audit.controlsTested > 0
                          ? 'in_progress'
                          : 'not_started',
                      detail: 'Working Papers Reviewed',
                      targetTab: 'workpapers',
                    },
                    {
                      key: 'signoff',
                      name: 'Report & Issuance',
                      status: audit.reportIssued ? 'reviewed' : 'in_progress',
                      detail: audit.reportIssued ? 'Sealed by CAE & Lead' : 'Awaiting Final Issuance',
                      targetTab: 'report',
                    },
                  ].map((phase) => (
                    <div
                      key={phase.key}
                      onClick={() => setActiveTab(phase.targetTab as any)}
                      className="p-3.5 rounded-xl bg-[#0F141E] border border-slate-800 hover:border-teal-500/50 hover:bg-[#131A26] transition-all cursor-pointer flex flex-col justify-between group"
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-xs font-semibold text-slate-200 group-hover:text-teal-300 transition-colors">
                          {phase.name}
                        </span>
                        {getStepBadge(phase.status as StepStatus)}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">{phase.detail}</div>
                      <div className="text-[10px] text-teal-400/80 mt-2 flex items-center gap-1 opacity-60 group-hover:opacity-100 transition-opacity">
                        <span>Go to {phase.targetTab} →</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: CONTROLS MATRIX (DEA & OET) */}
          {activeTab === 'controls' && (
            <div className="space-y-5">
              {/* DEA & OET Executive Summary Banner */}
              <div className="grid grid-cols-2 gap-4">
                {/* DEA Card */}
                <div className="p-4 rounded-xl bg-gradient-to-br from-[#16212D] to-[#121A24] border border-teal-500/30 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-teal-300 uppercase tracking-wider">
                      Design Effectiveness Assessment (DEA)
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-teal-500/20 text-teal-300 border border-teal-500/30">
                      {audit.dea?.status?.toUpperCase() || 'COMPLETED'}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 text-xs">
                    <div>Effective: <strong className="text-emerald-400">{audit.dea?.effective || 12}</strong></div>
                    <div>Ineffective: <strong className="text-rose-400">{audit.dea?.ineffective || 2}</strong></div>
                    <div>Total Evaluated: <strong className="text-white">{audit.controlsTotal || 14}</strong></div>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    {audit.dea?.notes || 'Walkthrough completed with 1st line control owners to test preventative logic and segregation of duties.'}
                  </p>
                </div>

                {/* OET Card */}
                <div className="p-4 rounded-xl bg-gradient-to-br from-[#201D28] to-[#161522] border border-indigo-500/30 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-indigo-300 uppercase tracking-wider">
                      Operating Effectiveness Testing (OET)
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                      {audit.oet?.status?.toUpperCase() || 'IN PROGRESS'}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 text-xs">
                    <div>Effective: <strong className="text-emerald-400">{audit.oet?.effective || 10}</strong></div>
                    <div>Ineffective / Exceptions: <strong className="text-amber-400">{audit.oet?.ineffective || 2}</strong></div>
                    <div>Sample Tested: <strong className="text-white">{audit.sampleSize} items</strong></div>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    {audit.oet?.notes || 'Substantive attribute sampling to confirm controls operated consistently across the audit period.'}
                  </p>
                </div>
              </div>

              {/* Detailed Controls Matrix Table */}
              <div className="rounded-xl border border-slate-800 bg-[#141B26] overflow-hidden">
                <div className="px-5 py-3 border-b border-slate-800 flex items-center justify-between bg-[#10151E]">
                  <div>
                    <span className="text-xs font-semibold text-slate-200">Key Controls Evaluation Register</span>
                    <span className="text-xs text-slate-400 ml-2">({localControls.length} controls mapped)</span>
                  </div>
                  <button
                    onClick={() => setNewWpModalOpen(true)}
                    className="px-3 py-1.5 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-all shadow-md shadow-teal-500/20 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>+ Add Working Paper / Control Test</span>
                  </button>
                </div>
                <div className="divide-y divide-slate-800/80">
                  {localControls.map((ctrl) => (
                    <div
                      key={ctrl.id}
                      className="p-4 hover:bg-slate-800/40 transition-colors space-y-2.5 cursor-pointer"
                      onClick={() => setWorkbenchControl(ctrl)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-slate-800 text-teal-300 border border-slate-700">
                            {ctrl.code}
                          </span>
                          <span className="text-xs font-semibold text-white">{ctrl.name}</span>
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-400">
                            {ctrl.type} · {ctrl.frequency}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                              ctrl.deaStatus === 'Effective'
                                ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                                : 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                            }`}
                          >
                            DEA: {ctrl.deaStatus}
                          </span>
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                              ctrl.oetStatus === 'Effective'
                                ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                                : ctrl.oetStatus === 'Ineffective'
                                ? 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            OET: {ctrl.oetStatus}
                          </span>
                        </div>
                      </div>
                      <p className="text-xs text-slate-400 pl-1">{ctrl.objective}</p>
                      
                      <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
                        <div className="p-2 rounded bg-[#0F141E] border border-slate-800/60 text-slate-300">
                          <strong className="text-teal-400">DEA Walkthrough:</strong> {ctrl.deaNotes || 'Nominal design verification.'}
                        </div>
                        <div className="p-2 rounded bg-[#0F141E] border border-slate-800/60 text-slate-300">
                          <strong className="text-indigo-400">OET Sample Tested:</strong> {ctrl.sampleSize || 25} items (Exceptions: {ctrl.sampleExceptions || 0})
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-1">
                        <span className="text-[11px] text-slate-400">
                          Assigned Tester: <strong className="text-slate-200">{ctrl.assignedAuditor || ctrl.owner || audit.leadAuditorName}</strong>
                        </span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setWorkbenchControl(ctrl);
                          }}
                          className="px-3 py-1 rounded-lg bg-teal-500/15 hover:bg-teal-500/25 text-teal-300 border border-teal-500/40 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                        >
                          <FileCheck className="w-3.5 h-3.5" />
                          Open Working Paper Workbench & Test Vouchers →
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: AUTO-POPULATED WORKING PAPERS */}
          {activeTab === 'workpapers' && (
            <div className="space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
                    Constituent Working Papers Catalog
                  </h3>
                  <p className="text-xs text-slate-400">
                    Auto-populated audit documentation, sample testing evidence, and maker-checker sign-offs
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setNewWpModalOpen(true)}
                    className="px-3 py-1.5 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    + New Working Paper
                  </button>
                  <button
                    onClick={() => setReviewDrawerOpen(true)}
                    className="px-3 py-1.5 rounded-lg bg-teal-500/15 hover:bg-teal-500/25 text-teal-300 border border-teal-500/30 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    Review Notes
                  </button>
                </div>
              </div>

              <div className="space-y-3">
                {localWorkpapers.map((wp) => (
                  <div
                    key={wp.id}
                    className="p-4 rounded-xl bg-[#141B26] border border-slate-800 hover:border-slate-700 transition-all flex items-start justify-between gap-4"
                  >
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-slate-800 text-teal-300 border border-slate-700">
                          {wp.ref}
                        </span>
                        <span className="text-xs font-semibold text-white">{wp.name}</span>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                            wp.status === 'Signed off'
                              ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                              : wp.status === 'Reviewed'
                              ? 'bg-teal-500/15 text-teal-300 border border-teal-500/30'
                              : 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                          }`}
                        >
                          {wp.status}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 pl-1">{wp.notes}</p>
                      <div className="flex items-center gap-4 text-[11px] text-slate-400 pt-1 pl-1">
                        <span>Prepared By: <strong className="text-slate-200">{wp.lead}</strong></span>
                        {wp.signoffLead && (
                          <span>Sign-off: <strong className="text-teal-300">{wp.signoffLead}</strong> ({wp.signoffDate})</span>
                        )}
                        {wp.testedSampleCount > 0 && (
                          <span>Sample Tested: <strong className="text-slate-200">{wp.testedSampleCount}</strong></span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => {
                          const matchedCtrl = localControls.find((c) => c.code === wp.ref || wp.name.includes(c.code)) || localControls[0];
                          setWorkbenchControl(matchedCtrl);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-teal-500/15 hover:bg-teal-500/25 text-teal-300 border border-teal-500/30 text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5"
                      >
                        <FileCheck className="w-3.5 h-3.5" />
                        Inspect Working Paper
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: FIELDWORK OBSERVATIONS */}
          {activeTab === 'observations' && (
            <div className="space-y-5">
              <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/25 text-amber-200 text-xs leading-relaxed flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="font-semibold block mb-0.5">Governance Gate: Issue Promotion Rule</strong>
                  Observations identified during fieldwork remain classified as <em>Audit Draft Findings</em> until the final Audit Report is formally approved & issued. Once issued, findings automatically graduate into the <strong>Division Observations & Corrective Action Plan (CAP) Register</strong>.
                </div>
              </div>

              <div className="space-y-3">
                {relatedObservations.length === 0 ? (
                  <div className="p-8 text-center text-slate-400 text-xs">
                    No exceptions or draft observations logged for this engagement.
                  </div>
                ) : (
                  relatedObservations.map((obs) => (
                    <div key={obs.id} className="p-4 rounded-xl bg-[#141B26] border border-slate-800 space-y-2.5">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-2">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                              obs.severity === 'critical'
                                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                                : obs.severity === 'high'
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                : 'bg-teal-500/20 text-teal-300 border border-teal-500/30'
                            }`}
                          >
                            {obs.severity}
                          </span>
                          <span className="text-xs font-semibold text-white">{obs.title}</span>
                        </div>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                            obs.reportIssued
                              ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                              : 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                          }`}
                        >
                          {obs.reportIssued ? 'Promoted to Board Register' : 'Draft Fieldwork Finding'}
                        </span>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-[11px]">
                        <div className="p-2 rounded bg-[#0F141E] text-slate-300 border border-slate-800/60">
                          <strong className="text-slate-400">Root Cause:</strong> {obs.rootCause || 'Underlying process gap.'}
                        </div>
                        <div className="p-2 rounded bg-[#0F141E] text-slate-300 border border-slate-800/60">
                          <strong className="text-slate-400">Regulatory Impact:</strong> {obs.impact || 'Compliance scrutiny.'}
                        </div>
                      </div>

                      {obs.capActionPlan && (
                        <div className="p-2 rounded bg-[#0E131C] text-[11px] text-teal-300 border border-teal-900/30">
                          <strong className="text-teal-400">Agreed Management Action Plan (CAP):</strong> {obs.capActionPlan} (Owner: {obs.capOwner || obs.owner})
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* TAB 5: AUDIT REPORT GENERATION & FINAL ISSUANCE */}
          {activeTab === 'report' && (
            <div className="space-y-6">
              {audit.reportIssued ? (
                <div className="p-5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-200 flex items-start gap-3">
                  <BadgeCheck className="w-6 h-6 text-emerald-400 shrink-0" />
                  <div className="text-xs space-y-1">
                    <h4 className="font-bold text-sm text-emerald-300">
                      Final Audit Report Officially Issued & Archive Locked
                    </h4>
                    <p>
                      Issued on <strong>{audit.reportIssuedDate || '2026-09-11'}</strong> with digital sign-off from Chief Audit Executive Marcus Vance and Audit Lead {audit.leadAuditorName}.
                    </p>
                    <p className="text-[11px] opacity-90">
                      All {relatedObservations.length} observations from this audit have been promoted to the Division Observations & Corrective Action Register with active SLA tracking.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-xl bg-teal-500/10 border border-teal-500/30 text-teal-200 text-xs flex items-center justify-between">
                  <div>
                    <strong className="font-semibold block mb-0.5">Constituent Report Issuance Engine</strong>
                    <span>Review opinion, finalize executive narrative, and issue report to formalize observations into the Board Register.</span>
                  </div>
                  <button
                    onClick={handleFinalizeAndIssue}
                    disabled={isIssuing}
                    className="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold transition-all shadow-md shadow-emerald-500/20 cursor-pointer disabled:opacity-50 shrink-0"
                  >
                    {isIssuing ? 'Issuing Report & Promoting...' : 'Finalize & Issue Report'}
                  </button>
                </div>
              )}

              {/* Report Editor / Formal Preview */}
              <div className="rounded-xl border border-slate-700/80 bg-[#0F141E] p-6 space-y-5 text-xs">
                {/* Letterhead */}
                <div className="border-b border-slate-800 pb-4 flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-serif font-bold text-white tracking-wide">
                      MERIDIAN RETAIL BANK · INTERNAL AUDIT DIVISION
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      CONFIDENTIAL EXECUTIVE AUDIT REPORT · ISSUED UNDER IIA GLOBAL STANDARDS
                    </p>
                  </div>
                  <div className="text-right text-[11px] text-slate-400">
                    <div>Engagement Ref: <strong>AUD-2026-{audit.id}</strong></div>
                    <div>Date: <strong>{audit.reportIssuedDate || 'Draft For Sign-off'}</strong></div>
                  </div>
                </div>

                {/* Executive Opinion Selector */}
                <div className="space-y-2">
                  <label className="text-[11px] font-bold uppercase text-slate-400">Executive Audit Opinion Rating</label>
                  <div className="flex gap-3">
                    {(['Satisfactory', 'Needs Improvement', 'Unsatisfactory'] as const).map((op) => (
                      <button
                        key={op}
                        type="button"
                        onClick={() => setExecutiveOpinion(op)}
                        disabled={audit.reportIssued}
                        className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                          (audit.executiveOpinion || executiveOpinion) === op
                            ? op === 'Satisfactory'
                              ? 'bg-emerald-500 text-slate-950 ring-2 ring-emerald-400'
                              : op === 'Needs Improvement'
                              ? 'bg-amber-500 text-slate-950 ring-2 ring-amber-400'
                              : 'bg-rose-500 text-white ring-2 ring-rose-400'
                            : 'bg-[#151C28] text-slate-400 border border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        {op}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Executive Summary Narrative */}
                <div className="space-y-2">
                  <label className="text-[11px] font-bold uppercase text-slate-400">Executive Summary & Audit Scope</label>
                  <textarea
                    rows={4}
                    disabled={audit.reportIssued}
                    value={audit.reportSummary || reportSummary}
                    onChange={(e) => setReportSummary(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[#141A25] border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
                  />
                </div>

                {/* Digital Sign-off Signatures */}
                <div className="pt-4 border-t border-slate-800 grid grid-cols-2 gap-6">
                  <div className="p-3 rounded-lg bg-[#141A25] border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">Lead Engagement Auditor</span>
                    <div className="font-serif text-sm font-semibold text-white">{audit.leadAuditorName}</div>
                    <span className="text-[10px] text-emerald-400">Digital Signature Verified</span>
                  </div>
                  <div className="p-3 rounded-lg bg-[#141A25] border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">Chief Audit Executive (CAE)</span>
                    <div className="font-serif text-sm font-semibold text-white">Marcus Vance, CIA, CRMA</div>
                    <span className="text-[10px] text-emerald-400">Digital Sign-off Seal Affixed</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 border-t border-slate-800 bg-[#10151E] flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <Building className="w-3.5 h-3.5 text-teal-400" />
            <span>Meridian Retail Bank Assurance Architecture</span>
          </div>
          <button
            onClick={() => setSelectedAuditForModal(null)}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white transition-colors cursor-pointer"
          >
            Close Audit File (Esc)
          </button>
        </div>
      </div>

      {/* WORKING PAPER WORKBENCH (DEA / OET / Law 3 Population Gateway & Sample Vouchers) */}
      {workbenchControl && (
        <WorkingPaperWorkbenchModal
          control={workbenchControl}
          audit={audit}
          onClose={() => setWorkbenchControl(null)}
          onSaveControl={(updated) => {
            setLocalControls((prev) =>
              prev.map((c) => (c.id === updated.id ? updated : c))
            );
            setWorkbenchControl(null);
            showToast(`Saved working paper and testing vouchers for ${updated.code}`);
          }}
          onCreateObservation={(obs) => {
            showToast(`Draft observation created: ${obs.title}. Retained in draft until final report issuance.`);
          }}
        />
      )}

      {/* NEW WORKING PAPER CREATION MODAL */}
      {newWpModalOpen && (
        <NewWorkingPaperModal
          audit={audit}
          onClose={() => setNewWpModalOpen(false)}
          onAddControl={(newCtrl) => {
            setLocalControls((prev) => [newCtrl, ...prev]);
            setLocalWorkpapers((prev) => [
              {
                id: `wp_${Date.now()}`,
                ref: newCtrl.code,
                name: newCtrl.name,
                lead: audit.leadAuditorName,
                status: 'Draft',
                testedSampleCount: 0,
                exceptionsCount: 0,
                notes: 'Newly added working paper testing matrix.',
              },
              ...prev,
            ]);
            setNewWpModalOpen(false);
            showToast(`Added working paper for ${newCtrl.code}`);
          }}
        />
      )}
    </div>
  );
}
