import React, { useState } from 'react';
import { X, Plus, ShieldCheck, FileCheck, Users } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { AuditControlItem, AuditEngagement, SamplingMethod } from '../../types';

interface NewWorkingPaperModalProps {
  audit: AuditEngagement;
  onClose: () => void;
  onAddControl: (newControl: AuditControlItem) => void;
}

export const NewWorkingPaperModal: React.FC<NewWorkingPaperModalProps> = ({
  audit,
  onClose,
  onAddControl,
}) => {
  const { people, showToast } = useApp();

  const [testType, setTestType] = useState<'DEA' | 'OET' | 'Both'>('Both');
  const [code, setCode] = useState(`CTRL-${(audit.controlsTotal || 14) + 1}`);
  const [name, setName] = useState('');
  const [objective, setObjective] = useState('');
  const [type, setType] = useState<'Preventive' | 'Detective' | 'Corrective'>('Preventive');
  const [frequency, setFrequency] = useState<
    'Automated Real-time' | 'Daily' | 'Weekly' | 'Monthly' | 'Quarterly' | 'Annual'
  >('Daily');
  const [owner, setOwner] = useState(audit.leadAuditorName);
  const [assignedAuditor, setAssignedAuditor] = useState(audit.leadAuditorName);
  const [samplingMethod, setSamplingMethod] = useState<SamplingMethod>('MUS');
  const [sampleSize, setSampleSize] = useState(25);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newControl: AuditControlItem = {
      id: `ctrl_${Date.now()}`,
      code: code.trim().toUpperCase(),
      name: name.trim(),
      objective: objective.trim() || 'Validate operational compliance against established risk threshold.',
      type,
      frequency,
      owner,
      assignedAuditor,
      deaStatus: 'Pending Walkthrough',
      deaNotes: 'Initial design walkthrough scheduled.',
      oetStatus: 'Not Started',
      sampleSize,
      sampleExceptions: 0,
      samplingMethod,
      samplingEntryMode: 'Algorithmic',
      populationGate: {
        status: 'UNVERIFIED',
        filename: `${audit.dept.replace(/\s+/g, '_')}_Population_Voucher_Extract.csv`,
        totalRecords: 1250,
        totalAmount: 14500000,
      },
      sampleItems: [],
    };

    onAddControl(newControl);
    showToast(`Added new working paper & control test ${newControl.code}: ${newControl.name}`);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-[85] flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg bg-[#111722] text-slate-100 rounded-2xl border border-slate-700 shadow-2xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-6 py-4 border-b border-slate-800 bg-gradient-to-r from-[#17202F] to-[#111722] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Plus className="w-5 h-5 text-teal-400" />
            <h3 className="font-semibold text-white text-base">New Working Paper (DEA / OET)</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-semibold text-slate-300 block mb-1">Control Reference Code</label>
              <input
                type="text"
                required
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="w-full px-3 py-2 bg-[#0C1018] border border-slate-700 rounded-lg text-white font-mono text-xs focus:border-teal-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="text-[11px] font-semibold text-slate-300 block mb-1">Testing Scope</label>
              <select
                value={testType}
                onChange={(e) => setTestType(e.target.value as any)}
                className="w-full px-3 py-2 bg-[#0C1018] border border-slate-700 rounded-lg text-white text-xs focus:border-teal-400 focus:outline-none"
              >
                <option value="Both">Dual Testing (DEA Walkthrough + OET Testing)</option>
                <option value="DEA">DEA Design Walkthrough Only</option>
                <option value="OET">OET Substantive Sampling Only</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-[11px] font-semibold text-slate-300 block mb-1">Control Title</label>
            <input
              type="text"
              required
              placeholder="e.g. Mandatory Supervisory Override Sign-off for Credit Exceptions"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 bg-[#0C1018] border border-slate-700 rounded-lg text-white text-xs focus:border-teal-400 focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[11px] font-semibold text-slate-300 block mb-1">Control Objective & Standard</label>
            <textarea
              rows={2}
              placeholder="Ensure secondary maker-checker authorization is captured before disbursement."
              value={objective}
              onChange={(e) => setObjective(e.target.value)}
              className="w-full px-3 py-2 bg-[#0C1018] border border-slate-700 rounded-lg text-white text-xs focus:border-teal-400 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-semibold text-slate-300 block mb-1">Control Classification</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as any)}
                className="w-full px-3 py-2 bg-[#0C1018] border border-slate-700 rounded-lg text-white text-xs focus:border-teal-400 focus:outline-none"
              >
                <option value="Preventive">Preventive (Hard Gate)</option>
                <option value="Detective">Detective (Periodic Reconciliation)</option>
                <option value="Corrective">Corrective</option>
              </select>
            </div>
            <div>
              <label className="text-[11px] font-semibold text-slate-300 block mb-1">Execution Frequency</label>
              <select
                value={frequency}
                onChange={(e) => setFrequency(e.target.value as any)}
                className="w-full px-3 py-2 bg-[#0C1018] border border-slate-700 rounded-lg text-white text-xs focus:border-teal-400 focus:outline-none"
              >
                <option value="Automated Real-time">Automated Real-time</option>
                <option value="Daily">Daily</option>
                <option value="Weekly">Weekly</option>
                <option value="Monthly">Monthly</option>
                <option value="Quarterly">Quarterly</option>
                <option value="Annual">Annual</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-semibold text-slate-300 block mb-1">Assigned In-Charge Auditor</label>
              <select
                value={assignedAuditor}
                onChange={(e) => setAssignedAuditor(e.target.value)}
                className="w-full px-3 py-2 bg-[#0C1018] border border-slate-700 rounded-lg text-white text-xs focus:border-teal-400 focus:outline-none"
              >
                {people.map((p) => (
                  <option key={p.id} value={p.name}>
                    {p.name} ({p.roleTitle})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-[11px] font-semibold text-slate-300 block mb-1">Sampling Method</label>
              <select
                value={samplingMethod}
                onChange={(e) => setSamplingMethod(e.target.value as SamplingMethod)}
                className="w-full px-3 py-2 bg-[#0C1018] border border-slate-700 rounded-lg text-white text-xs focus:border-teal-400 focus:outline-none"
              >
                <option value="MUS">Monetary Unit Sampling (MUS)</option>
                <option value="Random">Random Sampling</option>
                <option value="Systematic">Systematic Interval</option>
                <option value="Stratified">Stratified Risk</option>
                <option value="High Value">Targeted High Value</option>
              </select>
            </div>
          </div>

          <div className="pt-2 flex items-center justify-end gap-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs transition-all shadow-md shadow-teal-500/20 cursor-pointer"
            >
              Create Working Paper
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
