import React from 'react';
import { useTheme, FONTS, HOVER_EASE } from '../../context/ThemeContext';
import { useApp } from '../../context/AppContext';
import { Icon } from '../common/Icons';

export function BoardReportsTab() {
  const { t } = useTheme();
  const { showToast } = useApp();

  const reports = [
    {
      id: 'REP-2026-Q3',
      title: 'Q3 2026 Comprehensive Audit Committee Executive Briefing Pack',
      date: 'September 11, 2026',
      author: 'Marcus Vance, Chief Audit Executive',
      status: 'Ready for Presentation',
      pages: 42,
    },
    {
      id: 'REP-2026-Q2',
      title: 'Q2 2026 Internal Audit Quarterly Performance & Remediation Report',
      date: 'June 30, 2026',
      author: 'Marcus Vance, Chief Audit Executive',
      status: 'Approved by Committee',
      pages: 38,
    },
    {
      id: 'REP-2026-SPECIAL',
      title: 'Special Investigation: Retail Loan Underwriting Override Patterns',
      date: 'August 14, 2026',
      author: 'Riya Anand & Marcus Vance',
      status: 'Confidential Executive Memorandum',
      pages: 18,
    },
    {
      id: 'REP-2025-ANNUAL',
      title: '2025 Annual Internal Audit Overall Opinion & Governance Assessment',
      date: 'January 25, 2026',
      author: 'Marcus Vance, Chief Audit Executive',
      status: 'Concluded & Filed with Regulators',
      pages: 64,
    },
  ];

  return (
    <div style={{ padding: '32px 48px', maxWidth: 1360, margin: '0 auto' }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 24, flexWrap: 'wrap', gap: 16 }}>
        <div>
          <div style={{ fontFamily: FONTS.serif, fontSize: 26, fontWeight: 600, marginBottom: 4 }}>
            Board Audit Committee Reports & Formal Memoranda
          </div>
          <p style={{ color: t.textSecondary, fontSize: 13.5 }}>
            Archived and active executive briefings prepared for the Meridian Bank Board of Directors Audit Committee.
          </p>
        </div>

        <button
          onClick={() => showToast('Compiled live Q3 Board Briefing presentation pack')}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 6,
            padding: '8px 16px',
            borderRadius: 9,
            border: 'none',
            background: t.verdigris,
            color: t.mode === 'dark' ? '#12151C' : '#FFFFFF',
            fontSize: 12.5,
            fontWeight: 600,
            cursor: 'pointer',
          }}
        >
          {Icon.plus(t.mode === 'dark' ? '#12151C' : '#FFFFFF')}
          Compile New Board Memorandum
        </button>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        {reports.map((rep) => (
          <div
            key={rep.id}
            style={{
              padding: '20px 24px',
              borderRadius: 14,
              background: t.card,
              border: `1px solid ${t.hairline}`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
              transition: `border-color 0.2s ease, transform 0.2s ${HOVER_EASE}`,
            }}
            onMouseEnter={(e) => (e.currentTarget.style.borderColor = t.hairlineStrong)}
            onMouseLeave={(e) => (e.currentTarget.style.borderColor = t.hairline)}
          >
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
                <span style={{ fontSize: 11, fontWeight: 700, color: t.verdigris }}>{rep.id}</span>
                <span
                  style={{
                    fontSize: 10.5,
                    fontWeight: 600,
                    color: t.verdigris,
                    padding: '2px 7px',
                    borderRadius: 4,
                    background: `${t.verdigris}15`,
                    border: `1px solid ${t.verdigris}35`,
                  }}
                >
                  {rep.status}
                </span>
              </div>
              <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 4 }}>
                {rep.title}
              </div>
              <div style={{ fontSize: 12, color: t.textSecondary }}>
                {rep.date} · Signatory: {rep.author} · {rep.pages} Pages
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <button
                onClick={() => showToast(`Downloading ${rep.id} Board Briefing PDF`)}
                style={{
                  padding: '7px 14px',
                  borderRadius: 8,
                  border: `1px solid ${t.hairlineStrong}`,
                  background: t.cardSunken,
                  color: t.textPrimary,
                  fontSize: 12,
                  fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                Download PDF
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
