import React, { useState, useRef, useEffect, useMemo } from 'react';
import { useTheme, FONTS, SPRING, HOVER_EASE, HOVER_DUR } from '../../context/ThemeContext';
import { useApp } from '../../context/AppContext';
import { Icon } from '../common/Icons';
import { AuditEngagement, AuditStatus } from '../../types';
import {
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Zap,
  Clock,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  FileText,
  ExternalLink,
  History,
  RotateCcw
} from 'lucide-react';

const DAY_MS = 86400000;
const DAY_WIDTH = 5.2; // px per day for high density across 2023-2027

function daysBetween(a: Date, b: Date) {
  return Math.round((b.getTime() - a.getTime()) / DAY_MS);
}

export function GanttTimeWarp() {
  const { t } = useTheme();
  const {
    audits,
    timeWarpYear,
    isWarping,
    triggerTimeWarp,
    setSelectedAuditForModal,
    setActiveTab,
  } = useApp();

  const scrollRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);

  const [dragging, setDragging] = useState(false);
  const [hoverId, setHoverId] = useState<string | number | null>(null);
  const [hoverPos, setHoverPos] = useState<{ top: number; left: number } | null>(null);
  const [selectedId, setSelectedId] = useState<string | number | null>(null);
  const [scrollLeft, setScrollLeft] = useState(0);
  const [viewportWidth, setViewportWidth] = useState(900);

  const dragState = useRef({
    startX: 0,
    startScroll: 0,
    lastX: 0,
    lastT: 0,
    velocity: 0,
  });
  const inertiaRaf = useRef<number | null>(null);

  // Spans from Jan 1, 2023 to Dec 31, 2027 (5 years of time travel!)
  const rangeStart = useMemo(() => new Date(2023, 0, 1), []);
  const rangeEnd = useMemo(() => new Date(2027, 11, 31), []);
  const totalDays = useMemo(() => daysBetween(rangeStart, rangeEnd), [rangeStart, rangeEnd]);
  const totalWidth = totalDays * DAY_WIDTH;

  const today = useMemo(() => new Date(2026, 8, 11), []);
  const todayX = daysBetween(rangeStart, today) * DAY_WIDTH;

  const statusStyles: Record<AuditStatus, { fill: string; label: string }> = {
    in_progress: { fill: t.verdigris, label: 'In progress' },
    overdue: { fill: t.cinnabar, label: 'Overdue' },
    upcoming: { fill: t.blueAccent, label: 'Upcoming' },
    concluded_this_year: { fill: `${t.verdigris}95`, label: 'Concluded this year' },
    concluded_prior: { fill: t.textSecondary, label: 'Concluded prior' },
  };

  // Observe width and initialize scroll near today
  useEffect(() => {
    if (!scrollRef.current) return;
    const el = scrollRef.current;
    const ro = new ResizeObserver(() => setViewportWidth(el.clientWidth));
    ro.observe(el);
    setViewportWidth(el.clientWidth);

    // Initial center on today
    const initial = todayX - el.clientWidth / 2;
    el.scrollLeft = initial;
    setScrollLeft(initial);
    return () => ro.disconnect();
  }, [todayX]);

  // Inertia handling
  const stopInertia = () => {
    if (inertiaRaf.current) {
      cancelAnimationFrame(inertiaRaf.current);
      inertiaRaf.current = null;
    }
  };

  const runInertia = (velocity: number) => {
    let v = velocity;
    const step = () => {
      if (!scrollRef.current || Math.abs(v) < 0.02) {
        inertiaRaf.current = null;
        return;
      }
      scrollRef.current.scrollLeft -= v * 16;
      setScrollLeft(scrollRef.current.scrollLeft);
      v *= 0.94;
      inertiaRaf.current = requestAnimationFrame(step);
    };
    inertiaRaf.current = requestAnimationFrame(step);
  };

  const onPointerDown = (e: React.PointerEvent) => {
    stopInertia();
    setDragging(true);
    setHoverId(null);
    dragState.current = {
      startX: e.clientX,
      startScroll: scrollRef.current?.scrollLeft || 0,
      lastX: e.clientX,
      lastT: performance.now(),
      velocity: 0,
    };
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (!dragging || !scrollRef.current) return;
    const now = performance.now();
    const dx = e.clientX - dragState.current.startX;
    scrollRef.current.scrollLeft = dragState.current.startScroll - dx;
    setScrollLeft(scrollRef.current.scrollLeft);

    const dt = now - dragState.current.lastT;
    if (dt > 0) dragState.current.velocity = (e.clientX - dragState.current.lastX) / dt;
    dragState.current.lastX = e.clientX;
    dragState.current.lastT = now;
  };

  const endDrag = () => {
    if (!dragging) return;
    setDragging(false);
    if (Math.abs(dragState.current.velocity) > 0.05) {
      runInertia(dragState.current.velocity);
    }
  };

  // Warp into any year (Past or Future)
  const warpToYear = (year: number) => {
    stopInertia();
    triggerTimeWarp(year);
    const targetDate = new Date(year, 5, 1);
    const targetX = daysBetween(rangeStart, targetDate) * DAY_WIDTH;
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        left: targetX - viewportWidth / 2,
        behavior: 'smooth',
      });
      setTimeout(() => {
        setScrollLeft(scrollRef.current?.scrollLeft || 0);
      }, 400);
    }
  };

  const goBackInTime = () => {
    const prevYear = Math.max(2023, timeWarpYear - 1);
    warpToYear(prevYear);
  };

  const advanceInTime = () => {
    const nextYear = Math.min(2027, timeWarpYear + 1);
    warpToYear(nextYear);
  };

  // Month intervals across 2023 - 2027
  const months = useMemo(() => {
    const list: Date[] = [];
    let cur = new Date(2023, 0, 1);
    while (cur <= rangeEnd) {
      list.push(new Date(cur));
      cur = new Date(cur.getFullYear(), cur.getMonth() + 1, 1);
    }
    return list;
  }, [rangeEnd]);

  const selectedItem = audits.find((a) => String(a.id) === String(selectedId));

  const handleBarClick = (item: AuditEngagement) => {
    setSelectedId((prev) => (String(prev) === String(item.id) ? null : item.id));
  };

  return (
    <div
      ref={cardRef}
      style={{
        background: t.card,
        border: `1px solid ${t.hairline}`,
        borderRadius: 16,
        padding: '22px 0 20px',
        marginBottom: 32,
        position: 'relative',
        overflow: 'hidden',
        boxShadow: '0 4px 20px rgba(0,0,0,0.06)',
      }}
    >
      {/* SURREALISTIC HYPERLOOP SPEEDLINES & WARP TUNNEL OVERLAY (Requirement 4 & 6) */}
      {isWarping && (
        <div
          style={{
            position: 'absolute',
            inset: 0,
            zIndex: 90,
            pointerEvents: 'none',
            background: t.mode === 'dark'
              ? 'radial-gradient(ellipse at center, rgba(111,166,148,0.3) 0%, rgba(13,17,23,0.95) 100%)'
              : 'radial-gradient(ellipse at center, rgba(78,135,120,0.35) 0%, rgba(247,246,243,0.95) 100%)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            backdropFilter: 'blur(4px)',
            animation: 'fadeIn 0.12s ease',
          }}
        >
          {/* Chromatic Hyperloop Tunnel Streaks */}
          <div
            style={{
              position: 'absolute',
              inset: 0,
              backgroundImage: `radial-gradient(circle, transparent 20%, rgba(111,166,148,0.2) 40%, transparent 80%), repeating-linear-gradient(90deg, ${t.verdigris}77 0px, transparent 10px, ${t.cinnabar}55 25px, transparent 45px)`,
              backgroundSize: '250% 100%',
              animation: 'hyperloopStreaks 0.28s linear infinite',
              opacity: 0.85,
            }}
          />

          <div
            style={{
              position: 'relative',
              zIndex: 2,
              textAlign: 'center',
              padding: '20px 36px',
              borderRadius: 16,
              background: t.card,
              border: `2px solid ${t.verdigris}`,
              boxShadow: '0 24px 70px rgba(0,0,0,0.5)',
              transform: 'scale(1.08)',
              animation: 'previewIn 0.2s cubic-bezier(0.16, 1, 0.3, 1)',
            }}
          >
            <div className="flex items-center justify-center gap-2 mb-1">
              <Zap className="w-4 h-4 text-teal-400 animate-pulse" />
              <span style={{ fontSize: 11, fontWeight: 700, color: t.verdigris, letterSpacing: 1.4, textTransform: 'uppercase' }}>
                HYPERLOOP RELATIVISTIC TIME-WARP
              </span>
            </div>
            <div style={{ fontFamily: FONTS.serif, fontSize: 32, fontWeight: 700, margin: '6px 0', color: t.textPrimary }}>
              Traveling to Epoch {timeWarpYear}
            </div>
            <div style={{ fontSize: 12, color: t.textSecondary }}>
              {timeWarpYear < 2026
                ? 'Rewinding historical audit files, workpapers & closed observations...'
                : timeWarpYear === 2026
                ? 'Synchronizing active 2026 fieldwork & testing continuum...'
                : 'Projecting forward planned multi-year audit universe cycle...'}
            </div>
          </div>
        </div>
      )}

      {/* Gantt Header & Warp Controls */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '0 26px',
          marginBottom: 16,
          flexWrap: 'wrap',
          gap: 12,
        }}
      >
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontFamily: FONTS.serif, fontSize: 17, fontWeight: 600 }}>
              Multi-Year Audit Engagement Timeline (2023–2027)
            </span>
            <span
              style={{
                fontSize: 10,
                fontWeight: 700,
                color: t.verdigris,
                padding: '2px 8px',
                borderRadius: 5,
                background: `${t.verdigris}15`,
                border: `1px solid ${t.verdigris}35`,
              }}
            >
              Epoch: {timeWarpYear}
            </span>
          </div>
          <div style={{ fontSize: 11.5, color: t.textSecondary, marginTop: 2 }}>
            Interactive timeline pan · Click bars to inspect DEA/OET controls tested & workpapers
          </div>
        </div>

        {/* Hyperloop Time Travel Navigation Buttons (Requirement 4 & 6) */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <button
            onClick={goBackInTime}
            disabled={timeWarpYear <= 2023}
            title="Rewind time backward to previous audit year"
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-700 bg-slate-800/80 text-xs font-semibold text-slate-200 hover:bg-slate-700 hover:text-white transition disabled:opacity-40 disabled:cursor-not-allowed shadow-sm"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            <span>Go Back in Time</span>
          </button>

          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            {[2023, 2024, 2025, 2026, 2027].map((yr) => {
              const isLive = yr === 2026;
              const isSelected = yr === timeWarpYear;
              return (
                <button
                  key={yr}
                  onClick={() => warpToYear(yr)}
                  title={`Hyperloop warp to ${yr}`}
                  style={{
                    padding: '5px 10px',
                    borderRadius: 7,
                    border: isSelected ? `1.5px solid ${t.verdigris}` : `1px solid ${t.hairline}`,
                    background: isSelected ? `${t.verdigris}20` : t.cardSunken,
                    color: isSelected ? t.verdigris : t.textPrimary,
                    fontSize: 11.5,
                    fontWeight: isSelected ? 700 : 500,
                    cursor: 'pointer',
                    transition: `all ${HOVER_DUR} ${HOVER_EASE}`,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 4,
                  }}
                >
                  {yr}
                  {isLive && (
                    <span style={{ fontSize: 9, color: t.verdigris, fontWeight: 700 }}>
                      LIVE
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          <button
            onClick={advanceInTime}
            disabled={timeWarpYear >= 2027}
            title="Advance time forward to next audit year"
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-700 bg-slate-800/80 text-xs font-semibold text-slate-200 hover:bg-slate-700 hover:text-white transition disabled:opacity-40 disabled:cursor-not-allowed shadow-sm"
          >
            <span>Advance Forward</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Legend */}
      <div style={{ display: 'flex', gap: 14, padding: '0 26px 12px', fontSize: 11, color: t.textSecondary, flexWrap: 'wrap' }}>
        {Object.entries(statusStyles).map(([key, s]) => (
          <div key={key} style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
            <div style={{ width: 8, height: 8, borderRadius: 2, background: s.fill }} />
            <span>{s.label}</span>
          </div>
        ))}
      </div>

      {/* Timeline Scrollport with Custom Sexy Scrollbar */}
      <div
        ref={scrollRef}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={endDrag}
        onPointerLeave={endDrag}
        onScroll={(e) => {
          if (!dragging) setScrollLeft(e.currentTarget.scrollLeft);
        }}
        className="custom-scrollbar"
        style={{
          overflowX: 'auto',
          overflowY: 'hidden',
          cursor: dragging ? 'grabbing' : 'grab',
          userSelect: 'none',
          scrollbarWidth: 'thin',
          scrollbarColor: `${t.verdigris}40 transparent`,
          position: 'relative',
        }}
      >
        {/* Parallax Depth lines */}
        <div
          style={{
            position: 'absolute',
            inset: 0,
            pointerEvents: 'none',
            backgroundImage: `repeating-linear-gradient(90deg, ${t.hairline} 0px, ${t.hairline} 1px, transparent 1px, transparent ${DAY_WIDTH * 30}px)`,
            backgroundPosition: `${-scrollLeft * 0.4}px 0`,
            opacity: 0.6,
          }}
        />

        <div style={{ position: 'relative', width: totalWidth, paddingBottom: 6, zIndex: 1 }}>
          {/* Month & Year Ruler */}
          <div style={{ position: 'relative', height: 28, borderBottom: `1px solid ${t.hairline}`, marginBottom: 10 }}>
            {months.map((m, i) => {
              const x = daysBetween(rangeStart, m) * DAY_WIDTH;
              const isYearStart = m.getMonth() === 0;
              return (
                <div key={i} style={{ position: 'absolute', left: x, top: 0, height: '100%' }}>
                  <div
                    style={{
                      width: 1,
                      height: '100%',
                      background: isYearStart ? t.hairlineStrong : t.hairline,
                      position: 'absolute',
                      left: 0,
                    }}
                  />
                  <div
                    style={{
                      fontSize: 10.5,
                      color: isYearStart ? t.textPrimary : t.textSecondary,
                      fontWeight: isYearStart ? 700 : 500,
                      paddingLeft: 6,
                      paddingTop: 4,
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {m.toLocaleDateString('en-US', { month: 'short' })}
                    {isYearStart && ` ${m.getFullYear()}`}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Today Line */}
          <div
            style={{
              position: 'absolute',
              left: todayX,
              top: 28,
              bottom: 0,
              width: 1.5,
              background: t.verdigris,
              zIndex: 4,
              opacity: 0.8,
            }}
          >
            <div
              style={{
                position: 'absolute',
                top: -24,
                left: '50%',
                transform: 'translateX(-50%)',
                fontSize: 9,
                fontWeight: 700,
                color: t.verdigris,
                letterSpacing: 0.4,
                whiteSpace: 'nowrap',
                background: t.card,
                padding: '1px 5px',
                borderRadius: 4,
                border: `1px solid ${t.verdigris}50`,
              }}
            >
              TODAY (SEP 11, 2026)
            </div>
          </div>

          {/* Engagement Bars */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, padding: '4px 0' }}>
            {audits.map((item) => {
              const startD = new Date(item.start);
              const endD = new Date(item.end);
              const x = daysBetween(rangeStart, startD) * DAY_WIDTH;
              const w = Math.max(18, daysBetween(startD, endD) * DAY_WIDTH);
              const s = statusStyles[item.status];
              const isSelected = String(selectedId) === String(item.id);

              return (
                <div
                  key={item.id}
                  style={{
                    position: 'relative',
                    height: 28,
                  }}
                >
                  <div
                    onClick={() => handleBarClick(item)}
                    title={`${item.title} — ${item.controlsTested || 0}/${item.controlsTotal || 0} Controls Tested (Click to view DEA/OET details)`}
                    style={{
                      position: 'absolute',
                      left: x,
                      width: w,
                      top: 2,
                      height: 24,
                      borderRadius: 6,
                      background: s.fill,
                      cursor: 'pointer',
                      border: isSelected ? `2px solid ${t.textPrimary}` : '2px solid transparent',
                      boxShadow: isSelected ? '0 4px 14px rgba(0,0,0,0.3)' : 'none',
                      transition: dragging
                        ? 'none'
                        : `transform 0.18s ${HOVER_EASE}, box-shadow 0.18s ${HOVER_EASE}`,
                      display: 'flex',
                      alignItems: 'center',
                      paddingLeft: 8,
                      paddingRight: 6,
                      overflow: 'hidden',
                      transform: isSelected ? 'scaleY(1.15)' : 'scale(1)',
                    }}
                  >
                    {w > 65 && (
                      <span
                        style={{
                          fontSize: 11,
                          fontWeight: 600,
                          color: t.mode === 'dark' ? '#12151C' : '#FFFFFF',
                          whiteSpace: 'nowrap',
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                        }}
                      >
                        {item.title}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* RICH GANTT POPOUT WITH CONTROLS TESTED, DEA & OET STATUS (Requirement 6!) */}
      {selectedItem && (
        <div
          style={{
            position: 'absolute',
            top: 60,
            right: 28,
            zIndex: 60,
            width: 'min(410px, calc(100vw - 32px))',
            background: t.card,
            border: `1.5px solid ${t.verdigris}60`,
            borderRadius: 16,
            padding: '18px 20px',
            boxShadow: '0 32px 72px rgba(0,0,0,0.45)',
            animation: `riseIn 0.25s ${SPRING}`,
          }}
        >
          {/* Header */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 }}>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span
                  style={{
                    fontSize: 10,
                    fontWeight: 700,
                    color: statusStyles[selectedItem.status].fill,
                    padding: '1px 6px',
                    borderRadius: 4,
                    background: `${statusStyles[selectedItem.status].fill}15`,
                    border: `1px solid ${statusStyles[selectedItem.status].fill}35`,
                    textTransform: 'uppercase',
                  }}
                >
                  {statusStyles[selectedItem.status].label}
                </span>
                <span className="text-[11px] text-slate-400">
                  Stage: <strong className="text-slate-200 capitalize">{selectedItem.stage}</strong>
                </span>
              </div>
              <span style={{ fontSize: 14.5, fontWeight: 700, lineHeight: 1.3, color: t.textPrimary }}>
                {selectedItem.title}
              </span>
            </div>

            <button
              onClick={() => setSelectedId(null)}
              style={{ background: 'none', border: 'none', color: t.textSecondary, cursor: 'pointer', fontSize: 18 }}
            >
              ×
            </button>
          </div>

          <div style={{ fontSize: 11.5, color: t.textSecondary, marginBottom: 12 }}>
            {selectedItem.dept} · Lead: <strong style={{ color: t.textPrimary }}>{selectedItem.leadAuditorName}</strong>
            <div className="text-[11px] text-slate-400 mt-0.5">
              Timeline: {selectedItem.start} to {selectedItem.end}
            </div>
          </div>

          {/* CONTROLS TESTED PROGRESS METER (Requirement 6) */}
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 mb-3 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-teal-400" />
                Controls Tested
              </span>
              <span className="font-bold text-teal-300">
                {selectedItem.controlsTested || 0} / {selectedItem.controlsTotal || 0} Controls
              </span>
            </div>
            {/* Progress Bar */}
            <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-teal-400 rounded-full transition-all duration-300"
                style={{
                  width: `${Math.min(100, Math.round(((selectedItem.controlsTested || 0) / (selectedItem.controlsTotal || 1)) * 100))}%`,
                }}
              />
            </div>
          </div>

          {/* DEA & OET DUAL MATRIX (Perfect Executive Alignment - No Text Wrap Collisions) */}
          <div className="grid grid-cols-2 gap-2.5 mb-3">
            {/* DEA Box */}
            <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10.5px] font-bold tracking-wider text-slate-300 uppercase">DEA ASSESSMENT</span>
                <span
                  className={`text-[9.5px] font-bold px-1.5 py-0.5 rounded border ${
                    selectedItem.dea?.status === 'completed'
                      ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                      : 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                  }`}
                >
                  {selectedItem.dea?.status === 'completed' ? 'Done' : selectedItem.dea?.status === 'in_progress' ? 'In Progress' : 'Pending'}
                </span>
              </div>

              <div className="space-y-1.5 pt-1 text-xs">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                    <span>Effective</span>
                  </span>
                  <span className="font-mono font-bold text-emerald-300">
                    {selectedItem.dea?.effective || 0}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-rose-400 font-medium">
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                    <span>Ineffective</span>
                  </span>
                  <span className="font-mono font-bold text-rose-300">
                    {selectedItem.dea?.ineffective || 0}
                  </span>
                </div>
              </div>
            </div>

            {/* OET Box */}
            <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10.5px] font-bold tracking-wider text-slate-300 uppercase">OET TESTING</span>
                <span
                  className={`text-[9.5px] font-bold px-1.5 py-0.5 rounded border ${
                    selectedItem.oet?.status === 'completed'
                      ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                      : selectedItem.oet?.status === 'in_progress'
                      ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                      : 'bg-slate-700/40 text-slate-400 border-slate-700'
                  }`}
                >
                  {selectedItem.oet?.status === 'completed' ? 'Done' : selectedItem.oet?.status === 'in_progress' ? 'In Progress' : 'Pending'}
                </span>
              </div>

              <div className="space-y-1.5 pt-1 text-xs">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                    <span>Effective</span>
                  </span>
                  <span className="font-mono font-bold text-emerald-300">
                    {selectedItem.oet?.effective || 0}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-rose-400 font-medium">
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                    <span>Ineffective</span>
                  </span>
                  <span className="font-mono font-bold text-rose-300">
                    {selectedItem.oet?.ineffective || 0}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Notes if present */}
          {selectedItem.dea?.notes && (
            <div className="text-[11px] text-slate-400 bg-slate-900/40 p-2 rounded-lg border border-slate-800/80 mb-3 leading-relaxed">
              <span className="text-slate-300 font-medium">DEA Notes:</span> {selectedItem.dea.notes}
            </div>
          )}

          {/* CTA Buttons */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <button
              onClick={() => {
                setSelectedAuditForModal(selectedItem);
                setSelectedId(null);
              }}
              style={{
                width: '100%',
                padding: '9px 0',
                borderRadius: 8,
                border: 'none',
                background: t.verdigris,
                color: t.mode === 'dark' ? '#12151C' : '#FFFFFF',
                fontSize: 12,
                fontWeight: 600,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 6,
              }}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Open Audit File, Workpapers & Evidence</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('calendar');
                setSelectedId(null);
              }}
              style={{
                width: '100%',
                padding: '7px 0',
                borderRadius: 8,
                border: `1px solid ${t.hairline}`,
                background: t.cardSunken,
                color: t.textPrimary,
                fontSize: 11.5,
                fontWeight: 600,
                cursor: 'pointer',
              }}
            >
              View on Audit Calendar
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
