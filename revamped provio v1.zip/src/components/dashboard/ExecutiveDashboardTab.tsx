import React, { useState, useMemo } from 'react';
import { useTheme, FONTS, SPRING, HOVER_EASE, HOVER_DUR } from '../../context/ThemeContext';
import { useApp } from '../../context/AppContext';
import { Icon } from '../common/Icons';
import { GanttTimeWarp } from './GanttTimeWarp';
import { Observation, ObservationComment, AuditEngagement } from '../../types';
import {
  AlertTriangle,
  Building2,
  Calendar,
  CheckCircle2,
  ChevronRight,
  Clock,
  ExternalLink,
  FileCheck,
  FileText,
  Filter,
  Layers,
  MessageSquare,
  Shield,
  ShieldAlert,
  Sparkles,
  User,
  Users,
  X
} from 'lucide-react';

export function ExecutiveDashboardTab() {
  const { t } = useTheme();
  const {
    departments,
    audits,
    entities,
    people,
    setActiveTab,
    selectedAuditForModal,
    setSelectedAuditForModal,
    selectedObservation,
    setSelectedObservation,
    addReviewComment,
    markCAPClosure,
    showToast,
  } = useApp();

  // Filters
  const [activeDeptFilter, setActiveDeptFilter] = useState<string>('all');
  const [activeSeverityFilter, setActiveSeverityFilter] = useState<string>('all');
  const [activeAgingFilter, setActiveAgingFilter] = useState<string>('all');

  // Popout States for Links (Requirement 5)
  const [inspectedDept, setInspectedDept] = useState<{ id: string; label: string; count: number } | null>(null);
  const [inspectedOwner, setInspectedOwner] = useState<{ name: string; dept: string; role: string; email: string } | null>(null);
  const [capActionModalObs, setCapActionModalObs] = useState<Observation | null>(null);
  const [rectificationNote, setRectificationNote] = useState('');

  // Comment input in observation modal
  const [commentInput, setCommentInput] = useState('');

  // Calculations
  const allObservations = useMemo(() => departments.flatMap((d) => d.observations), [departments]);
  const totalOpenFindings = allObservations.length;
  const criticalFindings = allObservations.filter((o) => o.severity === 'critical').length;
  const highFindings = allObservations.filter((o) => o.severity === 'high').length;
  const mediumFindings = allObservations.filter((o) => o.severity === 'medium').length;
  const lowFindings = allObservations.filter((o) => o.severity === 'low').length;
  const overdueCAPs = allObservations.filter((o) => o.overdue).length;
  const activeAuditsCount = audits.filter((a) => a.status === 'in_progress').length;

  // Aging distribution
  const due30DaysCount = allObservations.filter((o) => !o.overdue && o.dueDate <= '2026-10-15').length;
  const due60to90DaysCount = allObservations.filter((o) => !o.overdue && o.dueDate > '2026-10-15').length;
  const closedCount = allObservations.filter((o) => Boolean(o.closureDate)).length;

  // Department counts
  const deptBreakdown = useMemo(() => {
    return departments.map((d) => {
      const crit = d.observations.filter((o) => o.severity === 'critical').length;
      const overdue = d.observations.filter((o) => o.overdue).length;
      return {
        id: d.id,
        label: d.label,
        total: d.observations.length,
        critical: crit,
        overdue,
        pct: Math.round((d.observations.length / (totalOpenFindings || 1)) * 100),
      };
    });
  }, [departments, totalOpenFindings]);

  // Filtered observations
  const filteredDepartments = useMemo(() => {
    return departments
      .filter((dept) => {
        if (activeDeptFilter === 'all') return true;
        return dept.id === activeDeptFilter || dept.label.toLowerCase().includes(activeDeptFilter.toLowerCase());
      })
      .map((dept) => ({
        ...dept,
        observations: dept.observations.filter((obs) => {
          if (activeSeverityFilter !== 'all' && obs.severity !== activeSeverityFilter) return false;
          if (activeAgingFilter === 'overdue' && !obs.overdue) return false;
          if (activeAgingFilter === 'due_30' && (obs.overdue || obs.dueDate > '2026-10-15')) return false;
          if (activeAgingFilter === 'due_60_90' && (obs.overdue || obs.dueDate <= '2026-10-15')) return false;
          if (activeAgingFilter === 'closed' && !obs.closureDate) return false;
          return true;
        }),
      }));
  }, [departments, activeDeptFilter, activeSeverityFilter, activeAgingFilter]);

  const hasActiveFilters = activeDeptFilter !== 'all' || activeSeverityFilter !== 'all' || activeAgingFilter !== 'all';

  const clearAllFilters = () => {
    setActiveDeptFilter('all');
    setActiveSeverityFilter('all');
    setActiveAgingFilter('all');
  };

  const handlePostComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim() || !selectedObservation) return;
    addReviewComment(selectedObservation.id, commentInput);
    setCommentInput('');
  };

  const handleCloseCAP = (e: React.FormEvent) => {
    e.preventDefault();
    if (!capActionModalObs || !rectificationNote.trim()) {
      showToast('Please specify evidence of corrective implementation');
      return;
    }
    markCAPClosure(capActionModalObs.id, {
      rectificationText: rectificationNote,
      closureDate: '2026-09-11',
    });
    setCapActionModalObs(null);
    setRectificationNote('');
  };

  return (
    <div style={{ padding: '36px 48px', maxWidth: 1380, margin: '0 auto' }}>
      {/* Executive Briefing Title Banner — Luxurious, Refined Apple Typography (Requirement 4) */}
      <div style={{ marginBottom: 28 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 5 }}>
              <span
                style={{
                  fontFamily: FONTS.sans,
                  fontSize: 27,
                  fontWeight: 700,
                  letterSpacing: -0.4,
                  color: t.textPrimary,
                }}
              >
                Provio Executive Assurance Briefing · Q3 2026
              </span>
              <span
                style={{
                  fontSize: 10.5,
                  fontWeight: 700,
                  color: t.verdigris,
                  padding: '2px 8px',
                  borderRadius: 6,
                  background: `${t.verdigris}16`,
                  border: `1px solid ${t.verdigris}35`,
                  textTransform: 'uppercase',
                  letterSpacing: 0.5,
                }}
              >
                Board Ready
              </span>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: t.textSecondary, fontWeight: 500 }}>
              <span style={{ fontWeight: 600, color: t.textPrimary }}>
                Office of the Chief Audit Executive (CAE)
              </span>
              <span>·</span>
              <span>Meridian Retail Bank Corporation</span>
              <span>·</span>
              <span>Internal Audit Committee Dossier</span>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <button
              onClick={() => setActiveTab('calendar')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700/60 bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition cursor-pointer"
            >
              <Calendar className="w-3.5 h-3.5 text-teal-400" />
              <span>Execution Calendar</span>
            </button>
            <button
              onClick={() => setActiveTab('universe')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700/60 bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition cursor-pointer"
            >
              <Layers className="w-3.5 h-3.5 text-teal-400" />
              <span>Multi-Universe Scope</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Overview Cards with Apple-style subtle depth */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(4, 1fr)',
          gap: 16,
          marginBottom: 32,
        }}
      >
        {/* Card 1: Active Engagements */}
        <div
          onClick={() => setActiveTab('calendar')}
          style={{
            padding: '20px 22px',
            borderRadius: 14,
            background: t.card,
            border: `1px solid ${t.hairline}`,
            cursor: 'pointer',
            boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
            transition: `transform 0.2s ${HOVER_EASE}, border-color 0.2s ease`,
          }}
          onMouseEnter={(e) => (e.currentTarget.style.borderColor = t.verdigris)}
          onMouseLeave={(e) => (e.currentTarget.style.borderColor = t.hairline)}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <span style={{ fontSize: 11.5, fontWeight: 700, color: t.textSecondary, letterSpacing: 0.4 }}>
              LIVE AUDIT FIELDWORK
            </span>
            {Icon.calendar(t.verdigris)}
          </div>
          <div style={{ fontFamily: FONTS.sans, fontSize: 32, fontWeight: 800, color: t.textPrimary, letterSpacing: -0.5 }}>
            {activeAuditsCount} Engagements
          </div>
          <div style={{ fontSize: 11.5, color: t.verdigris, marginTop: 6, fontWeight: 600 }}>
            Click to open execution calendar →
          </div>
        </div>

        {/* Card 2: Open Findings */}
        <div
          onClick={() => {
            setActiveDeptFilter('all');
            setActiveSeverityFilter('all');
            setActiveAgingFilter('all');
          }}
          style={{
            padding: '20px 22px',
            borderRadius: 14,
            background: t.card,
            border: `1px solid ${activeSeverityFilter === 'all' && activeDeptFilter === 'all' ? t.verdigris : t.hairline}`,
            cursor: 'pointer',
            boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
            transition: `transform 0.2s ${HOVER_EASE}`,
          }}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <span style={{ fontSize: 11.5, fontWeight: 700, color: t.textSecondary, letterSpacing: 0.4 }}>
              TOTAL OPEN FINDINGS
            </span>
            {Icon.issues(t.textSecondary)}
          </div>
          <div style={{ fontFamily: FONTS.sans, fontSize: 32, fontWeight: 800, color: t.textPrimary, letterSpacing: -0.5 }}>
            {totalOpenFindings} Observations
          </div>
          <div style={{ fontSize: 11.5, color: t.textSecondary, marginTop: 6, fontWeight: 500 }}>
            Across 5 Core Banking Divisions
          </div>
        </div>

        {/* Card 3: Critical Severity */}
        <div
          onClick={() => setActiveSeverityFilter((s) => (s === 'critical' ? 'all' : 'critical'))}
          style={{
            padding: '20px 22px',
            borderRadius: 14,
            background: t.card,
            border: `1.5px solid ${activeSeverityFilter === 'critical' ? t.cinnabar : t.hairline}`,
            cursor: 'pointer',
            boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
            transition: `transform 0.2s ${HOVER_EASE}`,
          }}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <span style={{ fontSize: 11.5, fontWeight: 700, color: t.cinnabar, letterSpacing: 0.4 }}>
              CRITICAL ESCALATIONS
            </span>
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
          </div>
          <div style={{ fontFamily: FONTS.sans, fontSize: 32, fontWeight: 800, color: t.cinnabar, letterSpacing: -0.5 }}>
            {criticalFindings} Critical Items
          </div>
          <div style={{ fontSize: 11.5, color: t.cinnabar, marginTop: 6, fontWeight: 600 }}>
            {activeSeverityFilter === 'critical' ? 'Filtered: click to reset' : 'Click to isolate critical issues →'}
          </div>
        </div>

        {/* Card 4: Overdue CAPs */}
        <div
          onClick={() => setActiveAgingFilter((a) => (a === 'overdue' ? 'all' : 'overdue'))}
          style={{
            padding: '20px 22px',
            borderRadius: 14,
            background: t.card,
            border: `1.5px solid ${activeAgingFilter === 'overdue' ? t.cinnabar : t.hairline}`,
            cursor: 'pointer',
            boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
            transition: `transform 0.2s ${HOVER_EASE}, border-color 0.2s ease`,
          }}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <span style={{ fontSize: 11.5, fontWeight: 700, color: t.cinnabar, letterSpacing: 0.4 }}>
              OVERDUE MANAGEMENT CAPS
            </span>
            {Icon.issues(t.cinnabar)}
          </div>
          <div style={{ fontFamily: FONTS.sans, fontSize: 32, fontWeight: 800, color: t.cinnabar, letterSpacing: -0.5 }}>
            {overdueCAPs} Overdue Actions
          </div>
          <div style={{ fontSize: 11.5, color: t.cinnabar, marginTop: 6, fontWeight: 600 }}>
            {activeAgingFilter === 'overdue' ? 'Filtered: click to reset' : 'Requires immediate CAE sign-off →'}
          </div>
        </div>
      </div>

      {/* Surrealistic Hyperloop Time-Warp Gantt Chart with DEA/OET Popout */}
      <GanttTimeWarp />

      {/* THREE INTERACTIVE EXECUTIVE CHARTS (Requirement 5: Highlight Departments, Criticalities & Due Dates) */}
      <div style={{ marginBottom: 28 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
          <div>
            <div style={{ fontFamily: FONTS.sans, fontSize: 18, fontWeight: 700, color: t.textPrimary }}>
              Executive Assurance Analytics & Portfolio Distribution
            </div>
            <div style={{ fontSize: 12.5, color: t.textSecondary, marginTop: 2 }}>
              Click on any chart segment or department bar to filter the observation ledger and trigger detail popouts.
            </div>
          </div>

          {hasActiveFilters && (
            <button
              onClick={clearAllFilters}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                padding: '6px 12px',
                borderRadius: 8,
                background: `${t.cinnabar}15`,
                border: `1px solid ${t.cinnabar}40`,
                color: t.cinnabar,
                fontSize: 12,
                fontWeight: 600,
                cursor: 'pointer',
              }}
            >
              <X className="w-3.5 h-3.5" />
              <span>Clear Filter Criteria</span>
            </button>
          )}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr', gap: 16 }}>
          {/* CHART 1: FINDINGS BY DEPARTMENT / DIVISION */}
          <div
            style={{
              padding: '18px 20px',
              borderRadius: 14,
              background: t.card,
              border: `1px solid ${t.hairline}`,
              boxShadow: '0 2px 10px rgba(0,0,0,0.04)',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-teal-400" />
                <span style={{ fontSize: 13, fontWeight: 700, color: t.textPrimary }}>
                  Findings by Division
                </span>
              </div>
              <span style={{ fontSize: 11, color: t.textSecondary }}>
                {departments.length} Divisions
              </span>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {deptBreakdown.map((dept) => {
                const isSelected = activeDeptFilter === dept.id || activeDeptFilter === dept.label;
                return (
                  <div
                    key={dept.id}
                    onClick={() => {
                      setActiveDeptFilter(isSelected ? 'all' : dept.id);
                    }}
                    style={{
                      cursor: 'pointer',
                      padding: '8px 10px',
                      borderRadius: 8,
                      background: isSelected ? `${t.verdigris}18` : t.cardSunken,
                      border: `1px solid ${isSelected ? t.verdigris : t.hairline}`,
                      transition: `all ${HOVER_DUR} ${HOVER_EASE}`,
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                      <span style={{ fontSize: 12, fontWeight: 600, color: t.textPrimary }}>
                        {dept.label}
                      </span>
                      <div className="flex items-center gap-2">
                        {dept.critical > 0 && (
                          <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                            {dept.critical} Crit
                          </span>
                        )}
                        <span style={{ fontSize: 11.5, fontWeight: 700, color: isSelected ? t.verdigris : t.textSecondary }}>
                          {dept.total} items
                        </span>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div style={{ height: 5, borderRadius: 3, background: 'rgba(255,255,255,0.08)', overflow: 'hidden' }}>
                      <div
                        style={{
                          height: '100%',
                          width: `${Math.max(8, dept.pct)}%`,
                          background: dept.critical > 0 ? t.cinnabar : t.verdigris,
                          borderRadius: 3,
                          transition: 'width 0.3s ease',
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* CHART 2: CRITICALITY BREAKDOWN */}
          <div
            style={{
              padding: '18px 20px',
              borderRadius: 14,
              background: t.card,
              border: `1px solid ${t.hairline}`,
              boxShadow: '0 2px 10px rgba(0,0,0,0.04)',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-rose-400" />
                <span style={{ fontSize: 13, fontWeight: 700, color: t.textPrimary }}>
                  Criticality Breakdown
                </span>
              </div>
              <span style={{ fontSize: 11, color: t.textSecondary }}>
                {totalOpenFindings} Total
              </span>
            </div>

            {/* Segmented meter */}
            <div style={{ height: 10, borderRadius: 5, overflow: 'hidden', display: 'flex', marginBottom: 16 }}>
              <div style={{ width: `${(criticalFindings / (totalOpenFindings || 1)) * 100}%`, background: t.cinnabar }} title={`Critical: ${criticalFindings}`} />
              <div style={{ width: `${(highFindings / (totalOpenFindings || 1)) * 100}%`, background: '#C6521E' }} title={`High: ${highFindings}`} />
              <div style={{ width: `${(mediumFindings / (totalOpenFindings || 1)) * 100}%`, background: '#3B72A4' }} title={`Medium: ${mediumFindings}`} />
              <div style={{ width: `${(lowFindings / (totalOpenFindings || 1)) * 100}%`, background: t.textSecondary }} title={`Low: ${lowFindings}`} />
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {[
                { key: 'critical', label: 'Critical Severity', count: criticalFindings, col: t.cinnabar },
                { key: 'high', label: 'High Priority', count: highFindings, col: '#C6521E' },
                { key: 'medium', label: 'Medium Priority', count: mediumFindings, col: '#3B72A4' },
                { key: 'low', label: 'Low / Advisory', count: lowFindings, col: t.textSecondary },
              ].map((sev) => {
                const isSelected = activeSeverityFilter === sev.key;
                return (
                  <div
                    key={sev.key}
                    onClick={() => setActiveSeverityFilter(isSelected ? 'all' : sev.key)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: '8px 12px',
                      borderRadius: 8,
                      background: isSelected ? `${sev.col}20` : t.cardSunken,
                      border: `1px solid ${isSelected ? sev.col : t.hairline}`,
                      cursor: 'pointer',
                      transition: `all ${HOVER_DUR} ${HOVER_EASE}`,
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <div style={{ width: 8, height: 8, borderRadius: '50%', background: sev.col }} />
                      <span style={{ fontSize: 12, fontWeight: isSelected ? 700 : 500, color: t.textPrimary }}>
                        {sev.label}
                      </span>
                    </div>
                    <span style={{ fontSize: 12, fontWeight: 700, color: sev.col }}>
                      {sev.count}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* CHART 3: CAP DUE DATE AGING & REMEDIATION HORIZON */}
          <div
            style={{
              padding: '18px 20px',
              borderRadius: 14,
              background: t.card,
              border: `1px solid ${t.hairline}`,
              boxShadow: '0 2px 10px rgba(0,0,0,0.04)',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-400" />
                <span style={{ fontSize: 13, fontWeight: 700, color: t.textPrimary }}>
                  CAP Due Date Aging
                </span>
              </div>
              <span style={{ fontSize: 11, color: t.textSecondary }}>
                Target SLAs
              </span>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {[
                { key: 'overdue', label: 'Overdue Commitments', count: overdueCAPs, col: t.cinnabar, desc: 'Requires immediate escalation' },
                { key: 'due_30', label: 'Due within 30 Days', count: due30DaysCount, col: '#E07B49', desc: 'Target: Oct 15, 2026' },
                { key: 'due_60_90', label: 'Due in 60 to 90 Days', count: due60to90DaysCount, col: t.blueAccent, desc: 'Target: Nov - Dec 2026' },
                { key: 'closed', label: 'Verified Closed CAPs', count: closedCount, col: t.verdigris, desc: 'Evidence corroborated' },
              ].map((bucket) => {
                const isSelected = activeAgingFilter === bucket.key;
                return (
                  <div
                    key={bucket.key}
                    onClick={() => setActiveAgingFilter(isSelected ? 'all' : bucket.key)}
                    style={{
                      padding: '8px 12px',
                      borderRadius: 8,
                      background: isSelected ? `${bucket.col}18` : t.cardSunken,
                      border: `1px solid ${isSelected ? bucket.col : t.hairline}`,
                      cursor: 'pointer',
                      transition: `all ${HOVER_DUR} ${HOVER_EASE}`,
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ fontSize: 12, fontWeight: isSelected ? 700 : 600, color: t.textPrimary }}>
                        {bucket.label}
                      </span>
                      <span style={{ fontSize: 12, fontWeight: 800, color: bucket.col }}>
                        {bucket.count}
                      </span>
                    </div>
                    <div style={{ fontSize: 10.5, color: t.textSecondary, marginTop: 2 }}>
                      {bucket.desc}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* DIVISION OBSERVATIONS & CORRECTIVE ACTION REGISTER (Requirement 5) */}
      <div
        style={{
          background: t.card,
          border: `1px solid ${t.hairline}`,
          borderRadius: 16,
          padding: '24px 28px',
          boxShadow: '0 4px 20px rgba(0,0,0,0.06)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
          <div>
            <div style={{ fontFamily: FONTS.sans, fontSize: 18, fontWeight: 700, marginBottom: 3, color: t.textPrimary }}>
              Division Observations & Corrective Action Register
            </div>
            <div style={{ fontSize: 12.5, color: t.textSecondary }}>
              Every link is interactive. Click source audits to open audit files, click owners for contact cards, or click titles for root-cause analysis.
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            {hasActiveFilters && (
              <span className="text-xs text-amber-400 bg-amber-500/10 border border-amber-500/30 px-2.5 py-1 rounded-md font-semibold">
                Filters Active
              </span>
            )}
            <button
              onClick={() => showToast('Exporting division observation register to CSV...')}
              style={{
                padding: '6px 12px',
                borderRadius: 8,
                border: `1px solid ${t.hairline}`,
                background: t.cardSunken,
                color: t.textPrimary,
                fontSize: 12,
                fontWeight: 600,
                cursor: 'pointer',
              }}
            >
              Export Register
            </button>
          </div>
        </div>

        {/* Observations list grouped by department */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {filteredDepartments.map((dept) => {
            if (dept.observations.length === 0) return null;
            return (
              <div
                key={dept.id}
                style={{
                  border: `1px solid ${t.hairline}`,
                  borderRadius: 12,
                  overflow: 'hidden',
                  background: t.cardSunken,
                }}
              >
                {/* Department Header with CLICKABLE POP-OUT LINK */}
                <div
                  style={{
                    padding: '12px 18px',
                    background: t.card,
                    borderBottom: `1px solid ${t.hairline}`,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                  }}
                >
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setInspectedDept({ id: dept.id, label: dept.label, count: dept.observations.length })}
                      title={`Inspect ${dept.label} Division Profile & Universe Coverage`}
                      style={{
                        background: 'none',
                        border: 'none',
                        fontSize: 13.5,
                        fontWeight: 700,
                        color: t.verdigris,
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: 6,
                        textDecoration: 'underline',
                      }}
                    >
                      <span>{dept.label}</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                    <span className="text-xs text-slate-400">· Division Oversight</span>
                  </div>

                  <span style={{ fontSize: 11, color: t.textSecondary, fontWeight: 600 }}>
                    {dept.observations.length} Finding{dept.observations.length > 1 ? 's' : ''}
                  </span>
                </div>

                {/* Rows with ALL CLICKABLE LINKS (Requirement 5) */}
                <div>
                  {dept.observations.map((obs) => {
                    const isCrit = obs.severity === 'critical';
                    const isHigh = obs.severity === 'high';
                    const sevCol = isCrit ? t.cinnabar : isHigh ? (t.mode === 'dark' ? '#E59866' : '#C6521E') : t.textSecondary;

                    return (
                      <div
                        key={obs.id}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          padding: '12px 18px',
                          borderBottom: `1px solid ${t.hairline}`,
                          transition: `background ${HOVER_DUR} ${HOVER_EASE}`,
                        }}
                        className="hover:bg-slate-800/40"
                      >
                        {/* Finding Title & Severity */}
                        <div style={{ display: 'flex', alignItems: 'center', gap: 12, flex: 1.5 }}>
                          <span
                            style={{
                              fontSize: 10,
                              fontWeight: 700,
                              color: sevCol,
                              padding: '2px 6px',
                              borderRadius: 4,
                              background: `${sevCol}15`,
                              border: `1px solid ${sevCol}35`,
                              minWidth: 54,
                              textAlign: 'center',
                              textTransform: 'uppercase',
                            }}
                          >
                            {obs.severity}
                          </span>

                          <div>
                            <button
                              onClick={() => setSelectedObservation(obs)}
                              style={{
                                background: 'none',
                                border: 'none',
                                padding: 0,
                                textAlign: 'left',
                                fontSize: 13,
                                fontWeight: 600,
                                color: t.textPrimary,
                                cursor: 'pointer',
                              }}
                              className="hover:text-teal-300 hover:underline"
                            >
                              {obs.title}
                            </button>

                            {/* Clickable Source Audit Link */}
                            <div style={{ fontSize: 11.5, color: t.textSecondary, marginTop: 2, display: 'flex', alignItems: 'center', gap: 6 }}>
                              <span>Source:</span>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  const match = audits.find((a) => String(a.id) === String(obs.reportId) || a.title === obs.report);
                                  if (match) setSelectedAuditForModal(match);
                                  else showToast(`Opening dossier for ${obs.report}`);
                                }}
                                style={{
                                  background: 'none',
                                  border: 'none',
                                  padding: 0,
                                  fontSize: 11.5,
                                  fontWeight: 600,
                                  color: t.verdigris,
                                  textDecoration: 'underline',
                                  cursor: 'pointer',
                                }}
                              >
                                {obs.report} →
                              </button>
                            </div>
                          </div>
                        </div>

                        {/* Assigned Owner Link */}
                        <div style={{ flex: 1, padding: '0 10px' }}>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setInspectedOwner({
                                name: obs.owner || 'Chloe Bennett',
                                dept: dept.label,
                                role: 'VP, Operations & Control Owner',
                                email: 'c.bennett@meridianbank.com',
                              });
                            }}
                            style={{
                              background: 'none',
                              border: 'none',
                              padding: 0,
                              fontSize: 12,
                              color: t.textPrimary,
                              fontWeight: 500,
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              gap: 5,
                            }}
                            className="hover:underline"
                          >
                            <User className="w-3.5 h-3.5 text-slate-400" />
                            <span>{obs.owner || 'Assigned Lead'}</span>
                          </button>
                          <div style={{ fontSize: 10.5, color: t.textSecondary }}>
                            1st Line Action Owner
                          </div>
                        </div>

                        {/* Due Date & Action Link */}
                        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                          <div style={{ textAlign: 'right' }}>
                            <div style={{ fontSize: 11.5, fontWeight: 700, color: obs.overdue ? t.cinnabar : t.textPrimary }}>
                              {obs.overdue ? 'OVERDUE' : `Target: ${obs.dueDate}`}
                            </div>
                            <div style={{ fontSize: 10.5, color: t.textSecondary }}>
                              {obs.approval}
                            </div>
                          </div>

                          {/* CAP Remediation Action Link */}
                          <button
                            onClick={() => setCapActionModalObs(obs)}
                            title="Inspect or verify Corrective Action Plan"
                            style={{
                              padding: '5px 10px',
                              borderRadius: 6,
                              background: obs.closureDate ? `${t.verdigris}20` : t.card,
                              border: `1px solid ${obs.closureDate ? t.verdigris : t.hairline}`,
                              color: obs.closureDate ? t.verdigris : t.textPrimary,
                              fontSize: 11,
                              fontWeight: 600,
                              cursor: 'pointer',
                              display: 'flex',
                              alignItems: 'center',
                              gap: 4,
                            }}
                          >
                            {obs.closureDate ? (
                              <>
                                <CheckCircle2 className="w-3 h-3 text-teal-400" />
                                <span>Closed</span>
                              </>
                            ) : (
                              <>
                                <FileCheck className="w-3 h-3 text-amber-400" />
                                <span>CAP Action</span>
                              </>
                            )}
                          </button>

                          <button
                            onClick={() => setSelectedObservation(obs)}
                            style={{ background: 'none', border: 'none', cursor: 'pointer', color: t.textSecondary }}
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* POPOUT 1: DIVISION / DEPARTMENT OVERVIEW MODAL (Requirement 5) */}
      {inspectedDept && (
        <div
          onClick={() => setInspectedDept(null)}
          style={{
            position: 'fixed',
            inset: 0,
            background: t.overlay,
            backdropFilter: 'blur(3px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 100,
            animation: 'fadeIn 0.15s ease',
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              width: 540,
              background: t.card,
              borderRadius: 18,
              border: `1px solid ${t.hairlineStrong}`,
              boxShadow: '0 32px 72px rgba(0,0,0,0.4)',
              overflow: 'hidden',
              animation: `riseIn 0.22s ${SPRING}`,
            }}
          >
            <div style={{ padding: '20px 24px', borderBottom: `1px solid ${t.hairline}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div className="flex items-center gap-2.5">
                <Building2 className="w-5 h-5 text-teal-400" />
                <div>
                  <h3 style={{ fontSize: 16, fontWeight: 700, color: t.textPrimary }}>
                    {inspectedDept.label} Division Dossier
                  </h3>
                  <p style={{ fontSize: 11.5, color: t.textSecondary }}>
                    Operating Unit Profile & Assurance Governance
                  </p>
                </div>
              </div>
              <button
                onClick={() => setInspectedDept(null)}
                style={{ background: 'none', border: 'none', color: t.textSecondary, cursor: 'pointer', fontSize: 18 }}
              >
                ×
              </button>
            </div>

            <div style={{ padding: '20px 24px', display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
                <div className="text-xs text-slate-400 font-medium">Division Summary</div>
                <p className="text-xs text-slate-200 leading-relaxed">
                  The {inspectedDept.label} division manages core retail and consumer workflows across 48 branches, automated clearing pipelines, and digital customer onboarding.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-900/40 border border-slate-800">
                  <span className="text-slate-400 block mb-1">Open Observations</span>
                  <span className="text-lg font-bold text-slate-100">{inspectedDept.count} Findings</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-900/40 border border-slate-800">
                  <span className="text-slate-400 block mb-1">Assurance Rating</span>
                  <span className="text-lg font-bold text-teal-400">Needs Improvement</span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  onClick={() => {
                    setActiveTab('universe');
                    setInspectedDept(null);
                  }}
                  className="px-4 py-2 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 text-xs font-semibold transition"
                >
                  View in Audit Universe →
                </button>
                <button
                  onClick={() => setInspectedDept(null)}
                  className="px-4 py-2 rounded-lg border border-slate-700 text-slate-300 text-xs font-semibold hover:bg-slate-800 transition"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* POPOUT 2: AUDITEE OWNER CONTACT & RESPONSIBILITY MODAL (Requirement 5) */}
      {inspectedOwner && (
        <div
          onClick={() => setInspectedOwner(null)}
          style={{
            position: 'fixed',
            inset: 0,
            background: t.overlay,
            backdropFilter: 'blur(3px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 100,
            animation: 'fadeIn 0.15s ease',
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              width: 500,
              background: t.card,
              borderRadius: 18,
              border: `1px solid ${t.hairlineStrong}`,
              boxShadow: '0 32px 72px rgba(0,0,0,0.4)',
              overflow: 'hidden',
              animation: `riseIn 0.22s ${SPRING}`,
            }}
          >
            <div style={{ padding: '20px 24px', borderBottom: `1px solid ${t.hairline}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-teal-500/20 text-teal-300 flex items-center justify-center font-bold text-xs">
                  {inspectedOwner.name.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <h3 style={{ fontSize: 16, fontWeight: 700, color: t.textPrimary }}>
                    {inspectedOwner.name}
                  </h3>
                  <p style={{ fontSize: 11.5, color: t.textSecondary }}>
                    {inspectedOwner.role} · {inspectedOwner.dept}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setInspectedOwner(null)}
                style={{ background: 'none', border: 'none', color: t.textSecondary, cursor: 'pointer', fontSize: 18 }}
              >
                ×
              </button>
            </div>

            <div style={{ padding: '20px 24px', display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-xs space-y-1">
                <span className="text-slate-400">Corporate Email:</span>
                <span className="font-mono text-teal-300 block">{inspectedOwner.email}</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-xs space-y-1">
                <span className="text-slate-400">Governance Escalation Authority:</span>
                <span className="text-slate-200 block font-medium">Designated 1st Line Control Owner with primary signatory delegation for CAP milestone completion.</span>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  onClick={() => {
                    showToast(`Dispatched executive email to ${inspectedOwner.name}`);
                    setInspectedOwner(null);
                  }}
                  className="flex-1 py-2 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 text-xs font-semibold transition"
                >
                  Send Urgent CAP Notification
                </button>
                <button
                  onClick={() => setInspectedOwner(null)}
                  className="px-4 py-2 rounded-lg border border-slate-700 text-slate-300 text-xs font-semibold hover:bg-slate-800 transition"
                >
                  Dismiss
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* POPOUT 3: CORRECTIVE ACTION PLAN (CAP) RECTIFICATION & EVIDENCE MODAL (Requirement 5) */}
      {capActionModalObs && (
        <div
          onClick={() => setCapActionModalObs(null)}
          style={{
            position: 'fixed',
            inset: 0,
            background: t.overlay,
            backdropFilter: 'blur(3px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 100,
            animation: 'fadeIn 0.15s ease',
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              width: 580,
              background: t.card,
              borderRadius: 18,
              border: `1px solid ${t.hairlineStrong}`,
              boxShadow: '0 32px 72px rgba(0,0,0,0.4)',
              overflow: 'hidden',
              animation: `riseIn 0.22s ${SPRING}`,
            }}
          >
            <div style={{ padding: '20px 24px', borderBottom: `1px solid ${t.hairline}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div className="flex items-center gap-2">
                <FileCheck className="w-5 h-5 text-teal-400" />
                <div>
                  <h3 style={{ fontSize: 16, fontWeight: 700, color: t.textPrimary }}>
                    Corrective Action Plan (CAP) Verification
                  </h3>
                  <p style={{ fontSize: 11.5, color: t.textSecondary }}>
                    Ref: {capActionModalObs.id} · Due: {capActionModalObs.dueDate}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setCapActionModalObs(null)}
                style={{ background: 'none', border: 'none', color: t.textSecondary, cursor: 'pointer', fontSize: 18 }}
              >
                ×
              </button>
            </div>

            <form onSubmit={handleCloseCAP} style={{ padding: '20px 24px', display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-xs">
                <span className="text-slate-400 font-semibold block mb-1">Target Finding:</span>
                <span className="text-slate-200 font-medium">{capActionModalObs.title}</span>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                  Remediation Evidence & Verification Note
                </label>
                <textarea
                  value={rectificationNote}
                  onChange={(e) => setRectificationNote(e.target.value)}
                  placeholder="Describe control adjustments, automated guardrails implemented, or attach testing evidence..."
                  rows={3}
                  className="w-full p-2.5 rounded-lg bg-slate-900/70 border border-slate-700 text-xs text-slate-200 outline-none focus:border-teal-400 transition"
                  required
                />
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => showToast('Corroborating file attachment uploaded')}
                  className="px-3 py-1.5 rounded-lg border border-slate-700 text-xs text-slate-300 hover:bg-slate-800 transition"
                >
                  + Attach Evidence File
                </button>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setCapActionModalObs(null)}
                    className="px-3 py-1.5 rounded-lg border border-slate-700 text-xs text-slate-300 hover:bg-slate-800 transition"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 text-xs font-semibold transition shadow-md shadow-teal-500/20"
                  >
                    Verify & Close CAP
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* POPOUT 4: FULL OBSERVATION DETAIL MODAL WITH REVIEW COMMENTS & WORKPAPER DOCK */}
      {selectedObservation && (
        <div
          onClick={() => setSelectedObservation(null)}
          style={{
            position: 'fixed',
            inset: 0,
            background: t.overlay,
            backdropFilter: 'blur(3px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 100,
            animation: 'fadeIn 0.15s ease',
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              width: 720,
              maxHeight: '85vh',
              background: t.card,
              borderRadius: 18,
              border: `1px solid ${t.hairlineStrong}`,
              boxShadow: '0 32px 72px rgba(0,0,0,0.4)',
              overflow: 'hidden',
              display: 'flex',
              flexDirection: 'column',
              animation: `riseIn 0.25s ${SPRING}`,
            }}
          >
            {/* Header */}
            <div
              style={{
                padding: '20px 26px',
                borderBottom: `1px solid ${t.hairline}`,
                display: 'flex',
                alignItems: 'flex-start',
                justifyContent: 'space-between',
              }}
            >
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                  <span
                    style={{
                      fontSize: 10.5,
                      fontWeight: 700,
                      color: selectedObservation.severity === 'critical' ? t.cinnabar : t.verdigris,
                      padding: '2px 7px',
                      borderRadius: 4,
                      background: selectedObservation.severity === 'critical' ? `${t.cinnabar}18` : `${t.verdigris}18`,
                      border: `1px solid ${selectedObservation.severity === 'critical' ? t.cinnabar : t.verdigris}40`,
                      textTransform: 'uppercase',
                    }}
                  >
                    {selectedObservation.severity}
                  </span>
                  <span style={{ fontSize: 11.5, color: t.textSecondary }}>
                    Observation Detail · {selectedObservation.department || selectedObservation.dept}
                  </span>
                </div>
                <div style={{ fontFamily: FONTS.sans, fontSize: 18, fontWeight: 700 }}>
                  {selectedObservation.title}
                </div>
              </div>

              <button
                onClick={() => setSelectedObservation(null)}
                style={{
                  background: 'none',
                  border: 'none',
                  color: t.textSecondary,
                  cursor: 'pointer',
                  fontSize: 18,
                  padding: 4,
                }}
              >
                ×
              </button>
            </div>

            {/* Content Body: All Fields CLICKABLE */}
            <div style={{ overflowY: 'auto', padding: '20px 26px', display: 'flex', flexDirection: 'column', gap: 16 }}>
              {/* Clickable Quick Action Ribbon */}
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(3, 1fr)',
                  gap: 10,
                }}
              >
                {/* Clickable Audit Report Link */}
                <button
                  onClick={() => {
                    const match = audits.find((a) => String(a.id) === String(selectedObservation.reportId) || a.title === selectedObservation.report);
                    if (match) setSelectedAuditForModal(match);
                    else showToast(`Opening dossier for "${selectedObservation.report}"`);
                  }}
                  style={{
                    padding: '10px 12px',
                    borderRadius: 10,
                    background: t.cardSunken,
                    border: `1px solid ${t.hairline}`,
                    textAlign: 'left',
                    cursor: 'pointer',
                  }}
                >
                  <div style={{ fontSize: 10.5, color: t.textSecondary, marginBottom: 2 }}>SOURCE AUDIT FILE (CLICK)</div>
                  <div style={{ fontSize: 12, fontWeight: 600, color: t.verdigris, textDecoration: 'underline' }}>
                    {selectedObservation.report} →
                  </div>
                </button>

                {/* Clickable Owner Profile */}
                <button
                  onClick={() => {
                    setInspectedOwner({
                      name: selectedObservation.owner || 'Chloe Bennett',
                      dept: selectedObservation.department || selectedObservation.dept,
                      role: 'Assigned Action Owner',
                      email: 'c.bennett@meridianbank.com',
                    });
                  }}
                  style={{
                    padding: '10px 12px',
                    borderRadius: 10,
                    background: t.cardSunken,
                    border: `1px solid ${t.hairline}`,
                    textAlign: 'left',
                    cursor: 'pointer',
                  }}
                >
                  <div style={{ fontSize: 10.5, color: t.textSecondary, marginBottom: 2 }}>ASSIGNED OWNER (CLICK)</div>
                  <div style={{ fontSize: 12, fontWeight: 600, color: t.textPrimary }}>
                    {selectedObservation.owner || 'Assigned Lead'}
                  </div>
                </button>

                {/* Clickable Due Date / Status */}
                <button
                  onClick={() => setCapActionModalObs(selectedObservation)}
                  style={{
                    padding: '10px 12px',
                    borderRadius: 10,
                    background: selectedObservation.overdue ? `${t.cinnabar}14` : t.cardSunken,
                    border: `1px solid ${selectedObservation.overdue ? t.cinnabar : t.hairline}`,
                    textAlign: 'left',
                    cursor: 'pointer',
                  }}
                >
                  <div style={{ fontSize: 10.5, color: selectedObservation.overdue ? t.cinnabar : t.textSecondary, marginBottom: 2 }}>
                    TARGET CLOSURE (CLICK)
                  </div>
                  <div style={{ fontSize: 12, fontWeight: 600, color: selectedObservation.overdue ? t.cinnabar : t.textPrimary }}>
                    {selectedObservation.dueDate} {selectedObservation.overdue ? '(OVERDUE)' : ''}
                  </div>
                </button>
              </div>

              {/* Finding Narrative & Root Cause */}
              <div>
                <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 6 }}>
                  Internal Audit Condition & Root Cause Finding
                </div>
                <p style={{ fontSize: 13, color: t.textPrimary, lineHeight: 1.6, background: t.cardSunken, padding: '12px 14px', borderRadius: 10 }}>
                  Testing of sample files identified repeated non-compliance with standard operating procedures. Control owners bypassed mandatory maker-checker validation during peak cycle processing.
                </p>
              </div>

              {/* Management Response & Action Plan */}
              <div>
                <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 6 }}>
                  Management Action Plan (CAP)
                </div>
                <p style={{ fontSize: 13, color: t.textPrimary, lineHeight: 1.6, background: t.cardSunken, padding: '12px 14px', borderRadius: 10 }}>
                  Business leadership has engaged engineering to implement mandatory hard validation rules preventing transaction execution without authenticated secondary cryptographic authorization.
                </p>
              </div>

              {/* Interactive Audit Trail / Review Comments */}
              <div>
                <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 8 }}>
                  Governance Review Comments ({selectedObservation.comments?.length || 0})
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 12 }}>
                  {selectedObservation.comments?.map((c: ObservationComment) => (
                    <div
                      key={c.id}
                      style={{
                        padding: '10px 12px',
                        borderRadius: 8,
                        background: t.cardSunken,
                        border: `1px solid ${t.hairline}`,
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                        <span style={{ fontSize: 12, fontWeight: 600 }}>{c.author}</span>
                        <span style={{ fontSize: 10.5, color: t.textSecondary }}>{c.timestamp}</span>
                      </div>
                      <div style={{ fontSize: 12.5, color: t.textPrimary }}>{c.text}</div>
                    </div>
                  ))}
                </div>

                {/* Add comment input */}
                <form onSubmit={handlePostComment} style={{ display: 'flex', gap: 8 }}>
                  <input
                    value={commentInput}
                    onChange={(e) => setCommentInput(e.target.value)}
                    placeholder="Add an internal auditor review note..."
                    style={{
                      flex: 1,
                      padding: '8px 12px',
                      borderRadius: 8,
                      background: t.cardSunken,
                      border: `1px solid ${t.hairline}`,
                      color: t.textPrimary,
                      fontSize: 12.5,
                      outline: 'none',
                    }}
                  />
                  <button
                    type="submit"
                    style={{
                      padding: '8px 14px',
                      borderRadius: 8,
                      border: 'none',
                      background: t.verdigris,
                      color: t.mode === 'dark' ? '#12151C' : '#FFFFFF',
                      fontSize: 12,
                      fontWeight: 600,
                      cursor: 'pointer',
                    }}
                  >
                    Post Note
                  </button>
                </form>
              </div>
            </div>

            {/* Footer */}
            <div
              style={{
                padding: '14px 26px',
                borderTop: `1px solid ${t.hairline}`,
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                background: t.cardSunken,
              }}
            >
              <div style={{ fontSize: 11.5, color: t.textSecondary }}>
                Status: <strong style={{ color: t.textPrimary }}>{selectedObservation.approval}</strong>
              </div>
              <button
                onClick={() => setCapActionModalObs(selectedObservation)}
                style={{
                  padding: '7px 16px',
                  borderRadius: 7,
                  border: 'none',
                  background: t.verdigris,
                  color: t.mode === 'dark' ? '#12151C' : '#FFFFFF',
                  fontSize: 12,
                  fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                Verify & Conclude CAP
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
