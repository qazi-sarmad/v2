import React, { useState, useEffect, useRef } from 'react';
import { useTheme, FONTS, SPRING, HOVER_EASE, HOVER_DUR } from '../../context/ThemeContext';
import { useApp } from '../../context/AppContext';
import { Icon } from '../common/Icons';
import { AuditEngagement, StepStatus } from '../../types';
import { CheckCircle2, ChevronRight, ExternalLink, Sparkles, X } from 'lucide-react';

const TODAY_YEAR = 2026;
const TODAY_MONTH = 8; // Sep (0-indexed)
const TODAY_DAY = 11;

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

function daysInMonth(year: number, month: number) {
  return new Date(year, month + 1, 0).getDate();
}

function firstWeekdayMonStart(year: number, month: number) {
  const jsDay = new Date(year, month, 1).getDay(); // 0=Sun
  return (jsDay + 6) % 7; // Monday-start
}

function monthKey(y: number, m: number) {
  return `${y}-${m}`;
}

function addMonths(y: number, m: number, delta: number) {
  const total = y * 12 + m + delta;
  return { year: Math.floor(total / 12), month: ((total % 12) + 12) % 12 };
}

export function CalendarWidget() {
  const { t } = useTheme();
  const { audits, toggleAuditStep, setSelectedAuditForModal } = useApp();
  const [open, setOpen] = useState(false);
  const [selectedAuditId, setSelectedAuditId] = useState<string | number | null>(null);

  // Unclipped, dedicated inspection state (Requirement 4)
  const [inspectedDay, setInspectedDay] = useState<{
    year: number;
    month: number;
    day: number;
    audits: AuditEngagement[];
  } | null>(null);

  const [monthRange, setMonthRange] = useState({ startOffset: -4, endOffset: 4 });
  const [focusedMonth, setFocusedMonth] = useState({ year: TODAY_YEAR, month: TODAY_MONTH });

  const rootRef = useRef<HTMLDivElement>(null);
  const anchorRef = useRef<HTMLButtonElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const monthRefs = useRef<Record<string, HTMLDivElement | null>>({});

  // Close on outside click or Escape
  useEffect(() => {
    if (!open) return;
    const onDocClick = (e: MouseEvent) => {
      if (
        rootRef.current &&
        !rootRef.current.contains(e.target as Node) &&
        anchorRef.current &&
        !anchorRef.current.contains(e.target as Node)
      ) {
        setOpen(false);
      }
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', onDocClick);
    window.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDocClick);
      window.removeEventListener('keydown', onKey);
    };
  }, [open]);

  // Center on today on first open
  useEffect(() => {
    if (!open) return;
    const id = requestAnimationFrame(() => {
      const el = monthRefs.current[monthKey(TODAY_YEAR, TODAY_MONTH)];
      if (el && scrollRef.current) {
        el.scrollIntoView({ block: 'center' });
      }
    });
    return () => cancelAnimationFrame(id);
  }, [open]);

  const onScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    const nearTop = el.scrollTop < 160;
    const nearBottom = el.scrollHeight - (el.scrollTop + el.clientHeight) < 160;
    if (nearTop) setMonthRange((r) => ({ ...r, startOffset: r.startOffset - 3 }));
    if (nearBottom) setMonthRange((r) => ({ ...r, endOffset: r.endOffset + 3 }));

    const rect = el.getBoundingClientRect();
    const centerY = rect.top + rect.height / 2;
    let closestKey: string | null = null;
    let closestDist = Infinity;
    Object.entries(monthRefs.current).forEach(([key, node]) => {
      if (!node) return;
      const r = node.getBoundingClientRect();
      const dist = Math.abs(r.top + r.height / 2 - centerY);
      if (dist < closestDist) {
        closestDist = dist;
        closestKey = key;
      }
    });
    if (closestKey) {
      const [y, m] = (closestKey as string).split('-').map(Number);
      setFocusedMonth((prev) => (prev.year === y && prev.month === m ? prev : { year: y, month: m }));
    }
  };

  const jumpToToday = () => {
    setSelectedAuditId(null);
    setInspectedDay(null);
    const el = monthRefs.current[monthKey(TODAY_YEAR, TODAY_MONTH)];
    if (el) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
  };

  // Helper to test if an audit active dates span the given day
  const getAuditsForDay = (year: number, month: number, day: number) => {
    const dStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return audits.filter((a) => {
      return a.start <= dStr && a.end >= dStr;
    });
  };

  const monthsList = [];
  for (let off = monthRange.startOffset; off <= monthRange.endOffset; off++) {
    monthsList.push(addMonths(TODAY_YEAR, TODAY_MONTH, off));
  }

  const selectedAudit = audits.find((a) => String(a.id) === String(selectedAuditId));

  return (
    <div style={{ position: 'relative' }}>
      <button
        ref={anchorRef}
        onClick={() => setOpen((o) => !o)}
        title="Quick calendar panel (Infinite scroll & test steps)"
        style={{
          width: 34,
          height: 34,
          borderRadius: 8,
          border: `1px solid ${open ? t.hairlineStrong : t.hairline}`,
          background: open ? t.cardSunken : t.card,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          cursor: 'pointer',
          transition: `background ${HOVER_DUR} ${HOVER_EASE}, border-color ${HOVER_DUR} ${HOVER_EASE}`,
        }}
      >
        {Icon.calendar(open ? t.verdigris : t.textSecondary)}
      </button>

      {/* Floating Panel (Positioned & Sized with high-end aesthetics) */}
      <div
        ref={rootRef}
        style={{
          position: 'absolute',
          top: 'calc(100% + 10px)',
          right: -40,
          zIndex: 70,
          width: inspectedDay ? 560 : 360,
          transformOrigin: 'top right',
          background: t.card,
          border: `1px solid ${t.hairlineStrong}`,
          borderRadius: 18,
          boxShadow: '0 28px 72px rgba(0,0,0,0.45)',
          overflow: 'hidden',
          display: 'flex',
          transform: open ? 'scale(1) translateY(0)' : 'scale(0.92) translateY(-12px)',
          opacity: open ? 1 : 0,
          pointerEvents: open ? 'auto' : 'none',
          transition: `width 0.26s ${SPRING}, transform 0.38s ${SPRING}, opacity 0.24s ${HOVER_EASE}`,
        }}
      >
        {/* Main Calendar Scroll Column */}
        <div style={{ width: 360, flexShrink: 0, display: 'flex', flexDirection: 'column' }}>
          {/* Header with Month / Today */}
          <div style={{ padding: '16px 20px 10px', borderBottom: `1px solid ${t.hairline}` }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontFamily: FONTS.serif, fontSize: 16, fontWeight: 600 }}>
                {MONTH_NAMES[focusedMonth.month]} {focusedMonth.year}
              </span>
              <div style={{ display: 'flex', gap: 6 }}>
                <button
                  onClick={jumpToToday}
                  style={{
                    fontSize: 11,
                    fontWeight: 600,
                    color: t.verdigris,
                    background: `${t.verdigris}14`,
                    border: `1px solid ${t.verdigris}35`,
                    borderRadius: 6,
                    padding: '3px 8px',
                    cursor: 'pointer',
                  }}
                >
                  Today
                </button>
                <button
                  onClick={() => setOpen(false)}
                  style={{
                    width: 22,
                    height: 22,
                    borderRadius: 4,
                    background: 'none',
                    border: 'none',
                    color: t.textSecondary,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 4, marginTop: 12 }}>
              {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((d, i) => (
                <div
                  key={i}
                  style={{
                    fontSize: 10.5,
                    color: t.textSecondary,
                    textAlign: 'center',
                    fontWeight: 600,
                  }}
                >
                  {d}
                </div>
              ))}
            </div>
          </div>

          {/* Selected Audit Quick Pill */}
          {selectedAudit && (
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                background: `${t.verdigris}14`,
                border: `1px solid ${t.verdigris}40`,
                borderRadius: 8,
                padding: '6px 10px',
                margin: '8px 16px 0',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, overflow: 'hidden' }}>
                <div style={{ width: 6, height: 6, borderRadius: '50%', background: t.verdigris, flexShrink: 0 }} />
                <span style={{ fontSize: 11, fontWeight: 600, color: t.verdigris, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {selectedAudit.title}
                </span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <button
                  onClick={() => setSelectedAuditForModal(selectedAudit)}
                  style={{
                    background: 'none',
                    border: 'none',
                    fontSize: 10.5,
                    fontWeight: 600,
                    color: t.verdigris,
                    textDecoration: 'underline',
                    cursor: 'pointer',
                  }}
                >
                  Open
                </button>
                <button
                  onClick={() => setSelectedAuditId(null)}
                  style={{ background: 'none', border: 'none', color: t.textSecondary, cursor: 'pointer', fontSize: 13 }}
                >
                  ×
                </button>
              </div>
            </div>
          )}

          {/* Infinite Scrollport with Sexy Custom Scrollbar (Requirement 4) */}
          <div
            ref={scrollRef}
            onScroll={onScroll}
            className="custom-scrollbar"
            style={{
              height: 380,
              overflowY: 'auto',
              padding: '12px 16px',
              scrollbarWidth: 'thin',
              scrollbarColor: `${t.verdigris}40 transparent`,
            }}
          >
            {monthsList.map(({ year, month }) => {
              const k = monthKey(year, month);
              const numDays = daysInMonth(year, month);
              const offset = firstWeekdayMonStart(year, month);
              const totalCells = offset + numDays;
              const rows = Math.ceil(totalCells / 7);

              return (
                <div
                  key={k}
                  ref={(node) => {
                    monthRefs.current[k] = node;
                  }}
                  style={{ marginBottom: 24 }}
                >
                  {/* Month Label */}
                  <div
                    style={{
                      fontSize: 12,
                      fontWeight: 700,
                      color: t.textSecondary,
                      letterSpacing: 0.4,
                      marginBottom: 8,
                      textTransform: 'uppercase',
                    }}
                  >
                    {MONTH_NAMES[month]} {year}
                  </div>

                  {/* Days Matrix */}
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 4 }}>
                    {Array.from({ length: rows * 7 }).map((_, idx) => {
                      const dayNum = idx - offset + 1;
                      if (dayNum < 1 || dayNum > numDays) {
                        return <div key={idx} style={{ height: 32 }} />;
                      }

                      const dayAudits = getAuditsForDay(year, month, dayNum);
                      const isToday = year === TODAY_YEAR && month === TODAY_MONTH && dayNum === TODAY_DAY;
                      const hasAudits = dayAudits.length > 0;
                      const hasOverdue = dayAudits.some((a) => a.status === 'overdue');
                      const isInspected =
                        inspectedDay?.year === year &&
                        inspectedDay?.month === month &&
                        inspectedDay?.day === dayNum;

                      return (
                        <div
                          key={idx}
                          onClick={() => {
                            if (hasAudits) {
                              setInspectedDay({ year, month, day: dayNum, audits: dayAudits });
                            } else {
                              setInspectedDay(null);
                            }
                          }}
                          style={{
                            height: 34,
                            borderRadius: 8,
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            justifyContent: 'center',
                            cursor: hasAudits ? 'pointer' : 'default',
                            position: 'relative',
                            background: isInspected
                              ? `${t.verdigris}24`
                              : isToday
                              ? t.verdigris
                              : hasAudits
                              ? t.cardSunken
                              : 'transparent',
                            border: isInspected
                              ? `1.5px solid ${t.verdigris}`
                              : isToday
                              ? 'none'
                              : hasAudits
                              ? `1px solid ${t.hairline}`
                              : '1px solid transparent',
                            color: isToday ? (t.mode === 'dark' ? '#12151C' : '#FFFFFF') : t.textPrimary,
                            transition: `all 0.16s ${HOVER_EASE}`,
                            transform: isInspected ? 'scale(1.08)' : 'scale(1)',
                          }}
                        >
                          <span style={{ fontSize: 11, fontWeight: isToday || isInspected ? 700 : 500 }}>
                            {dayNum}
                          </span>

                          {/* Audit Indicator Dot */}
                          {hasAudits && (
                            <div
                              style={{
                                width: 4,
                                height: 4,
                                borderRadius: '50%',
                                background: isToday
                                  ? (t.mode === 'dark' ? '#12151C' : '#FFFFFF')
                                  : hasOverdue
                                  ? t.cinnabar
                                  : t.verdigris,
                                marginTop: 1,
                              }}
                            />
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Micro-state legend */}
          <div
            style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '6px 12px',
              padding: '10px 16px',
              borderTop: `1px solid ${t.hairline}`,
              background: t.cardSunken,
            }}
          >
            {[
              ['Today', t.verdigris],
              ['Active audit', `${t.verdigris}90`],
              ['Overdue item', t.cinnabar],
            ].map(([label, col]) => (
              <div key={label} style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                <div style={{ width: 7, height: 7, borderRadius: '50%', background: col as string }} />
                <span style={{ fontSize: 10, color: t.textSecondary }}>{label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* UNCLIPPED Dedicated Day Inspection Panel (Requirement 4) */}
        {inspectedDay && (
          <div
            style={{
              width: 200,
              flexShrink: 0,
              borderLeft: `1px solid ${t.hairline}`,
              background: t.cardSunken,
              padding: '16px 14px',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              animation: `fadeIn 0.2s ease`,
            }}
          >
            <div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
                <span style={{ fontSize: 10.5, fontWeight: 700, color: t.textSecondary, letterSpacing: 0.3 }}>
                  {MONTH_NAMES[inspectedDay.month].slice(0, 3)} {inspectedDay.day}, {inspectedDay.year}
                </span>
                <button
                  onClick={() => setInspectedDay(null)}
                  style={{ background: 'none', border: 'none', color: t.textSecondary, cursor: 'pointer', fontSize: 14 }}
                >
                  ×
                </button>
              </div>

              <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 8, color: t.textPrimary }}>
                {inspectedDay.audits.length} Engagement{inspectedDay.audits.length > 1 ? 's' : ''} Active:
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {inspectedDay.audits.map((audit) => {
                  return (
                    <div
                      key={audit.id}
                      style={{
                        padding: '10px 10px',
                        borderRadius: 9,
                        background: t.card,
                        border: `1px solid ${t.hairline}`,
                        display: 'flex',
                        flexDirection: 'column',
                        gap: 6,
                      }}
                    >
                      <div style={{ fontSize: 12, fontWeight: 600, lineHeight: 1.25, color: t.textPrimary }}>
                        {audit.title}
                      </div>
                      <div style={{ fontSize: 10.5, color: t.textSecondary }}>
                        Lead: {audit.leadAuditorName}
                      </div>

                      {/* Milestone toggles */}
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 4 }}>
                        {(['fieldwork', 'review', 'signoff'] as const).map((stepKey) => {
                          const s = audit.steps[stepKey];
                          return (
                            <button
                              key={stepKey}
                              onClick={() => toggleAuditStep(audit.id, stepKey)}
                              title={`Toggle ${stepKey}`}
                              style={{
                                width: 15,
                                height: 15,
                                borderRadius: '50%',
                                border: `1px solid ${s === 'reviewed' ? t.verdigris : s === 'in_progress' ? t.verdigris : t.textSecondary}`,
                                background: s === 'in_progress' ? t.verdigris : s === 'reviewed' ? `${t.verdigris}30` : 'transparent',
                                cursor: 'pointer',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                              }}
                            >
                              {s === 'reviewed' && <CheckCircle2 className="w-3 h-3 text-teal-400" />}
                            </button>
                          );
                        })}
                      </div>

                      <button
                        onClick={() => {
                          setSelectedAuditForModal(audit);
                          setOpen(false);
                        }}
                        style={{
                          marginTop: 6,
                          width: '100%',
                          padding: '5px 0',
                          borderRadius: 6,
                          background: `${t.verdigris}18`,
                          border: `1px solid ${t.verdigris}35`,
                          color: t.verdigris,
                          fontSize: 10.5,
                          fontWeight: 600,
                          cursor: 'pointer',
                        }}
                      >
                        Inspect Audit File →
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            <div style={{ fontSize: 10, color: t.textSecondary, textAlign: 'center', marginTop: 12 }}>
              Unclipped Executive Pop-out View
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
