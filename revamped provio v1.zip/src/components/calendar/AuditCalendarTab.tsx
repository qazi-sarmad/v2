import React, { useState, useMemo } from 'react';
import { useTheme, FONTS, SPRING, HOVER_EASE, HOVER_DUR } from '../../context/ThemeContext';
import { useApp } from '../../context/AppContext';
import { Icon } from '../common/Icons';
import { AuditEngagement, AuditStage, AuditStatus, StepStatus } from '../../types';

type CalendarViewMode = 'month' | 'schedule' | 'year';

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

export function AuditCalendarTab() {
  const { t } = useTheme();
  const {
    audits,
    people,
    entities,
    toggleAuditStep,
    addAudit,
    setSelectedAuditForModal,
    showToast,
  } = useApp();

  const [viewMode, setViewMode] = useState<CalendarViewMode>('month');
  const [currentYear, setCurrentYear] = useState(2026);
  const [currentMonth, setCurrentMonth] = useState(8); // 8 = Sep 2026
  const [selectedDay, setSelectedDay] = useState<number | null>(11); // default Sep 11, 2026

  // Filters
  const [deptFilter, setDeptFilter] = useState<string>('all');
  const [auditorFilter, setAuditorFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Schedule modal
  const [scheduleModalOpen, setScheduleModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDept, setNewDept] = useState('Retail Banking');
  const [newEntityId, setNewEntityId] = useState(entities[0]?.id || '');
  const [newLeadId, setNewLeadId] = useState(people[0]?.id || '');
  const [newStart, setNewStart] = useState('2026-09-15');
  const [newEnd, setNewEnd] = useState('2026-10-15');
  const [newSampleSize, setNewSampleSize] = useState(60);
  const [newScope, setNewScope] = useState('');

  // Filtered audits
  const filteredAudits = useMemo(() => {
    return audits.filter((a) => {
      if (deptFilter !== 'all' && a.dept !== deptFilter) return false;
      if (auditorFilter !== 'all' && a.leadAuditorId !== auditorFilter) return false;
      if (statusFilter !== 'all' && a.status !== statusFilter) return false;
      return true;
    });
  }, [audits, deptFilter, auditorFilter, statusFilter]);

  const prevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear((y) => y - 1);
    } else {
      setCurrentMonth((m) => m - 1);
    }
  };

  const nextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear((y) => y + 1);
    } else {
      setCurrentMonth((m) => m + 1);
    }
  };

  const jumpToCurrent = () => {
    setCurrentYear(2026);
    setCurrentMonth(8);
    setSelectedDay(11);
  };

  // Helper for month grid
  const daysCount = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDayWeekday = (new Date(currentYear, currentMonth, 1).getDay() + 6) % 7; // Monday start
  const calendarCells: (number | null)[] = [];
  for (let i = 0; i < firstDayWeekday; i++) calendarCells.push(null);
  for (let d = 1; d <= daysCount; d++) calendarCells.push(d);

  // Audits active on a day
  const getAuditsOnDay = (day: number) => {
    const dStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return filteredAudits.filter((a) => a.start <= dStr && a.end >= dStr);
  };

  const selectedDayAudits = selectedDay ? getAuditsOnDay(selectedDay) : [];

  const handleCreateEngagement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) {
      showToast('Please provide an engagement title');
      return;
    }
    const lead = people.find((p) => p.id === newLeadId);
    addAudit({
      title: newTitle,
      dept: newDept,
      entityId: newEntityId,
      start: newStart,
      end: newEnd,
      status: 'upcoming',
      stage: 'planning',
      leadAuditorId: newLeadId,
      leadAuditorName: lead?.name || 'Assigned Auditor',
      steps: { fieldwork: 'not_started', review: 'not_started', signoff: 'not_started' },
      scopeSummary: newScope || 'Scheduled internal audit assessment per universe plan.',
      sampleSize: newSampleSize,
      exceptionsCount: 0,
      controlsTotal: 12,
      controlsTested: 0,
      dea: { status: 'not_started', effective: 0, ineffective: 0 },
      oet: { status: 'not_started', effective: 0, ineffective: 0 },
      reportIssued: false,
    });
    setScheduleModalOpen(false);
    setNewTitle('');
    setNewScope('');
  };

  const getStatusColor = (status: AuditStatus) => {
    switch (status) {
      case 'overdue':
        return t.cinnabar;
      case 'in_progress':
        return t.verdigris;
      case 'upcoming':
        return t.blueAccent;
      default:
        return t.textSecondary;
    }
  };

  return (
    <div style={{ padding: '32px 48px', maxWidth: 1360, margin: '0 auto', position: 'relative' }}>
      {/* Title & Toolbar */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 24, flexWrap: 'wrap', gap: 16 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <span style={{ fontFamily: FONTS.serif, fontSize: 26, fontWeight: 600 }}>
              Audit Execution & Milestone Calendar
            </span>
          </div>
          <p style={{ color: t.textSecondary, fontSize: 13.5 }}>
            Live orchestration of fieldwork testing, reviewer sign-offs, and board milestone deadlines.
          </p>
        </div>

        {/* View Switcher & Action */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div
            style={{
              display: 'flex',
              padding: 3,
              borderRadius: 9,
              background: t.cardSunken,
              border: `1px solid ${t.hairline}`,
            }}
          >
            {(['month', 'schedule', 'year'] as const).map((mode) => (
              <button
                key={mode}
                onClick={() => setViewMode(mode)}
                style={{
                  padding: '6px 14px',
                  borderRadius: 7,
                  border: 'none',
                  background: viewMode === mode ? t.card : 'transparent',
                  color: viewMode === mode ? t.textPrimary : t.textSecondary,
                  fontSize: 12.5,
                  fontWeight: viewMode === mode ? 600 : 500,
                  cursor: 'pointer',
                  boxShadow: viewMode === mode ? '0 2px 6px rgba(0,0,0,0.08)' : 'none',
                  transition: `all ${HOVER_DUR} ${HOVER_EASE}`,
                  textTransform: 'capitalize',
                }}
              >
                {mode === 'month' ? 'Month Grid' : mode === 'schedule' ? 'Swimlanes' : 'Year Heatmap'}
              </button>
            ))}
          </div>

          <button
            onClick={() => setScheduleModalOpen(true)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              padding: '8px 14px',
              borderRadius: 9,
              border: 'none',
              background: t.verdigris,
              color: t.mode === 'dark' ? '#12151C' : '#FFFFFF',
              fontSize: 12.5,
              fontWeight: 600,
              cursor: 'pointer',
              boxShadow: '0 4px 14px rgba(0,0,0,0.18)',
              transition: `transform 0.2s ${SPRING}`,
            }}
          >
            {Icon.plus(t.mode === 'dark' ? '#12151C' : '#FFFFFF')}
            Schedule Audit
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 14,
          padding: '10px 18px',
          borderRadius: 12,
          background: t.card,
          border: `1px solid ${t.hairline}`,
          marginBottom: 24,
          flexWrap: 'wrap',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: t.textSecondary, fontSize: 12 }}>
          {Icon.filter(t.textSecondary)}
          <span>Filters:</span>
        </div>

        {/* Dept filter */}
        <select
          value={deptFilter}
          onChange={(e) => setDeptFilter(e.target.value)}
          style={{
            background: t.cardSunken,
            color: t.textPrimary,
            border: `1px solid ${t.hairline}`,
            borderRadius: 7,
            padding: '5px 10px',
            fontSize: 12,
            outline: 'none',
            fontFamily: FONTS.sans,
          }}
        >
          <option value="all">All Departments (5)</option>
          <option value="Retail Banking">Retail Banking</option>
          <option value="Treasury">Treasury</option>
          <option value="Deposit Operations">Deposit Operations</option>
          <option value="Procurement">Procurement</option>
          <option value="IT & Cyber Operations">IT & Cyber</option>
        </select>

        {/* Auditor filter */}
        <select
          value={auditorFilter}
          onChange={(e) => setAuditorFilter(e.target.value)}
          style={{
            background: t.cardSunken,
            color: t.textPrimary,
            border: `1px solid ${t.hairline}`,
            borderRadius: 7,
            padding: '5px 10px',
            fontSize: 12,
            outline: 'none',
            fontFamily: FONTS.sans,
          }}
        >
          <option value="all">All Lead Auditors ({people.length})</option>
          {people.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name} ({p.roleTitle})
            </option>
          ))}
        </select>

        {/* Status filter */}
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          style={{
            background: t.cardSunken,
            color: t.textPrimary,
            border: `1px solid ${t.hairline}`,
            borderRadius: 7,
            padding: '5px 10px',
            fontSize: 12,
            outline: 'none',
            fontFamily: FONTS.sans,
          }}
        >
          <option value="all">All Statuses</option>
          <option value="in_progress">In Progress</option>
          <option value="overdue">Overdue</option>
          <option value="upcoming">Upcoming</option>
          <option value="concluded_this_year">Concluded this year</option>
        </select>

        {(deptFilter !== 'all' || auditorFilter !== 'all' || statusFilter !== 'all') && (
          <button
            onClick={() => {
              setDeptFilter('all');
              setAuditorFilter('all');
              setStatusFilter('all');
            }}
            style={{
              background: 'none',
              border: 'none',
              color: t.cinnabar,
              fontSize: 11.5,
              fontWeight: 600,
              cursor: 'pointer',
              textDecoration: 'underline',
              marginLeft: 'auto',
            }}
          >
            Clear filters
          </button>
        )}
      </div>

      {/* Main Content Area based on ViewMode */}
      {viewMode === 'month' && (
        <div style={{ display: 'grid', gridTemplateColumns: selectedDay ? '1fr 340px' : '1fr', gap: 24, alignItems: 'start' }}>
          {/* Calendar Grid Container */}
          <div
            style={{
              background: t.card,
              border: `1px solid ${t.hairline}`,
              borderRadius: 16,
              padding: 24,
              boxShadow: '0 4px 20px rgba(0,0,0,0.06)',
            }}
          >
            {/* Month Navigation Banner */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <span style={{ fontFamily: FONTS.serif, fontSize: 20, fontWeight: 600 }}>
                  {MONTH_NAMES[currentMonth]} {currentYear}
                </span>
                <button
                  onClick={jumpToCurrent}
                  style={{
                    fontSize: 11.5,
                    fontWeight: 600,
                    color: t.verdigris,
                    background: `${t.verdigris}14`,
                    border: `1px solid ${t.verdigris}40`,
                    borderRadius: 6,
                    padding: '4px 10px',
                    cursor: 'pointer',
                  }}
                >
                  Current (Sep 2026)
                </button>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <button
                  onClick={prevMonth}
                  title="Previous month"
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: 8,
                    border: `1px solid ${t.hairline}`,
                    background: t.cardSunken,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                  }}
                >
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                    <path d="M7.5 9.5L4 6L7.5 2.5" stroke={t.textPrimary} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
                <button
                  onClick={nextMonth}
                  title="Next month"
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: 8,
                    border: `1px solid ${t.hairline}`,
                    background: t.cardSunken,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                  }}
                >
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                    <path d="M4.5 2.5L8 6L4.5 9.5" stroke={t.textPrimary} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
              </div>
            </div>

            {/* Weekday headers */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 8, marginBottom: 8 }}>
              {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map((w) => (
                <div
                  key={w}
                  style={{
                    fontSize: 11,
                    fontWeight: 600,
                    color: t.textSecondary,
                    textAlign: 'center',
                    padding: '6px 0',
                  }}
                >
                  {w}
                </div>
              ))}
            </div>

            {/* Grid Days */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 8 }}>
              {calendarCells.map((dayNum, idx) => {
                if (dayNum === null) {
                  return (
                    <div
                      key={`empty-${idx}`}
                      style={{
                        minHeight: 104,
                        borderRadius: 10,
                        background: `${t.cardSunken}40`,
                        border: `1px dashed ${t.hairline}`,
                      }}
                    />
                  );
                }

                const dayAudits = getAuditsOnDay(dayNum);
                const isToday = currentYear === 2026 && currentMonth === 8 && dayNum === 11;
                const isSelected = selectedDay === dayNum;

                return (
                  <div
                    key={dayNum}
                    onClick={() => setSelectedDay(dayNum)}
                    style={{
                      minHeight: 104,
                      borderRadius: 10,
                      padding: '8px 8px',
                      background: isSelected
                        ? (t.mode === 'dark' ? 'rgba(111,166,148,0.12)' : 'rgba(78,135,120,0.08)')
                        : t.cardSunken,
                      border: isSelected
                        ? `1.5px solid ${t.verdigris}`
                        : `1px solid ${t.hairline}`,
                      cursor: 'pointer',
                      display: 'flex',
                      flexDirection: 'column',
                      transition: `transform 0.2s ${HOVER_EASE}, border-color 0.2s ease`,
                      transform: isSelected ? 'scale(1.02)' : 'scale(1)',
                    }}
                  >
                    {/* Day number header */}
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
                      <span
                        style={{
                          fontSize: 12,
                          fontWeight: isToday || isSelected ? 700 : 500,
                          width: 22,
                          height: 22,
                          borderRadius: '50%',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          background: isToday ? t.verdigris : 'transparent',
                          color: isToday
                            ? (t.mode === 'dark' ? '#12151C' : '#FFFFFF')
                            : t.textPrimary,
                        }}
                      >
                        {dayNum}
                      </span>

                      {dayAudits.length > 0 && (
                        <span style={{ fontSize: 10, color: t.textSecondary, fontWeight: 600 }}>
                          {dayAudits.length} act.
                        </span>
                      )}
                    </div>

                    {/* Chips for active audits */}
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 4, flex: 1 }}>
                      {dayAudits.slice(0, 2).map((audit) => {
                        const col = getStatusColor(audit.status);
                        return (
                          <div
                            key={audit.id}
                            title={`${audit.title} (${audit.stage})`}
                            style={{
                              padding: '3px 6px',
                              borderRadius: 5,
                              background: `${col}18`,
                              border: `1px solid ${col}45`,
                              fontSize: 10.5,
                              fontWeight: 600,
                              color: col,
                              whiteSpace: 'nowrap',
                              overflow: 'hidden',
                              textOverflow: 'ellipsis',
                              lineHeight: 1.2,
                            }}
                          >
                            {audit.title}
                          </div>
                        );
                      })}
                      {dayAudits.length > 2 && (
                        <div style={{ fontSize: 9.5, color: t.textSecondary, fontWeight: 600, paddingLeft: 2 }}>
                          +{dayAudits.length - 2} more
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Interactive Day Inspector Drawer */}
          {selectedDay && (
            <div
              style={{
                background: t.card,
                border: `1px solid ${t.hairlineStrong}`,
                borderRadius: 16,
                padding: '20px 20px',
                boxShadow: '0 8px 30px rgba(0,0,0,0.12)',
                position: 'sticky',
                top: 24,
                animation: `previewIn 0.22s ${HOVER_EASE}`,
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14, borderBottom: `1px solid ${t.hairline}`, paddingBottom: 10 }}>
                <div>
                  <div style={{ fontSize: 11, color: t.textSecondary, fontWeight: 600, letterSpacing: 0.3 }}>
                    DAY INSPECTION
                  </div>
                  <div style={{ fontFamily: FONTS.serif, fontSize: 17, fontWeight: 600 }}>
                    {MONTH_NAMES[currentMonth]} {selectedDay}, {currentYear}
                  </div>
                </div>
                <button
                  onClick={() => setSelectedDay(null)}
                  style={{
                    background: 'none',
                    border: 'none',
                    color: t.textSecondary,
                    cursor: 'pointer',
                    fontSize: 16,
                    padding: 4,
                  }}
                >
                  ×
                </button>
              </div>

              {selectedDayAudits.length === 0 ? (
                <div style={{ padding: '30px 10px', textAlign: 'center', color: t.textSecondary, fontSize: 12.5 }}>
                  No active audit fieldwork or sign-offs scheduled for this date.
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                  {selectedDayAudits.map((audit) => {
                    const col = getStatusColor(audit.status);
                    return (
                      <div
                        key={audit.id}
                        style={{
                          padding: '12px 14px',
                          borderRadius: 12,
                          background: t.cardSunken,
                          border: `1px solid ${t.hairline}`,
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8, marginBottom: 6 }}>
                          <span style={{ fontSize: 13, fontWeight: 600, lineHeight: 1.3 }}>
                            {audit.title}
                          </span>
                          <span
                            style={{
                              fontSize: 10,
                              fontWeight: 700,
                              color: col,
                              padding: '2px 6px',
                              borderRadius: 4,
                              background: `${col}15`,
                              border: `1px solid ${col}35`,
                              whiteSpace: 'nowrap',
                            }}
                          >
                            {audit.status.replace(/_/g, ' ')}
                          </span>
                        </div>

                        <div style={{ fontSize: 11.5, color: t.textSecondary, marginBottom: 8 }}>
                          Lead: <span style={{ color: t.textPrimary, fontWeight: 500 }}>{audit.leadAuditorName}</span> · {audit.dept}
                        </div>

                        {/* Interactive Steps */}
                        <div style={{ marginBottom: 10, padding: '8px 10px', background: t.card, borderRadius: 8, border: `1px solid ${t.hairline}` }}>
                          <div style={{ fontSize: 10.5, fontWeight: 600, color: t.textSecondary, marginBottom: 6 }}>
                            MILESTONE PROGRESS (CLICK TO TOGGLE):
                          </div>
                          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                            {(['fieldwork', 'review', 'signoff'] as const).map((stepKey) => {
                              const s = audit.steps[stepKey];
                              return (
                                <button
                                  key={stepKey}
                                  onClick={() => toggleAuditStep(audit.id, stepKey)}
                                  style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 5,
                                    background: 'none',
                                    border: 'none',
                                    cursor: 'pointer',
                                    padding: '2px 4px',
                                  }}
                                >
                                  <div
                                    style={{
                                      width: 14,
                                      height: 14,
                                      borderRadius: '50%',
                                      border: `1.5px solid ${s === 'reviewed' ? t.verdigris : s === 'in_progress' ? t.verdigris : t.textSecondary}`,
                                      background: s === 'in_progress' ? t.verdigris : s === 'reviewed' ? `${t.verdigris}25` : 'transparent',
                                      display: 'flex',
                                      alignItems: 'center',
                                      justifyContent: 'center',
                                    }}
                                  >
                                    {s === 'reviewed' && (
                                      <svg width="8" height="8" viewBox="0 0 8 8">
                                        <path d="M2 4L3.5 5.5L6.5 2.5" stroke={t.verdigris} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" fill="none" />
                                      </svg>
                                    )}
                                  </div>
                                  <span style={{ fontSize: 11, color: t.textPrimary, textTransform: 'capitalize' }}>
                                    {stepKey}
                                  </span>
                                </button>
                              );
                            })}
                          </div>
                        </div>

                        {/* Open Audit File CTA */}
                        <button
                          onClick={() => setSelectedAuditForModal(audit)}
                          style={{
                            width: '100%',
                            padding: '7px 0',
                            borderRadius: 8,
                            border: `1px solid ${t.hairlineStrong}`,
                            background: t.card,
                            color: t.textPrimary,
                            fontSize: 11.5,
                            fontWeight: 600,
                            cursor: 'pointer',
                          }}
                        >
                          View Workpapers & Findings ({audit.sampleSize} files)
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Swimlane / Schedule View */}
      {viewMode === 'schedule' && (
        <div
          style={{
            background: t.card,
            border: `1px solid ${t.hairline}`,
            borderRadius: 16,
            padding: 24,
          }}
        >
          <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 16 }}>
            Multi-Week Engagement Swimlanes ({filteredAudits.length} Audits)
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {filteredAudits.map((audit) => {
              const col = getStatusColor(audit.status);
              return (
                <div
                  key={audit.id}
                  onClick={() => setSelectedAuditForModal(audit)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '14px 18px',
                    borderRadius: 10,
                    background: t.cardSunken,
                    border: `1px solid ${t.hairline}`,
                    cursor: 'pointer',
                    transition: `transform 0.2s ${HOVER_EASE}`,
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.borderColor = t.hairlineStrong)}
                  onMouseLeave={(e) => (e.currentTarget.style.borderColor = t.hairline)}
                >
                  <div style={{ minWidth: 260 }}>
                    <div style={{ fontSize: 13.5, fontWeight: 600, marginBottom: 2 }}>{audit.title}</div>
                    <div style={{ fontSize: 11.5, color: t.textSecondary }}>
                      {audit.dept} · Lead: {audit.leadAuditorName}
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                    <div style={{ fontSize: 11.5, color: t.textSecondary }}>
                      {audit.start} — {audit.end}
                    </div>
                    <span
                      style={{
                        fontSize: 11,
                        fontWeight: 600,
                        color: col,
                        padding: '3px 8px',
                        borderRadius: 6,
                        background: `${col}15`,
                        border: `1px solid ${col}40`,
                      }}
                    >
                      {audit.status.replace(/_/g, ' ')}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Year Heatmap View */}
      {viewMode === 'year' && (
        <div
          style={{
            background: t.card,
            border: `1px solid ${t.hairline}`,
            borderRadius: 16,
            padding: 24,
          }}
        >
          <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 4 }}>
            2026 Audit Coverage Heatmap
          </div>
          <div style={{ fontSize: 12, color: t.textSecondary, marginBottom: 20 }}>
            Annual distribution of fieldwork density and quarterly reporting milestones.
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
            {MONTH_NAMES.map((mName, mIdx) => {
              const mStr = `2026-${String(mIdx + 1).padStart(2, '0')}`;
              const countInMonth = audits.filter((a) => a.start.startsWith(mStr) || a.end.startsWith(mStr)).length;
              return (
                <div
                  key={mName}
                  onClick={() => {
                    setCurrentMonth(mIdx);
                    setViewMode('month');
                  }}
                  style={{
                    padding: '14px 16px',
                    borderRadius: 10,
                    background: t.cardSunken,
                    border: `1px solid ${t.hairline}`,
                    cursor: 'pointer',
                    transition: `transform 0.2s ${HOVER_EASE}`,
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.borderColor = t.verdigris)}
                  onMouseLeave={(e) => (e.currentTarget.style.borderColor = t.hairline)}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                    <span style={{ fontSize: 12.5, fontWeight: 600 }}>{mName}</span>
                    <span style={{ fontSize: 11, fontWeight: 700, color: countInMonth > 0 ? t.verdigris : t.textSecondary }}>
                      {countInMonth} Audits
                    </span>
                  </div>
                  <div style={{ display: 'flex', gap: 4 }}>
                    {Array.from({ length: 4 }).map((_, wIdx) => (
                      <div
                        key={wIdx}
                        style={{
                          height: 8,
                          flex: 1,
                          borderRadius: 3,
                          background: countInMonth > wIdx ? t.verdigris : t.hairline,
                          opacity: countInMonth > wIdx ? 0.8 : 0.3,
                        }}
                      />
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Schedule Engagement Modal */}
      {scheduleModalOpen && (
        <div
          onClick={() => setScheduleModalOpen(false)}
          style={{
            position: 'fixed',
            inset: 0,
            background: t.overlay,
            backdropFilter: 'blur(3px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 100,
            animation: 'fadeIn 0.15s ease',
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              width: 520,
              background: t.card,
              borderRadius: 18,
              border: `1px solid ${t.hairlineStrong}`,
              boxShadow: '0 32px 72px rgba(0,0,0,0.4)',
              overflow: 'hidden',
              animation: `riseIn 0.25s ${SPRING}`,
            }}
          >
            <div style={{ padding: '18px 24px', borderBottom: `1px solid ${t.hairline}` }}>
              <div style={{ fontSize: 11, color: t.textSecondary, fontWeight: 600, letterSpacing: 0.3 }}>
                AUDIT SCHEDULING ORCHESTRATION
              </div>
              <div style={{ fontSize: 16, fontWeight: 600 }}>Schedule New Audit Engagement</div>
            </div>

            <form onSubmit={handleCreateEngagement} style={{ padding: '20px 24px' }}>
              <div style={{ marginBottom: 14 }}>
                <label style={{ fontSize: 11.5, fontWeight: 600, color: t.textSecondary, display: 'block', marginBottom: 4 }}>
                  Engagement Title *
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Wire Transfer Maker-Checker Q4 Assessment"
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    borderRadius: 8,
                    background: t.cardSunken,
                    border: `1px solid ${t.hairline}`,
                    color: t.textPrimary,
                    fontSize: 13,
                    fontFamily: FONTS.sans,
                    outline: 'none',
                  }}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 14 }}>
                <div>
                  <label style={{ fontSize: 11.5, fontWeight: 600, color: t.textSecondary, display: 'block', marginBottom: 4 }}>
                    Department
                  </label>
                  <select
                    value={newDept}
                    onChange={(e) => setNewDept(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '8px 10px',
                      borderRadius: 8,
                      background: t.cardSunken,
                      border: `1px solid ${t.hairline}`,
                      color: t.textPrimary,
                      fontSize: 12.5,
                      fontFamily: FONTS.sans,
                      outline: 'none',
                    }}
                  >
                    <option value="Retail Banking">Retail Banking</option>
                    <option value="Treasury">Treasury</option>
                    <option value="Deposit Operations">Deposit Operations</option>
                    <option value="Procurement">Procurement</option>
                    <option value="IT & Cyber Operations">IT & Cyber Operations</option>
                  </select>
                </div>

                <div>
                  <label style={{ fontSize: 11.5, fontWeight: 600, color: t.textSecondary, display: 'block', marginBottom: 4 }}>
                    Lead Auditor
                  </label>
                  <select
                    value={newLeadId}
                    onChange={(e) => setNewLeadId(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '8px 10px',
                      borderRadius: 8,
                      background: t.cardSunken,
                      border: `1px solid ${t.hairline}`,
                      color: t.textPrimary,
                      fontSize: 12.5,
                      fontFamily: FONTS.sans,
                      outline: 'none',
                    }}
                  >
                    {people.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} ({p.roleTitle})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 14 }}>
                <div>
                  <label style={{ fontSize: 11.5, fontWeight: 600, color: t.textSecondary, display: 'block', marginBottom: 4 }}>
                    Start Date
                  </label>
                  <input
                    type="date"
                    required
                    value={newStart}
                    onChange={(e) => setNewStart(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '8px 10px',
                      borderRadius: 8,
                      background: t.cardSunken,
                      border: `1px solid ${t.hairline}`,
                      color: t.textPrimary,
                      fontSize: 12.5,
                      fontFamily: FONTS.sans,
                      outline: 'none',
                    }}
                  />
                </div>

                <div>
                  <label style={{ fontSize: 11.5, fontWeight: 600, color: t.textSecondary, display: 'block', marginBottom: 4 }}>
                    End Date
                  </label>
                  <input
                    type="date"
                    required
                    value={newEnd}
                    onChange={(e) => setNewEnd(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '8px 10px',
                      borderRadius: 8,
                      background: t.cardSunken,
                      border: `1px solid ${t.hairline}`,
                      color: t.textPrimary,
                      fontSize: 12.5,
                      fontFamily: FONTS.sans,
                      outline: 'none',
                    }}
                  />
                </div>
              </div>

              <div style={{ marginBottom: 14 }}>
                <label style={{ fontSize: 11.5, fontWeight: 600, color: t.textSecondary, display: 'block', marginBottom: 4 }}>
                  Auditable Entity (from Audit Universe)
                </label>
                <select
                  value={newEntityId}
                  onChange={(e) => setNewEntityId(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '8px 10px',
                    borderRadius: 8,
                    background: t.cardSunken,
                    border: `1px solid ${t.hairline}`,
                    color: t.textPrimary,
                    fontSize: 12.5,
                    fontFamily: FONTS.sans,
                    outline: 'none',
                  }}
                >
                  {entities.map((ent) => (
                    <option key={ent.id} value={ent.id}>
                      {ent.name} ({ent.inherentRisk.toUpperCase()} Risk)
                    </option>
                  ))}
                </select>
              </div>

              <div style={{ marginBottom: 18 }}>
                <label style={{ fontSize: 11.5, fontWeight: 600, color: t.textSecondary, display: 'block', marginBottom: 4 }}>
                  Scope Summary & Sampling Notes
                </label>
                <textarea
                  rows={3}
                  value={newScope}
                  onChange={(e) => setNewScope(e.target.value)}
                  placeholder="Testing objectives, sampling methodology, and key risks to inspect..."
                  style={{
                    width: '100%',
                    padding: '8px 10px',
                    borderRadius: 8,
                    background: t.cardSunken,
                    border: `1px solid ${t.hairline}`,
                    color: t.textPrimary,
                    fontSize: 12.5,
                    fontFamily: FONTS.sans,
                    outline: 'none',
                    resize: 'none',
                  }}
                />
              </div>

              <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
                <button
                  type="button"
                  onClick={() => setScheduleModalOpen(false)}
                  style={{
                    padding: '8px 16px',
                    borderRadius: 8,
                    border: `1px solid ${t.hairline}`,
                    background: 'none',
                    color: t.textSecondary,
                    fontSize: 12.5,
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  style={{
                    padding: '8px 18px',
                    borderRadius: 8,
                    border: 'none',
                    background: t.verdigris,
                    color: t.mode === 'dark' ? '#12151C' : '#FFFFFF',
                    fontSize: 12.5,
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  Confirm & Schedule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
