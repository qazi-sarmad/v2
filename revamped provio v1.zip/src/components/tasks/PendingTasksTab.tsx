import React, { useState, useMemo } from 'react';
import {
  CheckCircle2,
  Clock,
  AlertTriangle,
  FileCheck,
  ShieldCheck,
  MessageSquare,
  BadgeCheck,
  Lock,
  ArrowRight,
  Filter,
  Search,
  Check,
  Calendar,
  Layers,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';
import { useTheme, FONTS, HOVER_DUR, HOVER_EASE } from '../../context/ThemeContext';
import { useApp } from '../../context/AppContext';
import { AuditEngagement, AuditControlItem, Observation } from '../../types';

export function PendingTasksTab() {
  const { t } = useTheme();
  const {
    audits,
    departments,
    reviewComments,
    activeUser,
    people,
    setSelectedAuditForModal,
    setSelectedObservation,
    setReviewDrawerOpen,
    showToast,
    setActiveTab,
  } = useApp();

  const [categoryFilter, setCategoryFilter] = useState<'all' | 'dea' | 'oet' | 'reviews' | 'cap' | 'signoff'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [assigneeFilter, setAssigneeFilter] = useState<'me' | 'all'>('me');

  // 1. Gather all DEA & OET controls needing action
  const allControlsNeedingTesting = useMemo(() => {
    const list: { audit: AuditEngagement; control: AuditControlItem; type: 'dea' | 'oet' }[] = [];
    audits.forEach((audit) => {
      (audit.controlsList || []).forEach((ctrl) => {
        if (ctrl.deaStatus === 'Pending Walkthrough') {
          list.push({ audit, control: ctrl, type: 'dea' });
        }
        if (ctrl.oetStatus === 'Testing In Progress' || ctrl.oetStatus === 'Not Started') {
          list.push({ audit, control: ctrl, type: 'oet' });
        }
      });
    });
    return list;
  }, [audits]);

  // 2. Open Review Notes
  const openReviewComments = useMemo(() => {
    return reviewComments.filter((c) => c.status === 'open');
  }, [reviewComments]);

  // 3. CAP Corrective Actions due or overdue
  const pendingCaps = useMemo(() => {
    return departments.flatMap((d) =>
      d.observations.filter((o) => !o.closureDate && o.reportIssued)
    );
  }, [departments]);

  // 4. Draft Observations pending report finalization
  const draftObservations = useMemo(() => {
    return departments.flatMap((d) =>
      d.observations.filter((o) => !o.reportIssued || o.isDraft)
    );
  }, [departments]);

  // 5. Engagements awaiting CAE final report issuance
  const auditsAwaitingIssuance = useMemo(() => {
    return audits.filter((a) => !a.reportIssued && a.steps.fieldwork === 'reviewed');
  }, [audits]);

  // Total summary metrics
  const totalTasks =
    allControlsNeedingTesting.length +
    openReviewComments.length +
    pendingCaps.length +
    auditsAwaitingIssuance.length;

  const overdueCount = pendingCaps.filter((c) => c.overdue).length;

  return (
    <div
      style={{
        padding: '24px 28px 60px',
        maxWidth: 1380,
        margin: '0 auto',
        fontFamily: FONTS.sans,
      }}
    >
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 24 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <span
              style={{
                fontFamily: FONTS.sans,
                fontSize: 10.5,
                fontWeight: 700,
                color: t.verdigris,
                textTransform: 'uppercase',
                letterSpacing: 0.5,
              }}
            >
              Auditor Work Queue & Action Center
            </span>
            <span style={{ fontSize: 11, color: t.textSecondary }}>·</span>
            <span style={{ fontSize: 11, color: t.textSecondary }}>
              Logged as: <strong style={{ color: t.textPrimary }}>{activeUser.name}</strong> ({activeUser.roleTitle})
            </span>
          </div>
          <h1
            style={{
              fontFamily: FONTS.serif,
              fontSize: 24,
              fontWeight: 600,
              color: t.textPrimary,
              margin: 0,
            }}
          >
            Pending Tasks & Action Items
          </h1>
        </div>

        {/* Filter Controls */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              borderRadius: 8,
              border: `1px solid ${t.hairline}`,
              background: t.cardSunken,
              padding: 2,
            }}
          >
            <button
              onClick={() => setAssigneeFilter('me')}
              style={{
                padding: '5px 12px',
                borderRadius: 6,
                border: 'none',
                background: assigneeFilter === 'me' ? t.card : 'transparent',
                color: assigneeFilter === 'me' ? t.textPrimary : t.textSecondary,
                fontSize: 12,
                fontWeight: 600,
                cursor: 'pointer',
              }}
            >
              My Action Items
            </button>
            <button
              onClick={() => setAssigneeFilter('all')}
              style={{
                padding: '5px 12px',
                borderRadius: 6,
                border: 'none',
                background: assigneeFilter === 'all' ? t.card : 'transparent',
                color: assigneeFilter === 'all' ? t.textPrimary : t.textSecondary,
                fontSize: 12,
                fontWeight: 600,
                cursor: 'pointer',
              }}
            >
              All Engagement Tasks
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards Strip */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 14, marginBottom: 24 }}>
        {/* Total Pending */}
        <div
          style={{
            padding: '16px 18px',
            borderRadius: 12,
            background: t.card,
            border: `1px solid ${t.hairline}`,
          }}
        >
          <div style={{ fontSize: 11, color: t.textSecondary, fontWeight: 600, marginBottom: 4 }}>TOTAL PENDING</div>
          <div style={{ fontSize: 24, fontWeight: 700, color: t.textPrimary }}>{totalTasks}</div>
          <div style={{ fontSize: 11, color: t.textSecondary, marginTop: 2 }}>Actionable audit tasks</div>
        </div>

        {/* Overdue CAPs (Cinnabar) */}
        <div
          style={{
            padding: '16px 18px',
            borderRadius: 12,
            background: t.card,
            border: `1px solid ${overdueCount > 0 ? 'rgba(239,68,68,0.3)' : t.hairline}`,
          }}
        >
          <div style={{ fontSize: 11, color: '#EF4444', fontWeight: 600, marginBottom: 4 }}>OVERDUE FINDINGS (SLA)</div>
          <div style={{ fontSize: 24, fontWeight: 700, color: '#EF4444' }}>{overdueCount}</div>
          <div style={{ fontSize: 11, color: t.textSecondary, marginTop: 2 }}>Requires escalation</div>
        </div>

        {/* Controls Tested Pending */}
        <div
          style={{
            padding: '16px 18px',
            borderRadius: 12,
            background: t.card,
            border: `1px solid ${t.hairline}`,
          }}
        >
          <div style={{ fontSize: 11, color: t.verdigris, fontWeight: 600, marginBottom: 4 }}>DEA / OET TESTING</div>
          <div style={{ fontSize: 24, fontWeight: 700, color: t.textPrimary }}>
            {allControlsNeedingTesting.length}
          </div>
          <div style={{ fontSize: 11, color: t.textSecondary, marginTop: 2 }}>Walkthroughs & sampling</div>
        </div>

        {/* Open Review Notes */}
        <div
          style={{
            padding: '16px 18px',
            borderRadius: 12,
            background: t.card,
            border: `1px solid ${t.hairline}`,
          }}
        >
          <div style={{ fontSize: 11, color: '#38BDF8', fontWeight: 600, marginBottom: 4 }}>OPEN REVIEW NOTES</div>
          <div style={{ fontSize: 24, fontWeight: 700, color: t.textPrimary }}>{openReviewComments.length}</div>
          <div style={{ fontSize: 11, color: t.textSecondary, marginTop: 2 }}>Maker-checker feedback</div>
        </div>

        {/* Final Reports Awaiting Sign-off */}
        <div
          style={{
            padding: '16px 18px',
            borderRadius: 12,
            background: t.card,
            border: `1px solid ${t.hairline}`,
          }}
        >
          <div style={{ fontSize: 11, color: '#10B981', fontWeight: 600, marginBottom: 4 }}>REPORTS FOR ISSUANCE</div>
          <div style={{ fontSize: 24, fontWeight: 700, color: t.textPrimary }}>{auditsAwaitingIssuance.length}</div>
          <div style={{ fontSize: 11, color: t.textSecondary, marginTop: 2 }}>Ready for CAE seal</div>
        </div>
      </div>

      {/* Category Filter Pills */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 20, overflowX: 'auto' }}>
        {[
          { id: 'all', label: 'All Tasks', count: totalTasks },
          { id: 'dea', label: 'DEA Walkthroughs', count: allControlsNeedingTesting.filter((c) => c.type === 'dea').length },
          { id: 'oet', label: 'OET Sampling & Population', count: allControlsNeedingTesting.filter((c) => c.type === 'oet').length },
          { id: 'reviews', label: 'Review Notes', count: openReviewComments.length },
          { id: 'cap', label: 'CAP Corrective Actions', count: pendingCaps.length },
          { id: 'signoff', label: 'Audit Report Issuance', count: auditsAwaitingIssuance.length },
        ].map((cat) => (
          <button
            key={cat.id}
            onClick={() => setCategoryFilter(cat.id as any)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              padding: '6px 12px',
              borderRadius: 8,
              border: `1px solid ${categoryFilter === cat.id ? t.verdigris : t.hairline}`,
              background: categoryFilter === cat.id ? `${t.verdigris}18` : t.card,
              color: categoryFilter === cat.id ? t.verdigris : t.textSecondary,
              fontSize: 12,
              fontWeight: 600,
              cursor: 'pointer',
              transition: `all ${HOVER_DUR} ${HOVER_EASE}`,
            }}
          >
            <span>{cat.label}</span>
            <span
              style={{
                fontSize: 10,
                fontWeight: 700,
                padding: '1px 6px',
                borderRadius: 999,
                background: categoryFilter === cat.id ? t.verdigris : t.cardSunken,
                color: categoryFilter === cat.id ? '#10151E' : t.textPrimary,
              }}
            >
              {cat.count}
            </span>
          </button>
        ))}
      </div>

      {/* Task List */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {/* 1. DEA & OET Controls Requiring Action */}
        {(categoryFilter === 'all' || categoryFilter === 'dea' || categoryFilter === 'oet') &&
          allControlsNeedingTesting
            .filter((item) => (categoryFilter === 'all' ? true : item.type === categoryFilter))
            .map(({ audit, control, type }) => (
              <div
                key={`${audit.id}_${control.id}_${type}`}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  padding: '16px 20px',
                  borderRadius: 12,
                  background: t.card,
                  border: `1px solid ${t.hairline}`,
                  transition: `border-color ${HOVER_DUR} ${HOVER_EASE}`,
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                  <div
                    style={{
                      width: 36,
                      height: 36,
                      borderRadius: 10,
                      background: type === 'dea' ? 'rgba(45,212,191,0.15)' : 'rgba(99,102,241,0.15)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    {type === 'dea' ? (
                      <ShieldCheck className="w-4 h-4 text-teal-400" />
                    ) : (
                      <FileCheck className="w-4 h-4 text-indigo-400" />
                    )}
                  </div>
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 2 }}>
                      <span
                        style={{
                          fontSize: 10.5,
                          fontWeight: 700,
                          fontFamily: FONTS.mono,
                          padding: '1px 6px',
                          borderRadius: 4,
                          background: t.cardSunken,
                          color: t.verdigris,
                        }}
                      >
                        {control.code}
                      </span>
                      <span style={{ fontSize: 11, color: t.textSecondary }}>· {audit.title}</span>
                      <span
                        style={{
                          fontSize: 10,
                          fontWeight: 700,
                          padding: '1px 6px',
                          borderRadius: 4,
                          background: type === 'dea' ? 'rgba(45,212,191,0.12)' : 'rgba(99,102,241,0.12)',
                          color: type === 'dea' ? '#2DD4BF' : '#818CF8',
                        }}
                      >
                        {type === 'dea' ? 'DEA WALKTHROUGH' : 'OET POPULATION & SAMPLE'}
                      </span>
                    </div>
                    <div style={{ fontSize: 13, fontWeight: 600, color: t.textPrimary }}>
                      {control.name}
                    </div>
                    <div style={{ fontSize: 11.5, color: t.textSecondary, marginTop: 2 }}>
                      In-Charge: <strong style={{ color: t.textPrimary }}>{control.assignedAuditor || audit.leadAuditorName}</strong> · Standard: {control.type} ({control.frequency})
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => setSelectedAuditForModal(audit)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                    padding: '8px 14px',
                    borderRadius: 8,
                    border: 'none',
                    background: t.verdigris,
                    color: t.mode === 'dark' ? '#10151E' : '#FFFFFF',
                    fontSize: 12,
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  <span>Open Working Paper</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}

        {/* 2. Open Review Notes */}
        {(categoryFilter === 'all' || categoryFilter === 'reviews') &&
          openReviewComments.map((comm) => (
            <div
              key={comm.id}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '16px 20px',
                borderRadius: 12,
                background: t.card,
                border: `1px solid ${t.hairline}`,
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                <div
                  style={{
                    width: 36,
                    height: 36,
                    borderRadius: 10,
                    background: 'rgba(56,189,248,0.15)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <MessageSquare className="w-4 h-4 text-sky-400" />
                </div>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 2 }}>
                    <span style={{ fontSize: 10.5, fontWeight: 700, color: '#38BDF8' }}>REVIEW NOTE #{comm.id}</span>
                    <span style={{ fontSize: 11, color: t.textSecondary }}>· File: {comm.doc}</span>
                    <span style={{ fontSize: 10, color: t.textSecondary }}>({comm.time})</span>
                  </div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: t.textPrimary }}>
                    {comm.comment}
                  </div>
                  <div style={{ fontSize: 11.5, color: t.textSecondary, marginTop: 2 }}>
                    From: <strong style={{ color: t.textPrimary }}>{comm.author}</strong> ({comm.role}) · {comm.replies.length} replies
                  </div>
                </div>
              </div>

              <button
                onClick={() => setReviewDrawerOpen(true)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  padding: '8px 14px',
                  borderRadius: 8,
                  border: `1px solid ${t.hairline}`,
                  background: t.cardSunken,
                  color: t.textPrimary,
                  fontSize: 12,
                  fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                <span>Respond to Note</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}

        {/* 3. CAP Remediation Actions */}
        {(categoryFilter === 'all' || categoryFilter === 'cap') &&
          pendingCaps.map((cap) => (
            <div
              key={cap.id}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '16px 20px',
                borderRadius: 12,
                background: t.card,
                border: `1px solid ${cap.overdue ? 'rgba(239,68,68,0.35)' : t.hairline}`,
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                <div
                  style={{
                    width: 36,
                    height: 36,
                    borderRadius: 10,
                    background: cap.overdue ? 'rgba(239,68,68,0.15)' : 'rgba(245,158,11,0.15)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <AlertTriangle className="w-4 h-4" style={{ color: cap.overdue ? '#EF4444' : '#F59E0B' }} />
                </div>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 2 }}>
                    <span
                      style={{
                        fontSize: 10,
                        fontWeight: 700,
                        textTransform: 'uppercase',
                        padding: '1px 6px',
                        borderRadius: 4,
                        background: cap.overdue ? 'rgba(239,68,68,0.15)' : 'rgba(245,158,11,0.15)',
                        color: cap.overdue ? '#EF4444' : '#F59E0B',
                      }}
                    >
                      {cap.overdue ? 'OVERDUE CAP' : 'ACTIVE CAP'}
                    </span>
                    <span style={{ fontSize: 11, color: t.textSecondary }}>· Due: {cap.dueDate}</span>
                    <span style={{ fontSize: 11, color: t.textSecondary }}>· {cap.dept}</span>
                  </div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: t.textPrimary }}>
                    {cap.title}
                  </div>
                  <div style={{ fontSize: 11.5, color: t.textSecondary, marginTop: 2 }}>
                    Assigned Owner: <strong style={{ color: t.textPrimary }}>{cap.capOwner || cap.owner}</strong>
                  </div>
                </div>
              </div>

              <button
                onClick={() => {
                  setSelectedObservation(cap);
                  setActiveTab('issues');
                }}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  padding: '8px 14px',
                  borderRadius: 8,
                  border: `1px solid ${t.hairline}`,
                  background: t.cardSunken,
                  color: t.textPrimary,
                  fontSize: 12,
                  fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                <span>Inspect in CAP Register</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}

        {/* 4. Audits Awaiting Final Sign-off & Issuance */}
        {(categoryFilter === 'all' || categoryFilter === 'signoff') &&
          auditsAwaitingIssuance.map((aud) => (
            <div
              key={aud.id}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '16px 20px',
                borderRadius: 12,
                background: t.card,
                border: '1px solid rgba(16,185,129,0.3)',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                <div
                  style={{
                    width: 36,
                    height: 36,
                    borderRadius: 10,
                    background: 'rgba(16,185,129,0.15)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <BadgeCheck className="w-4 h-4 text-emerald-400" />
                </div>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 2 }}>
                    <span style={{ fontSize: 10, fontWeight: 700, padding: '1px 6px', borderRadius: 4, background: 'rgba(16,185,129,0.2)', color: '#34D399' }}>
                      FIELDWORK COMPLETE
                    </span>
                    <span style={{ fontSize: 11, color: t.textSecondary }}>· Ready for Final Executive Report Issuance</span>
                  </div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: t.textPrimary }}>
                    {aud.title}
                  </div>
                  <div style={{ fontSize: 11.5, color: t.textSecondary, marginTop: 2 }}>
                    Lead: <strong style={{ color: t.textPrimary }}>{aud.leadAuditorName}</strong> · {aud.controlsTested}/{aud.controlsTotal} controls evaluated
                  </div>
                </div>
              </div>

              <button
                onClick={() => setSelectedAuditForModal(aud)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  padding: '8px 14px',
                  borderRadius: 8,
                  border: 'none',
                  background: '#10B981',
                  color: '#0A0E17',
                  fontSize: 12,
                  fontWeight: 700,
                  cursor: 'pointer',
                }}
              >
                <span>Finalize & Issue Report</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
      </div>
    </div>
  );
}
