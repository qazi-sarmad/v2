import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useTheme, FONTS, SPRING, EASE, HOVER_EASE } from '../../context/ThemeContext';
import { useApp, TabId } from '../../context/AppContext';
import { Icon } from './Icons';

interface PaletteItem {
  group: string;
  label: string;
  tab?: TabId;
  action?: string;
}

export function CommandPalette() {
  const { t } = useTheme();
  const {
    commandPaletteOpen,
    setCommandPaletteOpen,
    setActiveTab,
    setPeopleModalOpen,
    setReviewDrawerOpen,
    setSupabaseModalOpen,
    runLogicSimulation,
    triggerTimeWarp,
  } = useApp();

  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const items: PaletteItem[] = useMemo(
    () => [
      { group: 'Navigate', label: 'Executive Dashboard', tab: 'dashboard' },
      { group: 'Navigate', label: 'Audit Calendar & Execution Grid', tab: 'calendar' },
      { group: 'Navigate', label: 'Audit Universe & Entity Planning', tab: 'universe' },
      { group: 'Navigate', label: 'CAE Visual Methodology & Logic Studio', tab: 'logic' },
      { group: 'Navigate', label: 'Issues Register & CAP Tracking', tab: 'issues' },
      { group: 'Navigate', label: 'Audit Plan & Multi-Year Mandate', tab: 'plan' },

      { group: 'Actions', label: 'Team Roster, Defined Roles & Permissions', action: 'open_people' },
      { group: 'Actions', label: 'Executive Review Comments & Maker-Checker Trail', action: 'open_reviews' },
      { group: 'Actions', label: 'Supabase Database Connection & Migration Schema', action: 'open_supabase' },
      { group: 'Actions', label: 'Test-Run Methodology Logic Simulation', action: 'run_simulation' },
      { group: 'Actions', label: 'Engage Hyperloop Time-Warp to 2023 Baseline', action: 'warp_2023' },
      { group: 'Actions', label: 'Engage Hyperloop Time-Warp to 2026 Live Cycle', action: 'warp_2026' },

      { group: 'Recent Audits', label: 'Loan Origination — Q3 Control Test (Fieldwork)', tab: 'dashboard' },
      { group: 'Recent Audits', label: 'Treasury — Wire Transfer & Maker-Checker Review', tab: 'dashboard' },
      { group: 'Recent Audits', label: 'SWIFT Infrastructure Gateway CSP v2024 Audit', tab: 'universe' },
    ],
    []
  );

  useEffect(() => {
    if (commandPaletteOpen) {
      setQuery('');
      setSelected(0);
      setTimeout(() => inputRef.current?.focus(), 60);
    }
  }, [commandPaletteOpen]);

  const filtered = useMemo(() => {
    if (!query.trim()) return items;
    const q = query.toLowerCase();
    return items.filter(
      (i) => i.label.toLowerCase().includes(q) || i.group.toLowerCase().includes(q)
    );
  }, [items, query]);

  useEffect(() => {
    if (!commandPaletteOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setCommandPaletteOpen(false);
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelected((s) => Math.min(s + 1, filtered.length - 1));
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelected((s) => Math.max(s - 1, 0));
      }
      if (e.key === 'Enter' && filtered[selected]) {
        executeItem(filtered[selected]);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [commandPaletteOpen, filtered, selected]);

  const executeItem = (item: PaletteItem) => {
    if (item.tab) setActiveTab(item.tab);
    if (item.action === 'open_people') setPeopleModalOpen(true);
    if (item.action === 'open_reviews') setReviewDrawerOpen(true);
    if (item.action === 'open_supabase') setSupabaseModalOpen(true);
    if (item.action === 'run_simulation') runLogicSimulation();
    if (item.action === 'warp_2023') triggerTimeWarp(2023);
    if (item.action === 'warp_2026') triggerTimeWarp(2026);
    setCommandPaletteOpen(false);
  };

  if (!commandPaletteOpen) return null;

  let lastGroup: string | null = null;

  return (
    <div
      onClick={() => setCommandPaletteOpen(false)}
      style={{
        position: 'fixed',
        inset: 0,
        background: t.overlay,
        backdropFilter: 'blur(3px)',
        display: 'flex',
        alignItems: 'flex-start',
        justifyContent: 'center',
        paddingTop: '12vh',
        zIndex: 120,
        animation: 'fadeIn 0.15s ease',
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: 580,
          maxHeight: '65vh',
          background: t.card,
          borderRadius: 16,
          border: `1px solid ${t.hairlineStrong}`,
          boxShadow: '0 24px 60px rgba(0,0,0,0.38)',
          overflow: 'hidden',
          animation: `riseIn 0.18s ${EASE}`,
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 12,
            padding: '16px 18px',
            borderBottom: `1px solid ${t.hairline}`,
          }}
        >
          {Icon.search(t.textSecondary)}
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelected(0);
            }}
            placeholder="Search audits, entities, methodology logic, reports, team..."
            style={{
              flex: 1,
              border: 'none',
              outline: 'none',
              background: 'none',
              color: t.textPrimary,
              fontSize: 14.5,
              fontFamily: FONTS.sans,
            }}
          />
        </div>

        <div style={{ overflowY: 'auto', padding: '8px 10px', flex: 1 }}>
          {filtered.map((item, i) => {
            const showGroup = item.group !== lastGroup;
            lastGroup = item.group;
            return (
              <div key={`${item.group}-${item.label}`}>
                {showGroup && (
                  <div
                    style={{
                      fontSize: 10.5,
                      color: t.textSecondary,
                      padding: '8px 10px 4px',
                      fontWeight: 700,
                      letterSpacing: 0.3,
                      textTransform: 'uppercase',
                    }}
                  >
                    {item.group}
                  </div>
                )}
                <button
                  onClick={() => executeItem(item)}
                  onMouseEnter={() => setSelected(i)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    width: '100%',
                    padding: '9px 12px',
                    borderRadius: 8,
                    border: 'none',
                    cursor: 'pointer',
                    textAlign: 'left',
                    background: selected === i ? t.cardSunken : 'transparent',
                    color: t.textPrimary,
                    fontSize: 13.5,
                    fontFamily: FONTS.sans,
                  }}
                >
                  <span>{item.label}</span>
                  {selected === i && (
                    <span style={{ fontSize: 11, color: t.verdigris, fontWeight: 600 }}>
                      Jump ↵
                    </span>
                  )}
                </button>
              </div>
            );
          })}

          {filtered.length === 0 && (
            <div style={{ padding: '28px 10px', textAlign: 'center', color: t.textSecondary, fontSize: 13 }}>
              No matching records found for "{query}"
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
