import React from 'react';
import { useTheme, FONTS, SPRING } from '../../context/ThemeContext';
import { useApp } from '../../context/AppContext';

export function KeyboardShortcutsModal() {
  const { t } = useTheme();
  const { shortcutsModalOpen, setShortcutsModalOpen } = useApp();

  if (!shortcutsModalOpen) return null;

  const shortcuts = [
    { key: '← / →', desc: 'Navigate previous / next tab (Dashboard, Calendar, Universe, Logic, etc.)' },
    { key: 'Backspace', desc: 'Navigate back to previous view in history stack (or close open modal)' },
    { key: 'Esc', desc: 'Instantly dismiss any open popover, drawer, or modal' },
    { key: 'Ctrl / Cmd + K', desc: 'Open Command Palette to search audits, controls, and reports' },
    { key: '↑ / ↓', desc: 'Vertical navigation across action items and calendar rows' },
    { key: '?', desc: 'Toggle this keyboard shortcut guide' },
  ];

  return (
    <div
      onClick={() => setShortcutsModalOpen(false)}
      style={{
        position: 'fixed',
        inset: 0,
        background: t.overlay,
        backdropFilter: 'blur(3px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 120,
        animation: 'fadeIn 0.15s ease',
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: 500,
          background: t.card,
          borderRadius: 18,
          border: `1px solid ${t.hairlineStrong}`,
          boxShadow: '0 32px 72px rgba(0,0,0,0.4)',
          overflow: 'hidden',
          animation: `riseIn 0.25s ${SPRING}`,
        }}
      >
        <div
          style={{
            padding: '20px 24px',
            borderBottom: `1px solid ${t.hairline}`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <div>
            <div style={{ fontSize: 11, color: t.textSecondary, fontWeight: 600, letterSpacing: 0.3 }}>
              KEYBOARD NAVIGATION & SHORTCUTS
            </div>
            <div style={{ fontFamily: FONTS.serif, fontSize: 17, fontWeight: 600 }}>
              Tactile Executive Navigation Controls
            </div>
          </div>
          <button
            onClick={() => setShortcutsModalOpen(false)}
            style={{
              background: 'none',
              border: 'none',
              color: t.textSecondary,
              cursor: 'pointer',
              fontSize: 18,
              padding: 4,
            }}
          >
            ×
          </button>
        </div>

        <div style={{ padding: '16px 24px', display: 'flex', flexDirection: 'column', gap: 10 }}>
          {shortcuts.map(({ key, desc }) => (
            <div
              key={key}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '10px 14px',
                borderRadius: 10,
                background: t.cardSunken,
                border: `1px solid ${t.hairline}`,
              }}
            >
              <span style={{ fontSize: 13, color: t.textPrimary }}>{desc}</span>
              <kbd
                style={{
                  fontFamily: FONTS.mono,
                  fontSize: 11,
                  fontWeight: 600,
                  padding: '4px 8px',
                  borderRadius: 6,
                  background: t.card,
                  border: `1px solid ${t.hairlineStrong}`,
                  color: t.textPrimary,
                  boxShadow: '0 1px 3px rgba(0,0,0,0.06)',
                }}
              >
                {key}
              </kbd>
            </div>
          ))}
        </div>

        <div
          style={{
            padding: '14px 24px',
            background: t.cardSunken,
            borderTop: `1px solid ${t.hairline}`,
            textAlign: 'center',
            fontSize: 11.5,
            color: t.textSecondary,
          }}
        >
          Press <kbd style={{ padding: '2px 5px', borderRadius: 4, background: t.card, border: `1px solid ${t.hairline}` }}>Esc</kbd> or click outside to dismiss
        </div>
      </div>
    </div>
  );
}
