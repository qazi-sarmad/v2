import React from 'react';

export const Icon = {
  dashboard: (c: string) => (
    <svg width="17" height="17" viewBox="0 0 17 17" fill="none">
      <rect x="1.5" y="1.5" width="6" height="6" rx="1" stroke={c} strokeWidth="1.3" />
      <rect x="9.5" y="1.5" width="6" height="9" rx="1" stroke={c} strokeWidth="1.3" />
      <rect x="1.5" y="9.5" width="6" height="6" rx="1" stroke={c} strokeWidth="1.3" />
    </svg>
  ),
  calendar: (c: string) => (
    <svg width="17" height="17" viewBox="0 0 17 17" fill="none">
      <rect x="1.5" y="3" width="14" height="12" rx="1.5" stroke={c} strokeWidth="1.3" />
      <path d="M1.5 6.5H15.5" stroke={c} strokeWidth="1.3" />
      <path d="M5 1.5V4.5M12 1.5V4.5" stroke={c} strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  ),
  plan: (c: string) => (
    <svg width="17" height="17" viewBox="0 0 17 17" fill="none">
      <path d="M3 2.5H14V14.5L11 12.5L8.5 14.5L6 12.5L3 14.5V2.5Z" stroke={c} strokeWidth="1.3" strokeLinejoin="round" />
      <path d="M5.5 5.5H11.5M5.5 8H11.5" stroke={c} strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  ),
  universe: (c: string) => (
    <svg width="17" height="17" viewBox="0 0 17 17" fill="none">
      <circle cx="8.5" cy="8.5" r="6.5" stroke={c} strokeWidth="1.3" />
      <ellipse cx="8.5" cy="8.5" rx="6.5" ry="2.6" stroke={c} strokeWidth="1.3" />
      <path d="M2 8.5H15" stroke={c} strokeWidth="1.3" />
    </svg>
  ),
  issues: (c: string) => (
    <svg width="17" height="17" viewBox="0 0 17 17" fill="none">
      <path d="M8.5 2L15 14H2L8.5 2Z" stroke={c} strokeWidth="1.3" strokeLinejoin="round" />
      <path d="M8.5 6.5V9.5" stroke={c} strokeWidth="1.3" strokeLinecap="round" />
      <circle cx="8.5" cy="11.7" r="0.7" fill={c} />
    </svg>
  ),
  logic: (c: string) => (
    <svg width="17" height="17" viewBox="0 0 17 17" fill="none">
      <rect x="2" y="2" width="4.5" height="4.5" rx="1" stroke={c} strokeWidth="1.3" />
      <rect x="10.5" y="2" width="4.5" height="4.5" rx="1" stroke={c} strokeWidth="1.3" />
      <rect x="6.25" y="10.5" width="4.5" height="4.5" rx="1" stroke={c} strokeWidth="1.3" />
      <path d="M4.25 6.5V8.5H12.75V6.5M8.5 8.5V10.5" stroke={c} strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  ),
  reports: (c: string) => (
    <svg width="17" height="17" viewBox="0 0 17 17" fill="none">
      <path d="M4 1.5H10.5L13.5 4.5V15.5H4V1.5Z" stroke={c} strokeWidth="1.3" strokeLinejoin="round" />
      <path d="M6 8H11.5M6 10.5H11.5M6 13H9.5" stroke={c} strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  ),
  tasks: (c: string) => (
    <svg width="17" height="17" viewBox="0 0 17 17" fill="none">
      <path d="M6 3.5H14M6 8.5H14M6 13.5H14" stroke={c} strokeWidth="1.3" strokeLinecap="round" />
      <path d="M2.5 3.5L3.5 4.5L5 2.5" stroke={c} strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="3.5" cy="8.5" r="1" fill={c} />
      <circle cx="3.5" cy="13.5" r="1" fill={c} />
    </svg>
  ),
  search: (c: string) => (
    <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
      <circle cx="6.5" cy="6.5" r="4.5" stroke={c} strokeWidth="1.4" />
      <path d="M10 10L13.5 13.5" stroke={c} strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  ),
  sun: (c: string) => (
    <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
      <circle cx="7.5" cy="7.5" r="3" stroke={c} strokeWidth="1.3" />
      <path d="M7.5 1V2.3M7.5 12.7V14M14 7.5H12.7M2.3 7.5H1M12.1 2.9L11.2 3.8M3.8 11.2L2.9 12.1M12.1 12.1L11.2 11.2M3.8 3.8L2.9 2.9" stroke={c} strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  ),
  moon: (c: string) => (
    <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
      <path d="M13 9.3A5.8 5.8 0 1 1 5.7 2 4.6 4.6 0 0 0 13 9.3Z" stroke={c} strokeWidth="1.3" strokeLinejoin="round" />
    </svg>
  ),
  chevronRight: (c: string) => (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
      <path d="M4.5 2.5L8 6L4.5 9.5" stroke={c} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  chevronDown: (c: string) => (
    <svg width="11" height="11" viewBox="0 0 11 11" fill="none">
      <path d="M2.5 4.2L5.5 7.2L8.5 4.2" stroke={c} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  usersSmall: (c: string) => (
    <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
      <circle cx="5.5" cy="5" r="2" stroke={c} strokeWidth="1.3" />
      <path d="M1.8 13C1.8 10.5 3.4 9.2 5.5 9.2C7.6 9.2 9.2 10.5 9.2 13" stroke={c} strokeWidth="1.3" strokeLinecap="round" />
      <circle cx="10.8" cy="4.5" r="1.6" stroke={c} strokeWidth="1.2" />
      <path d="M9.8 8.4C11.6 8.4 13 9.5 13 11.5" stroke={c} strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  ),
  settingsSmall: (c: string) => (
    <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
      <circle cx="7.5" cy="7.5" r="2" stroke={c} strokeWidth="1.3" />
      <path d="M7.5 1.8V3.4M7.5 11.6V13.2M13.2 7.5H11.6M3.4 7.5H1.8M11.6 3.4L10.5 4.5M4.5 10.5L3.4 11.6M11.6 11.6L10.5 10.5M4.5 4.5L3.4 3.4" stroke={c} strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  ),
  hyperloop: (c: string) => (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <circle cx="8" cy="8" r="6.5" stroke={c} strokeWidth="1.2" strokeDasharray="3 2" />
      <path d="M3 8H13M10 5L13 8L10 11" stroke={c} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  keyboard: (c: string) => (
    <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
      <rect x="1.5" y="3.5" width="12" height="8" rx="1.5" stroke={c} strokeWidth="1.2" />
      <path d="M4 6H4.01M6.5 6H6.51M9 6H9.01M11 6H11.01M5 8.5H10" stroke={c} strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  ),
  plus: (c: string) => (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
      <path d="M7 2V12M2 7H12" stroke={c} strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  ),
  trash: (c: string) => (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
      <path d="M2.5 4H11.5M5 4V2.5H9V4M5.5 6.5V10.5M8.5 6.5V10.5M3.5 4L4.2 12H9.8L10.5 4" stroke={c} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  filter: (c: string) => (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
      <path d="M2 3H12L8 8V12L6 10V8L2 3Z" stroke={c} strokeWidth="1.2" strokeLinejoin="round" />
    </svg>
  ),
  play: (c: string) => (
    <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
      <polygon points="3.5,2 11,6.5 3.5,11" fill={c} />
    </svg>
  ),
  check: (c: string) => (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
      <path d="M3 7.5L5.8 10.3L11 4.5" stroke={c} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  alertSmall: (c: string) => (
    <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
      <path d="M7.5 1.5L14 13H1L7.5 1.5Z" stroke={c} strokeWidth="1.3" strokeLinejoin="round" />
      <path d="M7.5 5.5V8.5" stroke={c} strokeWidth="1.3" strokeLinecap="round" />
      <circle cx="7.5" cy="10.8" r="0.6" fill={c} />
    </svg>
  ),
  signOutSmall: (c: string) => (
    <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
      <path d="M6 2H3C2.4 2 2 2.4 2 3V12C2 12.6 2.4 13 3 13H6M10 10.5L13 7.5L10 4.5M5.5 7.5H13" stroke={c} strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
};
