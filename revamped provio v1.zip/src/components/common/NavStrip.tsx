import React from 'react';
import { useTheme, FONTS, HOVER_EASE, HOVER_DUR } from '../../context/ThemeContext';
import { useApp, TabId } from '../../context/AppContext';
import { Icon } from './Icons';

export function NavStrip() {
  const { t } = useTheme();
  const { activeTab, setActiveTab, navigateBack, navigateForward, tabHistory, historyIndex } = useApp();

  const tabs: { id: TabId; label: string; icon: (col: string) => React.ReactNode }[] = [
    { id: 'dashboard', label: 'Executive Briefing', icon: Icon.dashboard },
    { id: 'tasks', label: 'Pending Tasks', icon: Icon.tasks },
    { id: 'calendar', label: 'Audit Calendar', icon: Icon.calendar },
    { id: 'universe', label: 'Audit Universe', icon: Icon.universe },
    { id: 'logic', label: 'Visual Logic Studio', icon: Icon.logic },
    { id: 'issues', label: 'Issues & CAP Register', icon: Icon.issues },
    { id: 'plan', label: 'Audit Plan & Mandate', icon: Icon.plan },
  ];

  const canGoBack = historyIndex > 0;
  const canGoForward = historyIndex < tabHistory.length - 1;

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 28px',
        borderBottom: `1px solid ${t.hairline}`,
        background: t.mode === 'dark' ? '#10141E' : '#FFFFFF',
        backdropFilter: 'blur(16px)',
        position: 'sticky',
        top: 57,
        zIndex: 40,
      }}
    >
      {/* Back / Forward History Controls */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, paddingRight: 16 }}>
        <button
          onClick={navigateBack}
          disabled={!canGoBack}
          title="Back (Backspace or Alt+←)"
          style={{
            width: 28,
            height: 28,
            borderRadius: 6,
            border: `1px solid ${t.hairline}`,
            background: canGoBack ? t.card : t.cardSunken,
            color: canGoBack ? t.textPrimary : t.textSecondary,
            opacity: canGoBack ? 1 : 0.4,
            cursor: canGoBack ? 'pointer' : 'default',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <path d="M7.5 9.5L4 6L7.5 2.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>

        <button
          onClick={navigateForward}
          disabled={!canGoForward}
          title="Forward (Alt+→)"
          style={{
            width: 28,
            height: 28,
            borderRadius: 6,
            border: `1px solid ${t.hairline}`,
            background: canGoForward ? t.card : t.cardSunken,
            color: canGoForward ? t.textPrimary : t.textSecondary,
            opacity: canGoForward ? 1 : 0.4,
            cursor: canGoForward ? 'pointer' : 'default',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <path d="M4.5 2.5L8 6L4.5 9.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 24, overflowX: 'auto', flex: 1, scrollbarWidth: 'none' }}>
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                padding: '12px 0 10px',
                border: 'none',
                background: 'none',
                cursor: 'pointer',
                fontFamily: FONTS.sans,
                fontSize: 13,
                fontWeight: isActive ? 600 : 500,
                color: isActive ? t.textPrimary : t.textSecondary,
                position: 'relative',
                whiteSpace: 'nowrap',
                transition: `color ${HOVER_DUR} ${HOVER_EASE}`,
              }}
            >
              {tab.icon(isActive ? t.verdigris : t.textSecondary)}
              <span>{tab.label}</span>
              {isActive && (
                <div
                  style={{
                    position: 'absolute',
                    bottom: -1,
                    left: 0,
                    right: 0,
                    height: 2,
                    background: t.verdigris,
                    borderRadius: '2px 2px 0 0',
                  }}
                />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
