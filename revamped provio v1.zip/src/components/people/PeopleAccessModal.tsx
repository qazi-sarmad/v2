import React, { useState, useMemo } from 'react';
import { useTheme, FONTS, SPRING, HOVER_EASE, HOVER_DUR } from '../../context/ThemeContext';
import { useApp } from '../../context/AppContext';
import { Icon } from '../common/Icons';
import { Lock, ShieldCheck, UserCheck, AlertCircle } from 'lucide-react';

export function PeopleAccessModal() {
  const { t } = useTheme();
  const {
    people,
    roles,
    activeUserId,
    activeUser,
    setActiveUserId,
    updatePersonRole,
    updatePersonPermissions,
    addPerson,
    peopleModalOpen,
    setPeopleModalOpen,
  } = useApp();

  const [addMode, setAddMode] = useState(false);
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newDept, setNewDept] = useState('Retail Banking & Operations');
  const [newRoleId, setNewRoleId] = useState('senior_auditor');

  // RBAC Rule (Requirement 10):
  // "Team roster shall be viewable (of the person and it's subordinates only). Audit lead shouldn't be able to change his role, or the role of their boss!"
  const visiblePeople = useMemo(() => {
    if (activeUser.level === 1) return people; // CAE sees everyone
    return people.filter(
      (p) => p.id === activeUser.id || (p.level !== undefined && p.level > activeUser.level)
    );
  }, [people, activeUser]);

  if (!peopleModalOpen) return null;

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newEmail.trim()) return;
    const role = roles.find((r) => r.id === newRoleId);
    const initials = newName
      .split(' ')
      .map((p) => p[0])
      .join('')
      .substring(0, 2)
      .toUpperCase();

    addPerson({
      name: newName,
      email: newEmail,
      initials,
      roleId: newRoleId,
      roleTitle: role?.title || 'Auditor',
      department: newDept,
      level: role?.level || 4,
      permissions: role
        ? { ...role.defaultPermissions }
        : {
            canSignOff: false,
            canCloseCAP: false,
            canEditMethodology: false,
            canCreateAudits: false,
            canApproveSample: false,
          },
    });
    setAddMode(false);
    setNewName('');
    setNewEmail('');
  };

  const isRoleModificationAllowed = (targetPerson: typeof people[0]) => {
    // CAE can manage all roles
    if (activeUser.level === 1) return true;
    // Audit Lead cannot change their own role!
    if (targetPerson.id === activeUser.id) return false;
    // Audit Lead cannot change the role of their boss or peers!
    if (targetPerson.level !== undefined && targetPerson.level <= activeUser.level) return false;
    // Can change subordinates' roles
    return true;
  };

  return (
    <div
      onClick={() => setPeopleModalOpen(false)}
      style={{
        position: 'fixed',
        inset: 0,
        background: t.overlay,
        backdropFilter: 'blur(3px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 110,
        animation: 'fadeIn 0.15s ease',
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: 840,
          maxHeight: '85vh',
          background: t.card,
          borderRadius: 20,
          border: `1px solid ${t.hairlineStrong}`,
          boxShadow: '0 32px 80px rgba(0,0,0,0.45)',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
          animation: `riseIn 0.28s ${SPRING}`,
        }}
      >
        {/* Modal Header */}
        <div
          style={{
            padding: '20px 28px',
            borderBottom: `1px solid ${t.hairline}`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <div>
            <div style={{ fontSize: 11, color: t.textSecondary, fontWeight: 600, letterSpacing: 0.4 }}>
              GOVERNANCE & ACCESS CONTROL
            </div>
            <div style={{ fontFamily: FONTS.serif, fontSize: 20, fontWeight: 600 }}>
              Team Roster, Defined Roles & Permissions
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <button
              onClick={() => setAddMode((m) => !m)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                padding: '7px 12px',
                borderRadius: 8,
                border: 'none',
                background: addMode ? t.cardSunken : t.verdigris,
                color: addMode ? t.textPrimary : (t.mode === 'dark' ? '#12151C' : '#FFFFFF'),
                fontSize: 12,
                fontWeight: 600,
                cursor: 'pointer',
              }}
            >
              {addMode ? 'Cancel' : '+ Add Person'}
            </button>

            <button
              onClick={() => setPeopleModalOpen(false)}
              style={{
                width: 32,
                height: 32,
                borderRadius: 8,
                border: `1px solid ${t.hairline}`,
                background: 'none',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: t.textSecondary,
                fontSize: 18,
              }}
            >
              ×
            </button>
          </div>
        </div>

        {/* Add Person Drawer */}
        {addMode && (
          <form
            onSubmit={handleCreate}
            style={{
              padding: '16px 28px',
              background: t.cardSunken,
              borderBottom: `1px solid ${t.hairline}`,
              display: 'grid',
              gridTemplateColumns: '1.2fr 1.2fr 1fr 1fr auto',
              gap: 12,
              alignItems: 'end',
            }}
          >
            <div>
              <label style={{ fontSize: 11, fontWeight: 600, color: t.textSecondary, display: 'block', marginBottom: 4 }}>
                Full Name
              </label>
              <input
                required
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="e.g. Liam Sterling"
                style={{
                  width: '100%',
                  padding: '7px 10px',
                  borderRadius: 7,
                  background: t.card,
                  border: `1px solid ${t.hairline}`,
                  color: t.textPrimary,
                  fontSize: 12.5,
                  outline: 'none',
                }}
              />
            </div>
            <div>
              <label style={{ fontSize: 11, fontWeight: 600, color: t.textSecondary, display: 'block', marginBottom: 4 }}>
                Email
              </label>
              <input
                required
                type="email"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                placeholder="liam.s@meridianbank.com"
                style={{
                  width: '100%',
                  padding: '7px 10px',
                  borderRadius: 7,
                  background: t.card,
                  border: `1px solid ${t.hairline}`,
                  color: t.textPrimary,
                  fontSize: 12.5,
                  outline: 'none',
                }}
              />
            </div>
            <div>
              <label style={{ fontSize: 11, fontWeight: 600, color: t.textSecondary, display: 'block', marginBottom: 4 }}>
                Department
              </label>
              <input
                value={newDept}
                onChange={(e) => setNewDept(e.target.value)}
                style={{
                  width: '100%',
                  padding: '7px 10px',
                  borderRadius: 7,
                  background: t.card,
                  border: `1px solid ${t.hairline}`,
                  color: t.textPrimary,
                  fontSize: 12.5,
                  outline: 'none',
                }}
              />
            </div>
            <div>
              <label style={{ fontSize: 11, fontWeight: 600, color: t.textSecondary, display: 'block', marginBottom: 4 }}>
                Defined Role
              </label>
              <select
                value={newRoleId}
                onChange={(e) => setNewRoleId(e.target.value)}
                style={{
                  width: '100%',
                  padding: '7px 10px',
                  borderRadius: 7,
                  background: t.card,
                  border: `1px solid ${t.hairline}`,
                  color: t.textPrimary,
                  fontSize: 12.5,
                  outline: 'none',
                }}
              >
                {roles.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.title}
                  </option>
                ))}
              </select>
            </div>
            <button
              type="submit"
              style={{
                padding: '7px 14px',
                borderRadius: 7,
                border: 'none',
                background: t.verdigris,
                color: t.mode === 'dark' ? '#12151C' : '#FFFFFF',
                fontSize: 12,
                fontWeight: 600,
                cursor: 'pointer',
              }}
            >
              Confirm
            </button>
          </form>
        )}

        {/* Active Context Banner */}
        <div
          style={{
            padding: '10px 28px',
            background: t.cardSunken,
            borderBottom: `1px solid ${t.hairline}`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: 10,
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontSize: 12, color: t.textSecondary }}>Simulate View as Persona:</span>
            <select
              value={activeUserId}
              onChange={(e) => setActiveUserId(e.target.value)}
              style={{
                background: t.card,
                border: `1px solid ${t.hairlineStrong}`,
                borderRadius: 7,
                padding: '4px 10px',
                color: t.textPrimary,
                fontSize: 12,
                fontWeight: 600,
                outline: 'none',
              }}
            >
              {people.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} — {p.roleTitle} {p.level === 1 ? '(CAE)' : p.level === 2 ? '(Lead)' : ''}
                </option>
              ))}
            </select>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 11, color: t.textSecondary }}>
            <ShieldCheck className="w-3.5 h-3.5 text-teal-400" />
            <span>
              Hierarchy Scope: {activeUser.level === 1 ? 'Enterprise Chief Audit Executive View (Full Universe)' : `Direct Subordinates of ${activeUser.name}`}
            </span>
          </div>
        </div>

        {/* People List */}
        <div style={{ overflowY: 'auto', padding: '16px 28px', flex: 1 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {visiblePeople.map((person) => {
              const isCurrent = person.id === activeUserId;
              const canEditRole = isRoleModificationAllowed(person);

              return (
                <div
                  key={person.id}
                  style={{
                    padding: '16px 18px',
                    borderRadius: 14,
                    background: isCurrent
                      ? (t.mode === 'dark' ? 'rgba(111,166,148,0.12)' : 'rgba(78,135,120,0.08)')
                      : t.cardSunken,
                    border: isCurrent
                      ? `1.5px solid ${t.verdigris}`
                      : `1px solid ${t.hairline}`,
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 12,
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 10 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                      <div
                        style={{
                          width: 36,
                          height: 36,
                          borderRadius: '50%',
                          background: t.card,
                          border: `1px solid ${t.hairlineStrong}`,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontSize: 12.5,
                          fontWeight: 700,
                          color: t.verdigris,
                        }}
                      >
                        {person.initials}
                      </div>
                      <div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          <span style={{ fontSize: 14, fontWeight: 600 }}>{person.name}</span>
                          {isCurrent && (
                            <span
                              style={{
                                fontSize: 10,
                                fontWeight: 700,
                                color: t.verdigris,
                                padding: '1px 6px',
                                borderRadius: 4,
                                background: `${t.verdigris}18`,
                                border: `1px solid ${t.verdigris}40`,
                              }}
                            >
                              Current Session
                            </span>
                          )}
                          {person.level === 1 && (
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                              CHIEF AUDIT EXECUTIVE
                            </span>
                          )}
                        </div>
                        <div style={{ fontSize: 11.5, color: t.textSecondary }}>
                          {person.email} · {person.department}
                        </div>
                      </div>
                    </div>

                    {/* Role Dropdown with strict RBAC enforcement (Requirement 10!) */}
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <span style={{ fontSize: 11.5, color: t.textSecondary }}>Defined Role:</span>
                      {canEditRole ? (
                        <select
                          value={person.roleId}
                          onChange={(e) => updatePersonRole(person.id, e.target.value)}
                          style={{
                            background: t.card,
                            color: t.textPrimary,
                            border: `1px solid ${t.hairlineStrong}`,
                            borderRadius: 8,
                            padding: '6px 10px',
                            fontSize: 12,
                            fontWeight: 600,
                            outline: 'none',
                            cursor: 'pointer',
                          }}
                        >
                          {roles.map((r) => (
                            <option key={r.id} value={r.id}>
                              {r.title}
                            </option>
                          ))}
                        </select>
                      ) : (
                        <div
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/80 border border-slate-700 text-xs text-slate-300"
                          title="Only CAE can modify this role"
                        >
                          <Lock className="w-3.5 h-3.5 text-amber-400" />
                          <span className="font-semibold">{person.roleTitle}</span>
                          <span className="text-[10px] text-slate-400">(Locked)</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Permissions Checklist Toggles */}
                  <div
                    style={{
                      display: 'flex',
                      flexWrap: 'wrap',
                      gap: '8px 16px',
                      padding: '10px 12px',
                      borderRadius: 10,
                      background: t.card,
                      border: `1px solid ${t.hairline}`,
                    }}
                  >
                    {[
                      { key: 'canSignOff', label: 'Executive Sign-off' },
                      { key: 'canCloseCAP', label: 'Close CAP Actions' },
                      { key: 'canEditMethodology', label: 'Edit Visual Logic' },
                      { key: 'canCreateAudits', label: 'Schedule Audits' },
                      { key: 'canApproveSample', label: 'Approve Sampling' },
                    ].map(({ key, label }) => {
                      const enabled = (person.permissions as any)[key];
                      const disabled = !canEditRole;
                      return (
                        <label
                          key={key}
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: 6,
                            fontSize: 11.5,
                            color: enabled ? t.textPrimary : t.textSecondary,
                            opacity: disabled ? 0.6 : 1,
                            cursor: disabled ? 'not-allowed' : 'pointer',
                          }}
                        >
                          <input
                            type="checkbox"
                            checked={enabled}
                            disabled={disabled}
                            onChange={(e) => {
                              if (!canEditRole) return;
                              updatePersonPermissions(person.id, {
                                ...person.permissions,
                                [key]: e.target.checked,
                              });
                            }}
                            style={{ accentColor: t.verdigris }}
                          />
                          <span>{label}</span>
                        </label>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
