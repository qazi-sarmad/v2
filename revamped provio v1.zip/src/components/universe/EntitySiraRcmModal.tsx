import React, { useState } from 'react';
import {
  X,
  Target,
  ShieldCheck,
  FolderOpen,
  ArrowRight,
  Plus,
  Sliders,
  CheckCircle2,
  AlertTriangle,
  Building,
} from 'lucide-react';
import { useTheme, FONTS } from '../../context/ThemeContext';
import { useApp } from '../../context/AppContext';
import { AuditControlItem, AuditEntity, SiraAssessment } from '../../types';

interface EntitySiraRcmModalProps {
  entity: AuditEntity;
  onClose: () => void;
  onSaveEntity: (updated: AuditEntity) => void;
  onScopeIntoAudit: (entity: AuditEntity) => void;
}

export const EntitySiraRcmModal: React.FC<EntitySiraRcmModalProps> = ({
  entity,
  onClose,
  onSaveEntity,
  onScopeIntoAudit,
}) => {
  const { t } = useTheme();
  const { showToast } = useApp();

  const [activeTab, setActiveTab] = useState<'sira' | 'rcm'>('sira');

  // SIRA 5 Risk Drivers
  const [financial, setFinancial] = useState(entity.siraScore?.financial || 4);
  const [regulatory, setRegulatory] = useState(entity.siraScore?.regulatory || 5);
  const [operational, setOperational] = useState(entity.siraScore?.operational || 4);
  const [reputational, setReputational] = useState(entity.siraScore?.reputational || 4);
  const [historical, setHistorical] = useState(entity.siraScore?.historical || 3);
  const [rationale, setRationale] = useState(
    entity.siraScore?.rationale ||
      'High balance sheet volume subject to rigorous continuous regulatory examination and consumer compliance standards.'
  );

  // Computed Composite Score (Weighted formula: Fin 25%, Reg 30%, Ops 20%, Rep 15%, Hist 10%)
  const computedComposite = Math.round(
    ((financial * 0.25 + regulatory * 0.3 + operational * 0.2 + reputational * 0.15 + historical * 0.1) / 5) * 100
  );

  const riskTier = computedComposite >= 75 ? 'HIGH RISK' : computedComposite >= 50 ? 'MEDIUM RISK' : 'LOW RISK';

  // RCM Controls
  const [rcmControls, setRcmControls] = useState<AuditControlItem[]>(() => {
    if (entity.rcmControls && entity.rcmControls.length > 0) {
      return entity.rcmControls;
    }
    // Default RCM controls seeded for entity
    return [
      {
        id: `rcm_ctrl_1_${entity.id}`,
        code: `${entity.name.slice(0, 2).toUpperCase()}-01`,
        name: 'Mandatory Supervisory Sign-off & Threshold Limit Verification',
        objective: 'Prevent unauthorized transactions exceeding delegated authority levels.',
        type: 'Preventive',
        frequency: 'Automated Real-time',
        owner: entity.leadOwner,
        deaStatus: 'Effective',
        oetStatus: 'Effective',
        sampleSize: 60,
        sampleExceptions: 0,
      },
      {
        id: `rcm_ctrl_2_${entity.id}`,
        code: `${entity.name.slice(0, 2).toUpperCase()}-02`,
        name: 'Independent End-of-Day Ledger Reconciliation Gate',
        objective: 'Detect and escalate ledger variances within 24 hours of posting.',
        type: 'Detective',
        frequency: 'Daily',
        owner: entity.leadOwner,
        deaStatus: 'Effective',
        oetStatus: 'Effective',
        sampleSize: 25,
        sampleExceptions: 0,
      },
      {
        id: `rcm_ctrl_3_${entity.id}`,
        code: `${entity.name.slice(0, 2).toUpperCase()}-03`,
        name: 'Biometric / Cryptographic Multi-Factor Authentication Check',
        objective: 'Authenticate customer and operator identity prior to sensitive data modification.',
        type: 'Preventive',
        frequency: 'Automated Real-time',
        owner: entity.leadOwner,
        deaStatus: 'Effective',
        oetStatus: 'Testing In Progress',
        sampleSize: 30,
        sampleExceptions: 1,
      },
    ];
  });

  const [newCtrlCode, setNewCtrlCode] = useState('');
  const [newCtrlName, setNewCtrlName] = useState('');
  const [newCtrlType, setNewCtrlType] = useState<'Preventive' | 'Detective'>('Preventive');
  const [newCtrlFreq, setNewCtrlFreq] = useState('Daily');

  const handleAddRcmControl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCtrlName.trim()) return;

    const newCtrl: AuditControlItem = {
      id: `rcm_ctrl_${Date.now()}`,
      code: newCtrlCode.trim().toUpperCase() || `CTRL-${rcmControls.length + 1}`,
      name: newCtrlName.trim(),
      objective: 'Ensure compliance with operational control baseline.',
      type: newCtrlType,
      frequency: newCtrlFreq as any,
      owner: entity.leadOwner,
      deaStatus: 'Pending Walkthrough',
      oetStatus: 'Not Started',
      sampleSize: 25,
      sampleExceptions: 0,
    };

    setRcmControls((prev) => [...prev, newCtrl]);
    setNewCtrlCode('');
    setNewCtrlName('');
    showToast(`Added control ${newCtrl.code} to ${entity.name} RCM.`);
  };

  const handleSaveSiraAndRcm = () => {
    const updatedSira: SiraAssessment = {
      financial,
      regulatory,
      operational,
      reputational,
      historical,
      composite: computedComposite,
      rationale,
      lastAssessedDate: new Date().toISOString().split('T')[0],
    };

    const updatedEntity: AuditEntity = {
      ...entity,
      inherentRisk: computedComposite >= 75 ? 'high' : computedComposite >= 50 ? 'medium' : 'low',
      frequencyMonths: computedComposite >= 75 ? 12 : computedComposite >= 50 ? 24 : 36,
      siraScore: updatedSira,
      rcmControls,
    };

    onSaveEntity(updatedEntity);
    showToast(`Updated SIRA scorecard & RCM for ${entity.name}`);
    onClose();
  };

  const handleScopeClick = () => {
    handleSaveSiraAndRcm();
    onScopeIntoAudit(entity);
  };

  return (
    <div
      className="fixed inset-0 z-[80] flex items-center justify-center bg-black/75 backdrop-blur-md p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="w-full max-w-4xl bg-[#111722] text-slate-100 rounded-2xl border border-slate-700/80 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 bg-gradient-to-r from-[#17202F] via-[#131924] to-[#111722] flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-teal-500/15 text-teal-300 border border-teal-500/30">
                Auditable Entity Profile
              </span>
              <span className="text-xs text-slate-400">· {entity.businessUnit}</span>
            </div>
            <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
              <Building className="w-5 h-5 text-teal-400" />
              {entity.name}
            </h2>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleScopeClick}
              className="px-4 py-2 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-all shadow-md shadow-teal-500/20 cursor-pointer"
            >
              <FolderOpen className="w-3.5 h-3.5" />
              <span>Scope Entity & RCM into Audit File</span>
            </button>
            <button onClick={onClose} className="text-slate-400 hover:text-white cursor-pointer p-1">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Strip */}
        <div className="px-6 border-b border-slate-800 bg-[#121824] flex items-center gap-2">
          <button
            onClick={() => setActiveTab('sira')}
            className={`px-4 py-3 text-xs font-medium border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'sira'
                ? 'border-teal-400 text-teal-300 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Target className="w-3.5 h-3.5" />
            SIRA Inherent Risk Drivers
            <span className="px-2 py-0.2 rounded-full text-[10px] bg-slate-800 text-amber-300 font-bold">
              {computedComposite}/100
            </span>
          </button>

          <button
            onClick={() => setActiveTab('rcm')}
            className={`px-4 py-3 text-xs font-medium border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
              activeTab === 'rcm'
                ? 'border-teal-400 text-teal-300 font-semibold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            Risk & Control Matrix (RCM)
            <span className="px-2 py-0.2 rounded-full text-[10px] bg-slate-800 text-slate-300 font-bold">
              {rcmControls.length} Controls
            </span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-6 overflow-y-auto custom-scrollbar flex-1 space-y-6">
          {activeTab === 'sira' && (
            <div className="space-y-5">
              {/* Composite Scorecard Banner */}
              <div className="p-5 rounded-xl bg-gradient-to-r from-[#17202F] to-[#121824] border border-teal-500/30 flex items-center justify-between">
                <div>
                  <div className="text-xs text-slate-400 uppercase font-semibold">Strategic Inherent Risk Score</div>
                  <div className="text-3xl font-extrabold text-white mt-1">
                    {computedComposite} <span className="text-sm font-normal text-slate-400">/ 100</span>
                  </div>
                  <div className="text-xs text-teal-300 font-semibold mt-1">
                    Classification: {riskTier} · Mandated Frequency: {computedComposite >= 75 ? '12 Months (Annual)' : computedComposite >= 50 ? '24 Months' : '36 Months'}
                  </div>
                </div>

                <div className="text-right text-xs text-slate-400 max-w-xs leading-relaxed">
                  Regulatory Tier: <strong className="text-slate-200">{entity.regulatoryTier}</strong>
                  <div className="mt-1">Lead Executive Owner: <strong className="text-slate-200">{entity.leadOwner}</strong></div>
                </div>
              </div>

              {/* 5 Explicit Risk Drivers */}
              <div className="p-4 rounded-xl bg-[#141B26] border border-slate-800 space-y-4">
                <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                  Entity SIRA Risk Drivers Assessment (1 - 5 Scale)
                </h3>

                <div className="space-y-4 text-xs">
                  {/* Driver 1 */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-slate-300">
                      <span>1. Financial Materiality & Balance Sheet Exposure (Weight: 25%)</span>
                      <strong className="text-amber-400">{financial} / 5</strong>
                    </div>
                    <input
                      type="range"
                      min={1}
                      max={5}
                      value={financial}
                      onChange={(e) => setFinancial(parseInt(e.target.value))}
                      className="w-full accent-teal-400"
                    />
                  </div>

                  {/* Driver 2 */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-slate-300">
                      <span>2. Regulatory Compliance & Supervisory Examination Scrutiny (Weight: 30%)</span>
                      <strong className="text-rose-400">{regulatory} / 5</strong>
                    </div>
                    <input
                      type="range"
                      min={1}
                      max={5}
                      value={regulatory}
                      onChange={(e) => setRegulatory(parseInt(e.target.value))}
                      className="w-full accent-teal-400"
                    />
                  </div>

                  {/* Driver 3 */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-slate-300">
                      <span>3. Operational Complexity, Automation & IT Vulnerability (Weight: 20%)</span>
                      <strong className="text-teal-400">{operational} / 5</strong>
                    </div>
                    <input
                      type="range"
                      min={1}
                      max={5}
                      value={operational}
                      onChange={(e) => setOperational(parseInt(e.target.value))}
                      className="w-full accent-teal-400"
                    />
                  </div>

                  {/* Driver 4 */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-slate-300">
                      <span>4. Reputational & Consumer Brand Impact (Weight: 15%)</span>
                      <strong className="text-indigo-400">{reputational} / 5</strong>
                    </div>
                    <input
                      type="range"
                      min={1}
                      max={5}
                      value={reputational}
                      onChange={(e) => setReputational(parseInt(e.target.value))}
                      className="w-full accent-teal-400"
                    />
                  </div>

                  {/* Driver 5 */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-slate-300">
                      <span>5. Historical Audit Deficiencies & Prior CAP Issues (Weight: 10%)</span>
                      <strong className="text-amber-400">{historical} / 5</strong>
                    </div>
                    <input
                      type="range"
                      min={1}
                      max={5}
                      value={historical}
                      onChange={(e) => setHistorical(parseInt(e.target.value))}
                      className="w-full accent-teal-400"
                    />
                  </div>
                </div>

                <div className="pt-2">
                  <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                    SIRA Inherent Risk Methodology Rationale
                  </label>
                  <textarea
                    rows={2}
                    value={rationale}
                    onChange={(e) => setRationale(e.target.value)}
                    className="w-full px-3 py-2 bg-[#0E131C] border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-teal-400"
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'rcm' && (
            <div className="space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                    Risk & Control Matrix (RCM) Baseline
                  </h3>
                  <p className="text-xs text-slate-400">
                    Controls mapped to this auditable entity. Scoping this entity into an audit will auto-populate its Controls Matrix with these items.
                  </p>
                </div>
              </div>

              {/* RCM Controls List */}
              <div className="space-y-2">
                {rcmControls.map((ctrl) => (
                  <div
                    key={ctrl.id}
                    className="p-3.5 rounded-xl bg-[#141B26] border border-slate-800 flex items-start justify-between gap-3 text-xs"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded font-mono font-bold bg-slate-800 text-teal-300 border border-slate-700 text-[11px]">
                          {ctrl.code}
                        </span>
                        <strong className="text-white text-xs">{ctrl.name}</strong>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-400">
                          {ctrl.type} · {ctrl.frequency}
                        </span>
                      </div>
                      <p className="text-slate-400 text-xs pl-1">{ctrl.objective}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Add Control to RCM */}
              <form onSubmit={handleAddRcmControl} className="p-4 rounded-xl bg-[#0F141E] border border-slate-800 space-y-3 text-xs">
                <span className="font-bold text-white block">Add Key Control to Entity RCM</span>
                <div className="grid grid-cols-4 gap-2">
                  <input
                    type="text"
                    placeholder="Code (e.g. RL-05)"
                    value={newCtrlCode}
                    onChange={(e) => setNewCtrlCode(e.target.value)}
                    className="px-2.5 py-1.5 bg-[#090C12] border border-slate-700 rounded text-white text-xs font-mono"
                  />
                  <input
                    type="text"
                    placeholder="Control Title"
                    value={newCtrlName}
                    onChange={(e) => setNewCtrlName(e.target.value)}
                    className="col-span-2 px-2.5 py-1.5 bg-[#090C12] border border-slate-700 rounded text-white text-xs"
                  />
                  <button
                    type="submit"
                    className="px-3 py-1.5 rounded bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs cursor-pointer"
                  >
                    + Add to RCM
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-slate-800 bg-[#0E131C] flex items-center justify-between text-xs">
          <div className="text-slate-400">
            Entity: <strong>{entity.name}</strong> · Universe: <strong>{entity.universeId || 'Meridian Retail'}</strong>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleSaveSiraAndRcm}
              className="px-5 py-2 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold transition-all shadow-md shadow-teal-500/20 cursor-pointer"
            >
              Save SIRA Drivers & RCM
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
