import React, { useState, useMemo } from 'react';
import { useTheme, FONTS, SPRING, HOVER_EASE, HOVER_DUR } from '../../context/ThemeContext';
import { useApp } from '../../context/AppContext';
import { Icon } from '../common/Icons';
import { AuditEntity, InherentRisk } from '../../types';
import {
  Globe2,
  FolderOpen,
  Plus,
  Target,
  ShieldAlert,
  Calendar,
  Layers,
  Sparkles,
  Search,
  CheckCircle2,
  AlertCircle,
  Clock,
  ArrowUpRight,
  ExternalLink,
  ChevronRight,
  Sliders,
  BarChart3,
  X,
} from 'lucide-react';
import { EntitySiraRcmModal } from './EntitySiraRcmModal';

export function AuditUniverseTab() {
  const { t } = useTheme();
  const {
    universes,
    activeUniverseId,
    setActiveUniverseId,
    addUniverse,
    entities,
    addEntity,
    removeEntity,
    updateEntity,
    regenerateUniverseTimeline,
    openAuditFileForEntity,
    people,
    showToast,
  } = useApp();

  const [riskFilter, setRiskFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [addUniverseModalOpen, setAddUniverseModalOpen] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Entity-Level SIRA & RCM Modal vs Overall SIRA Modal
  const [siraRcmModalEntity, setSiraRcmModalEntity] = useState<AuditEntity | null>(null);
  const [overallSiraModalOpen, setOverallSiraModalOpen] = useState(false);

  // New entity form state
  const [name, setName] = useState('');
  const [businessUnit, setBusinessUnit] = useState('Consumer Banking Division');
  const [targetUniverseId, setTargetUniverseId] = useState(activeUniverseId);
  const [inherentRisk, setInherentRisk] = useState<InherentRisk>('high');
  const [regulatoryTier, setRegulatoryTier] = useState('Tier 1 - CFPB & OCC Scrutiny');
  const [frequencyMonths, setFrequencyMonths] = useState<12 | 18 | 24 | 36>(12);
  const [leadOwner, setLeadOwner] = useState(people[0]?.name || 'Riya Anand');
  const [scopeNotes, setScopeNotes] = useState('');
  
  // SIRA form weights
  const [siraFinancial, setSiraFinancial] = useState(4);
  const [siraRegulatory, setSiraRegulatory] = useState(5);
  const [siraOperational, setSiraOperational] = useState(4);
  const [siraReputational, setSiraReputational] = useState(4);

  // New universe form state
  const [newUnivName, setNewUnivName] = useState('');
  const [newUnivDesc, setNewUnivDesc] = useState('');
  const [newUnivSponsor, setNewUnivSponsor] = useState('');

  const activeUniverse = universes.find((u) => u.id === activeUniverseId) || universes[0];

  const universeEntities = useMemo(() => {
    return entities.filter((e) => !e.universeId || e.universeId === activeUniverseId);
  }, [entities, activeUniverseId]);

  const filteredEntities = useMemo(() => {
    return universeEntities.filter((e) => {
      if (riskFilter !== 'all' && e.inherentRisk !== riskFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          e.name.toLowerCase().includes(q) ||
          e.businessUnit.toLowerCase().includes(q) ||
          e.leadOwner.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [universeEntities, riskFilter, searchQuery]);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const compositeScore = Math.round(
      ((siraFinancial * 0.3 + siraRegulatory * 0.35 + siraOperational * 0.2 + siraReputational * 0.15) / 5) * 100
    );

    addEntity({
      universeId: targetUniverseId || activeUniverseId,
      name,
      businessUnit,
      inherentRisk,
      regulatoryTier,
      frequencyMonths,
      lastAuditedDate: '2025-06-15',
      nextAuditTarget: '2026-11-01',
      leadOwner,
      status: 'scheduled',
      scopeNotes: scopeNotes || 'Auditable entity scope defined in compliance with Meridian IA mandate.',
      siraScore: {
        financial: siraFinancial,
        regulatory: siraRegulatory,
        operational: siraOperational,
        reputational: siraReputational,
        composite: compositeScore,
        rationale: 'Calibrated SIRA weights based on quantitative exposure model.',
      },
    });

    setAddModalOpen(false);
    setName('');
    setScopeNotes('');
  };

  const handleAddUniverseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUnivName.trim()) return;
    addUniverse({
      name: newUnivName.trim(),
      description: newUnivDesc.trim() || 'Enterprise auditable universe division.',
      entitiesCount: 0,
      highRiskCount: 0,
      leadSponsor: newUnivSponsor.trim() || 'Executive Committee',
      coveragePct: 100,
    });
    setAddUniverseModalOpen(false);
    setNewUnivName('');
    setNewUnivDesc('');
    setNewUnivSponsor('');
  };

  const getRiskColor = (risk: InherentRisk) => {
    switch (risk) {
      case 'critical':
        return t.cinnabar;
      case 'high':
        return t.mode === 'dark' ? '#E59866' : '#C6521E';
      case 'medium':
        return t.mode === 'dark' ? '#F5B041' : '#B08A2E';
      default:
        return t.verdigris;
    }
  };

  return (
    <div style={{ padding: '32px 48px', maxWidth: 1380, margin: '0 auto' }}>
      {/* Title & Actions */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 24, flexWrap: 'wrap', gap: 16 }}>
        <div>
          <div style={{ fontFamily: FONTS.serif, fontSize: 26, fontWeight: 600, marginBottom: 4 }}>
            Audit Universe & Entity Architecture
          </div>
          <p style={{ color: t.textSecondary, fontSize: 13.5 }}>
            Multi-universe registry, strategic inherent risk assessment (SIRA), and direct entity-to-audit-file workbench.
          </p>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button
            onClick={() => setAddUniverseModalOpen(true)}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              padding: '8px 14px',
              borderRadius: 9,
              border: `1px solid ${t.hairlineStrong}`,
              background: t.card,
              color: t.textPrimary,
              fontSize: 12.5,
              fontWeight: 600,
              cursor: 'pointer',
            }}
          >
            <Globe2 className="w-3.5 h-3.5 text-teal-400" />
            New Universe
          </button>

          <button
            onClick={regenerateUniverseTimeline}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              padding: '8px 14px',
              borderRadius: 9,
              border: `1px solid ${t.verdigris}50`,
              background: `${t.verdigris}14`,
              color: t.verdigris,
              fontSize: 12.5,
              fontWeight: 600,
              cursor: 'pointer',
              transition: `background ${HOVER_DUR} ${HOVER_EASE}`,
            }}
          >
            <Calendar className="w-3.5 h-3.5" />
            Regenerate Multi-Year Timelines
          </button>

          <button
            onClick={() => {
              setTargetUniverseId(activeUniverseId);
              setAddModalOpen(true);
            }}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              padding: '8px 16px',
              borderRadius: 9,
              border: 'none',
              background: t.verdigris,
              color: t.mode === 'dark' ? '#12151C' : '#FFFFFF',
              fontSize: 12.5,
              fontWeight: 600,
              cursor: 'pointer',
              boxShadow: '0 4px 14px rgba(0,0,0,0.18)',
            }}
          >
            <Plus className="w-3.5 h-3.5" />
            Add Entity to Universe
          </button>
        </div>
      </div>

      {/* MULTI-UNIVERSE NAVIGATION TABS (Fulfills Requirement 7!) */}
      <div className="mb-6 rounded-2xl border border-slate-800 bg-[#121722] p-2 flex items-center gap-2 overflow-x-auto shadow-md">
        {universes.map((univ) => {
          const isSelected = univ.id === activeUniverseId;
          const count = entities.filter((e) => !e.universeId || e.universeId === univ.id).length;
          return (
            <button
              key={univ.id}
              onClick={() => setActiveUniverseId(univ.id)}
              className={`px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2.5 transition-all cursor-pointer whitespace-nowrap ${
                isSelected
                  ? 'bg-gradient-to-r from-teal-500/20 to-teal-500/10 text-teal-300 border border-teal-500/40 shadow-inner'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              <Globe2 className={`w-3.5 h-3.5 ${isSelected ? 'text-teal-400' : 'text-slate-500'}`} />
              <span>{univ.name}</span>
              <span
                className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                  isSelected ? 'bg-teal-500/25 text-teal-200' : 'bg-slate-800 text-slate-400'
                }`}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Active Universe Sponsor & Coverage Banner */}
      {activeUniverse && (
        <div className="mb-6 p-4 rounded-xl bg-[#141B26] border border-slate-800 flex items-center justify-between flex-wrap gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-semibold text-white">{activeUniverse.name}</h3>
              <span className="text-xs text-slate-400">· Sponsor: <strong className="text-teal-400">{activeUniverse.leadSponsor}</strong></span>
            </div>
            <p className="text-xs text-slate-400 max-w-3xl">{activeUniverse.description}</p>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <button
              onClick={() => setOverallSiraModalOpen(true)}
              className="px-3.5 py-2 rounded-lg bg-teal-500/15 hover:bg-teal-500/25 text-teal-300 border border-teal-500/35 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Target className="w-3.5 h-3.5 text-teal-400" />
              <span>Overall SIRA Portfolio Assessment</span>
            </button>
            <div className="p-2 px-3 rounded-lg bg-[#0F141E] border border-slate-800 text-center">
              <span className="text-[10px] text-slate-400 uppercase font-bold block">Assurance Coverage</span>
              <span className="text-sm font-bold text-emerald-400">{activeUniverse.coveragePct}%</span>
            </div>
            <div className="p-2 px-3 rounded-lg bg-[#0F141E] border border-slate-800 text-center">
              <span className="text-[10px] text-slate-400 uppercase font-bold block">Entities in Universe</span>
              <span className="text-sm font-bold text-white">{universeEntities.length}</span>
            </div>
          </div>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 14,
          padding: '10px 18px',
          borderRadius: 12,
          background: t.card,
          border: `1px solid ${t.hairline}`,
          marginBottom: 20,
          flexWrap: 'wrap',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, flex: 1, minWidth: 200 }}>
          <Search className="w-4 h-4 text-slate-400" />
          <input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={`Search ${activeUniverse?.name || 'universe'} entities, leads, or regulatory scope...`}
            style={{
              width: '100%',
              background: 'none',
              border: 'none',
              outline: 'none',
              color: t.textPrimary,
              fontSize: 13,
              fontFamily: FONTS.sans,
            }}
          />
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: 11.5, color: t.textSecondary }}>Inherent Risk:</span>
          {(['all', 'critical', 'high', 'medium', 'low'] as const).map((r) => (
            <button
              key={r}
              onClick={() => setRiskFilter(r)}
              style={{
                padding: '4px 10px',
                borderRadius: 6,
                border: 'none',
                background: riskFilter === r ? t.cardSunken : 'transparent',
                color: riskFilter === r ? t.textPrimary : t.textSecondary,
                fontSize: 11.5,
                fontWeight: riskFilter === r ? 600 : 400,
                cursor: 'pointer',
                textTransform: 'capitalize',
              }}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      {/* Entities List — Clicking Leads DIRECTLY to Audit File (Fulfills Requirement 9!) */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        {filteredEntities.length === 0 ? (
          <div className="p-12 text-center text-slate-400 text-xs rounded-xl border border-slate-800 bg-[#121620]">
            No entities match current filters in this universe. Click "Add Entity to Universe" to populate.
          </div>
        ) : (
          filteredEntities.map((entity) => {
            const riskColor = getRiskColor(entity.inherentRisk);
            return (
              <div
                key={entity.id}
                className="group p-5 rounded-xl border transition-all cursor-pointer shadow-sm hover:shadow-lg"
                style={{
                  background: t.card,
                  borderColor: t.hairline,
                }}
                onClick={() => openAuditFileForEntity(entity.id)}
              >
                {/* Header Row */}
                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap' }}>
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
                      <span className="text-base font-semibold group-hover:text-teal-300 transition-colors flex items-center gap-1.5">
                        {entity.name}
                        <ArrowUpRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity text-teal-400" />
                      </span>
                      <span
                        style={{
                          fontSize: 10,
                          fontWeight: 700,
                          color: riskColor,
                          padding: '2px 7px',
                          borderRadius: 5,
                          background: `${riskColor}15`,
                          border: `1px solid ${riskColor}35`,
                          textTransform: 'uppercase',
                          letterSpacing: 0.3,
                        }}
                      >
                        {entity.inherentRisk} Risk
                      </span>
                      <span
                        style={{
                          fontSize: 10.5,
                          fontWeight: 600,
                          color: entity.status === 'overdue' ? t.cinnabar : entity.status === 'covered' ? t.verdigris : t.blueAccent,
                        }}
                      >
                        ● {entity.status.toUpperCase()}
                      </span>
                    </div>
                    <div style={{ fontSize: 12, color: t.textSecondary }}>
                      {entity.businessUnit} · Regulatory Scope: <span style={{ color: t.textPrimary }}>{entity.regulatoryTier}</span>
                    </div>
                  </div>

                  {/* SIRA Badge & Open Audit File Action Button */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    {entity.siraScore && (
                      <div className="px-2.5 py-1 rounded-lg bg-[#0F141E] border border-slate-800 text-[11px] text-slate-300 flex items-center gap-1.5">
                        <Target className="w-3.5 h-3.5 text-teal-400" />
                        <span>SIRA Composite:</span>
                        <strong className="text-amber-300">{entity.siraScore.composite}/100</strong>
                      </div>
                    )}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSiraRcmModalEntity(entity);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-[#0F141E] hover:bg-slate-800 text-teal-300 border border-teal-500/35 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <Sliders className="w-3.5 h-3.5 text-teal-400" />
                      Entity SIRA & RCM
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        openAuditFileForEntity(entity.id);
                      }}
                      className="px-3.5 py-1.5 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
                    >
                      <FolderOpen className="w-3.5 h-3.5" />
                      Open Audit File
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setDeleteConfirmId(entity.id);
                      }}
                      title="Remove entity from universe"
                      style={{
                        padding: '5px 8px',
                        borderRadius: 6,
                        border: `1px solid ${t.hairline}`,
                        background: 'none',
                        color: t.cinnabar,
                        fontSize: 11,
                        fontWeight: 600,
                        cursor: 'pointer',
                      }}
                    >
                      Remove
                    </button>
                  </div>
                </div>

                {/* Scope & Cycle Metadata */}
                <div style={{ fontSize: 12.5, color: t.textPrimary, lineHeight: 1.5, background: t.cardSunken, padding: '10px 14px', borderRadius: 8, marginTop: 10 }}>
                  {entity.scopeNotes}
                </div>

                {/* Multi-Year Timeline Bar Visualizer */}
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8, alignItems: 'center', paddingTop: 10 }}>
                  {[
                    { year: '2024 Prior', active: entity.lastAuditedDate.startsWith('2024'), label: 'Concluded' },
                    { year: '2025 Prior', active: entity.lastAuditedDate.startsWith('2025'), label: 'Concluded' },
                    { year: '2026 Live', active: entity.status === 'covered' || entity.status === 'overdue' || entity.status === 'scheduled', label: entity.status.toUpperCase() },
                    { year: '2027 Horizon', active: entity.frequencyMonths > 12, label: 'Target Window' },
                  ].map(({ year, active, label }) => (
                    <div
                      key={year}
                      style={{
                        padding: '6px 10px',
                        borderRadius: 6,
                        background: active ? (label === 'OVERDUE' ? `${t.cinnabar}18` : `${t.verdigris}14`) : t.cardSunken,
                        border: `1px solid ${active ? (label === 'OVERDUE' ? `${t.cinnabar}40` : `${t.verdigris}35`) : t.hairline}`,
                      }}
                    >
                      <div style={{ fontSize: 10, color: t.textSecondary }}>{year}</div>
                      <div style={{ fontSize: 11, fontWeight: 600, color: active ? (label === 'OVERDUE' ? t.cinnabar : t.verdigris) : t.textSecondary }}>
                        {active ? label : 'Off-cycle'}
                      </div>
                    </div>
                  ))}
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 11.5, color: t.textSecondary, paddingTop: 8 }}>
                  <div>Frequency: <span style={{ color: t.textPrimary, fontWeight: 500 }}>Every {entity.frequencyMonths} Months</span> · Target Window: <span style={{ color: t.textPrimary }}>{entity.nextAuditTarget}</span></div>
                  <div>Assigned Audit Lead: <span style={{ color: t.textPrimary, fontWeight: 500 }}>{entity.leadOwner}</span></div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            background: t.overlay,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 100,
          }}
          onClick={() => setDeleteConfirmId(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              width: 400,
              background: t.card,
              borderRadius: 14,
              border: `1px solid ${t.hairlineStrong}`,
              padding: 24,
              boxShadow: '0 20px 50px rgba(0,0,0,0.3)',
            }}
          >
            <div style={{ fontSize: 16, fontWeight: 600, marginBottom: 8, color: t.cinnabar }}>
              Remove Auditable Entity?
            </div>
            <p style={{ fontSize: 13, color: t.textSecondary, marginBottom: 20, lineHeight: 1.5 }}>
              Are you sure you want to remove this entity from the active universe? Historical audit logs and past working papers will remain archived.
            </p>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
              <button
                onClick={() => setDeleteConfirmId(null)}
                style={{
                  padding: '7px 14px',
                  borderRadius: 7,
                  border: `1px solid ${t.hairline}`,
                  background: 'none',
                  color: t.textPrimary,
                  fontSize: 12,
                  cursor: 'pointer',
                }}
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  removeEntity(deleteConfirmId);
                  setDeleteConfirmId(null);
                }}
                style={{
                  padding: '7px 14px',
                  borderRadius: 7,
                  border: 'none',
                  background: t.cinnabar,
                  color: '#FFF',
                  fontSize: 12,
                  fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                Confirm Removal
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Universe Modal */}
      {addUniverseModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in"
          onClick={() => setAddUniverseModalOpen(false)}
        >
          <div
            className="w-full max-w-lg bg-[#121722] text-slate-100 rounded-2xl border border-slate-700 p-6 space-y-4 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-base font-semibold text-white flex items-center gap-2">
              <Globe2 className="w-5 h-5 text-teal-400" />
              Create New Audit Universe
            </h3>
            <form onSubmit={handleAddUniverseSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Universe Name</label>
                <input
                  type="text"
                  required
                  value={newUnivName}
                  onChange={(e) => setNewUnivName(e.target.value)}
                  placeholder="e.g. Wealth Management & Trust Operations"
                  className="w-full px-3 py-2 bg-[#0E131C] border border-slate-700 rounded-lg text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Executive Sponsor / Business Leader</label>
                <input
                  type="text"
                  value={newUnivSponsor}
                  onChange={(e) => setNewUnivSponsor(e.target.value)}
                  placeholder="e.g. Jennifer Vance, EVP Wealth Management"
                  className="w-full px-3 py-2 bg-[#0E131C] border border-slate-700 rounded-lg text-white"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Scope & Charter Description</label>
                <textarea
                  rows={3}
                  value={newUnivDesc}
                  onChange={(e) => setNewUnivDesc(e.target.value)}
                  placeholder="Describe regulatory purview, key banking platforms, and risk profile..."
                  className="w-full px-3 py-2 bg-[#0E131C] border border-slate-700 rounded-lg text-white"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setAddUniverseModalOpen(false)}
                  className="px-3.5 py-1.5 rounded-lg border border-slate-700 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold"
                >
                  Create Universe
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Entity Modal with SIRA Scoping */}
      {addModalOpen && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            background: t.overlay,
            backdropFilter: 'blur(3px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 100,
          }}
          onClick={() => setAddModalOpen(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              width: 580,
              maxHeight: '90vh',
              overflowY: 'auto',
              background: t.card,
              borderRadius: 16,
              border: `1px solid ${t.hairlineStrong}`,
              padding: '24px 28px',
              boxShadow: '0 24px 60px rgba(0,0,0,0.35)',
            }}
          >
            <div style={{ fontSize: 18, fontWeight: 600, marginBottom: 16 }}>
              Add Auditable Entity & SIRA Scoping
            </div>

            <form onSubmit={handleAddSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div>
                <label style={{ fontSize: 11.5, color: t.textSecondary, display: 'block', marginBottom: 4 }}>
                  Target Universe
                </label>
                <select
                  value={targetUniverseId}
                  onChange={(e) => setTargetUniverseId(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    borderRadius: 8,
                    border: `1px solid ${t.hairline}`,
                    background: t.cardSunken,
                    color: t.textPrimary,
                    fontSize: 13,
                  }}
                >
                  {universes.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label style={{ fontSize: 11.5, color: t.textSecondary, display: 'block', marginBottom: 4 }}>
                  Entity Name
                </label>
                <input
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Commercial Trade Finance & Letters of Credit"
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    borderRadius: 8,
                    border: `1px solid ${t.hairline}`,
                    background: t.cardSunken,
                    color: t.textPrimary,
                    fontSize: 13,
                  }}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <div>
                  <label style={{ fontSize: 11.5, color: t.textSecondary, display: 'block', marginBottom: 4 }}>
                    Business Unit / Division
                  </label>
                  <input
                    value={businessUnit}
                    onChange={(e) => setBusinessUnit(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '8px 12px',
                      borderRadius: 8,
                      border: `1px solid ${t.hairline}`,
                      background: t.cardSunken,
                      color: t.textPrimary,
                      fontSize: 13,
                    }}
                  />
                </div>
                <div>
                  <label style={{ fontSize: 11.5, color: t.textSecondary, display: 'block', marginBottom: 4 }}>
                    Inherent Risk Classification
                  </label>
                  <select
                    value={inherentRisk}
                    onChange={(e) => setInherentRisk(e.target.value as InherentRisk)}
                    style={{
                      width: '100%',
                      padding: '8px 12px',
                      borderRadius: 8,
                      border: `1px solid ${t.hairline}`,
                      background: t.cardSunken,
                      color: t.textPrimary,
                      fontSize: 13,
                    }}
                  >
                    <option value="critical">Critical Risk</option>
                    <option value="high">High Risk</option>
                    <option value="medium">Medium Risk</option>
                    <option value="low">Low Risk</option>
                  </select>
                </div>
              </div>

              {/* SIRA Weighting Sliders */}
              <div className="p-3.5 rounded-xl bg-[#0E131C] border border-slate-800 space-y-3">
                <div className="flex items-center justify-between text-xs font-semibold text-teal-300">
                  <span className="flex items-center gap-1.5">
                    <Target className="w-3.5 h-3.5" />
                    SIRA Strategic Inherent Risk Calibration
                  </span>
                  <span className="text-amber-400">
                    Composite: {Math.round(((siraFinancial * 0.3 + siraRegulatory * 0.35 + siraOperational * 0.2 + siraReputational * 0.15) / 5) * 100)} / 100
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-slate-400 mb-1">Financial Impact (1-5): {siraFinancial}</label>
                    <input
                      type="range"
                      min="1"
                      max="5"
                      value={siraFinancial}
                      onChange={(e) => setSiraFinancial(Number(e.target.value))}
                      className="w-full accent-teal-500"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">Regulatory Scrutiny (1-5): {siraRegulatory}</label>
                    <input
                      type="range"
                      min="1"
                      max="5"
                      value={siraRegulatory}
                      onChange={(e) => setSiraRegulatory(Number(e.target.value))}
                      className="w-full accent-rose-500"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">Operational Complexity (1-5): {siraOperational}</label>
                    <input
                      type="range"
                      min="1"
                      max="5"
                      value={siraOperational}
                      onChange={(e) => setSiraOperational(Number(e.target.value))}
                      className="w-full accent-teal-500"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">Reputational Risk (1-5): {siraReputational}</label>
                    <input
                      type="range"
                      min="1"
                      max="5"
                      value={siraReputational}
                      onChange={(e) => setSiraReputational(Number(e.target.value))}
                      className="w-full accent-indigo-500"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label style={{ fontSize: 11.5, color: t.textSecondary, display: 'block', marginBottom: 4 }}>
                  Auditable Scope Notes
                </label>
                <textarea
                  rows={2}
                  value={scopeNotes}
                  onChange={(e) => setScopeNotes(e.target.value)}
                  placeholder="Detail primary operational systems, regulatory mandates, and transaction flows..."
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    borderRadius: 8,
                    border: `1px solid ${t.hairline}`,
                    background: t.cardSunken,
                    color: t.textPrimary,
                    fontSize: 13,
                    fontFamily: FONTS.sans,
                  }}
                />
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 8 }}>
                <button
                  type="button"
                  onClick={() => setAddModalOpen(false)}
                  style={{
                    padding: '8px 16px',
                    borderRadius: 8,
                    border: `1px solid ${t.hairline}`,
                    background: 'none',
                    color: t.textPrimary,
                    fontSize: 12.5,
                    cursor: 'pointer',
                  }}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  style={{
                    padding: '8px 20px',
                    borderRadius: 8,
                    border: 'none',
                    background: t.verdigris,
                    color: t.mode === 'dark' ? '#12151C' : '#FFFFFF',
                    fontSize: 12.5,
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  Save Entity & Enroll in Universe
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ENTITY-SPECIFIC SIRA & RCM MATRIX MODAL (Law 2 & Requirement 5) */}
      {siraRcmModalEntity && (
        <EntitySiraRcmModal
          entity={siraRcmModalEntity}
          onClose={() => setSiraRcmModalEntity(null)}
          onSaveEntity={(updated) => {
            updateEntity(updated.id, updated);
            setSiraRcmModalEntity(null);
            showToast(`Updated SIRA Scorecard & RCM for ${updated.name}`);
          }}
          onScopeIntoAudit={(ent) => {
            setSiraRcmModalEntity(null);
            openAuditFileForEntity(ent.id);
          }}
        />
      )}

      {/* OVERALL PORTFOLIO SIRA ASSESSMENT (Accessed separately from entities) */}
      {overallSiraModalOpen && (
        <div
          className="fixed inset-0 z-[80] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in"
          onClick={() => setOverallSiraModalOpen(false)}
        >
          <div
            className="w-full max-w-4xl bg-[#111722] text-slate-100 rounded-2xl border border-slate-700 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="px-6 py-4 border-b border-slate-800 bg-[#151D2A] flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-teal-400">
                  Global Portfolio Assurance
                </span>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Target className="w-5 h-5 text-teal-400" />
                  Overall Universe Strategic Inherent Risk Assessment (SIRA)
                </h2>
              </div>
              <button
                onClick={() => setOverallSiraModalOpen(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 overflow-y-auto custom-scrollbar space-y-6">
              <div className="p-4 rounded-xl bg-teal-500/10 border border-teal-500/30 text-teal-200 text-xs">
                <strong>Overall SIRA vs Entity SIRA:</strong> Entity SIRA is accessed directly on each auditable entity to calibrate individual risk drivers and map constituent RCM controls. Overall SIRA evaluates the enterprise-wide macro portfolio risk distribution across all auditable entities to allocate internal audit resources.
              </div>

              {/* Macro SIRA Scoreboard */}
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 rounded-xl bg-[#141B26] border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-rose-400 block mb-1">High Risk Entities</span>
                  <div className="text-2xl font-bold text-white">
                    {universeEntities.filter((e) => e.inherentRisk === 'high').length}
                  </div>
                  <span className="text-[11px] text-slate-400">Annual 12-Month Mandatory Cycle</span>
                </div>
                <div className="p-4 rounded-xl bg-[#141B26] border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-amber-400 block mb-1">Medium Risk Entities</span>
                  <div className="text-2xl font-bold text-white">
                    {universeEntities.filter((e) => e.inherentRisk === 'medium').length}
                  </div>
                  <span className="text-[11px] text-slate-400">24-Month Assurance Cycle</span>
                </div>
                <div className="p-4 rounded-xl bg-[#141B26] border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-emerald-400 block mb-1">Low Risk Entities</span>
                  <div className="text-2xl font-bold text-white">
                    {universeEntities.filter((e) => e.inherentRisk === 'low').length}
                  </div>
                  <span className="text-[11px] text-slate-400">36-Month Assurance Horizon</span>
                </div>
              </div>

              {/* SIRA Entities Risk Table */}
              <div className="rounded-xl border border-slate-800 bg-[#141B26] overflow-hidden">
                <div className="px-5 py-3 border-b border-slate-800 bg-[#0F141E] text-xs font-semibold text-slate-200">
                  Universe Entities Strategic Ranking & Driver Aggregation
                </div>
                <div className="divide-y divide-slate-800/80 text-xs">
                  {universeEntities.map((ent) => (
                    <div key={ent.id} className="p-3.5 flex items-center justify-between hover:bg-slate-800/40">
                      <div>
                        <div className="font-semibold text-white">{ent.name}</div>
                        <div className="text-[11px] text-slate-400">{ent.businessUnit} · {ent.regulatoryTier}</div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            ent.inherentRisk === 'high'
                              ? 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                              : ent.inherentRisk === 'medium'
                              ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                              : 'bg-teal-500/15 text-teal-300 border border-teal-500/30'
                          }`}
                        >
                          {ent.inherentRisk} Risk
                        </span>
                        <button
                          onClick={() => {
                            setOverallSiraModalOpen(false);
                            setSiraRcmModalEntity(ent);
                          }}
                          className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-teal-300 text-xs font-medium cursor-pointer"
                        >
                          Configure Entity SIRA →
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="px-6 py-3 border-t border-slate-800 bg-[#0E131C] flex justify-end">
              <button
                onClick={() => setOverallSiraModalOpen(false)}
                className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white cursor-pointer"
              >
                Close Overall SIRA View
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
