import React, { useState, useEffect } from 'react';
import {
  X,
  Database,
  CheckCircle2,
  AlertCircle,
  Copy,
  ExternalLink,
  RefreshCw,
  Server,
  Shield,
  Layers,
  Key,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  getSupabaseStatus,
  testSupabaseConnection,
  saveCustomSupabaseConfig,
  clearCustomSupabaseConfig,
} from '../../lib/supabaseClient';

export const SupabaseModal: React.FC = () => {
  const { supabaseModalOpen, setSupabaseModalOpen, showToast } = useApp();
  const [activeTab, setActiveTab] = useState<'status' | 'schema' | 'config'>('status');
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [copied, setCopied] = useState(false);

  const [inputUrl, setInputUrl] = useState('');
  const [inputKey, setInputKey] = useState('');
  const [saveMessage, setSaveMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const [status, setStatus] = useState(getSupabaseStatus());

  useEffect(() => {
    if (supabaseModalOpen) {
      const cur = getSupabaseStatus();
      setStatus(cur);
      if (cur.isConfigured) {
        handleTestConnection();
      }
    }
  }, [supabaseModalOpen]);

  if (!supabaseModalOpen) return null;

  const handleTestConnection = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const res = await testSupabaseConnection();
      setTestResult(res);
      if (res.success) {
        showToast('Supabase connection verified successfully!');
      }
    } catch (err: any) {
      setTestResult({
        success: false,
        message: err?.message || 'Connection test failed',
      });
    } finally {
      setTesting(false);
    }
  };

  const handleSaveCredentials = (e: React.FormEvent) => {
    e.preventDefault();
    setSaveMessage(null);
    const res = saveCustomSupabaseConfig(inputUrl, inputKey);
    if (!res.success) {
      setSaveMessage({ type: 'error', text: res.message });
      return;
    }
    setSaveMessage({ type: 'success', text: 'Credentials saved! Reloading application to connect...' });
    showToast('Supabase credentials saved');
    setTimeout(() => {
      window.location.reload();
    }, 800);
  };

  const handleClearCredentials = () => {
    clearCustomSupabaseConfig();
    showToast('Custom credentials removed. Reloading...');
    setTimeout(() => {
      window.location.reload();
    }, 600);
  };

  const schemaSQL = `-- Provio Internal Audit & Governance — Supabase PostgreSQL Schema
-- Run in your Supabase SQL Editor:

CREATE TABLE IF NOT EXISTS audit_universes (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  lead_sponsor TEXT,
  coverage_pct NUMERIC DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_entities (
  id TEXT PRIMARY KEY,
  universe_id TEXT REFERENCES audit_universes(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  business_unit TEXT NOT NULL,
  inherent_risk TEXT NOT NULL CHECK (inherent_risk IN ('critical', 'high', 'medium', 'low')),
  regulatory_tier TEXT NOT NULL,
  frequency_months INTEGER DEFAULT 12,
  last_audited_date DATE,
  next_audit_target DATE,
  lead_owner TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'scheduled',
  scope_notes TEXT,
  sira_score JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_engagements (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  dept TEXT NOT NULL,
  entity_id TEXT REFERENCES audit_entities(id),
  universe_id TEXT REFERENCES audit_universes(id),
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  status TEXT NOT NULL,
  stage TEXT NOT NULL,
  lead_auditor_id TEXT NOT NULL,
  lead_auditor_name TEXT NOT NULL,
  steps JSONB DEFAULT '{"fieldwork": "not_started", "review": "not_started", "signoff": "not_started"}'::jsonb,
  scope_summary TEXT,
  sample_size INTEGER DEFAULT 60,
  exceptions_count INTEGER DEFAULT 0,
  rating TEXT,
  controls_total INTEGER DEFAULT 0,
  controls_tested INTEGER DEFAULT 0,
  dea JSONB,
  oet JSONB,
  report_issued BOOLEAN DEFAULT FALSE,
  report_issued_date DATE,
  report_summary TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_controls (
  id TEXT PRIMARY KEY,
  audit_id TEXT REFERENCES audit_engagements(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  name TEXT NOT NULL,
  objective TEXT NOT NULL,
  control_type TEXT,
  frequency TEXT,
  owner TEXT,
  dea_status TEXT DEFAULT 'Pending Walkthrough',
  oet_status TEXT DEFAULT 'Not Started',
  sample_size INTEGER DEFAULT 0,
  sample_exceptions INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_observations (
  id TEXT PRIMARY KEY,
  audit_id TEXT REFERENCES audit_engagements(id),
  title TEXT NOT NULL,
  dept TEXT NOT NULL,
  owner TEXT,
  severity TEXT NOT NULL,
  approval TEXT NOT NULL DEFAULT 'Pending review',
  report TEXT NOT NULL,
  closure_date DATE,
  overdue BOOLEAN DEFAULT FALSE,
  due_date DATE NOT NULL,
  rectification_text TEXT,
  report_issued BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);`;

  const copySchemaToClipboard = () => {
    navigator.clipboard.writeText(schemaSQL);
    setCopied(true);
    showToast('SQL schema copied to clipboard! Paste into Supabase SQL Editor.');
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200"
      onClick={() => setSupabaseModalOpen(false)}
    >
      <div
        className="w-full max-w-2xl bg-[#121722] text-slate-100 rounded-2xl border border-slate-700/80 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-800 bg-gradient-to-r from-[#17202F] to-[#121722] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-semibold text-white">Supabase Cloud Integration</h2>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-semibold border ${
                    status.isConfigured
                      ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                      : 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                  }`}
                >
                  {status.isConfigured ? 'Connected' : 'Credentials Required'}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                PostgreSQL persistence for audit universes, controls testing, and executive registers
              </p>
            </div>
          </div>
          <button
            onClick={() => setSupabaseModalOpen(false)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="px-6 border-b border-slate-800 bg-[#141A26] flex gap-4">
          <button
            onClick={() => setActiveTab('status')}
            className={`py-3 text-xs font-medium border-b-2 transition-colors cursor-pointer ${
              activeTab === 'status'
                ? 'border-emerald-400 text-emerald-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Connection Status
          </button>
          <button
            onClick={() => setActiveTab('config')}
            className={`py-3 text-xs font-medium border-b-2 transition-colors cursor-pointer ${
              activeTab === 'config'
                ? 'border-emerald-400 text-emerald-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Required Secrets & Env
          </button>
          <button
            onClick={() => setActiveTab('schema')}
            className={`py-3 text-xs font-medium border-b-2 transition-colors cursor-pointer ${
              activeTab === 'schema'
                ? 'border-emerald-400 text-emerald-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            PostgreSQL DDL Schema
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto custom-scrollbar flex-1 space-y-5">
          {activeTab === 'status' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-[#171E2B] border border-slate-800 flex items-start justify-between">
                <div>
                  <div className="text-xs font-medium text-slate-400 mb-1">Target Endpoint</div>
                  <div className="text-sm font-semibold text-white font-mono">
                    {status.url}
                  </div>
                  {status.source === 'storage' && (
                    <span className="inline-block mt-1 text-[10px] text-teal-400 bg-teal-500/10 px-2 py-0.5 rounded border border-teal-500/20">
                      Using in-app custom credentials
                    </span>
                  )}
                </div>
                <button
                  onClick={handleTestConnection}
                  disabled={testing}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${testing ? 'animate-spin' : ''}`} />
                  {testing ? 'Testing...' : 'Test Ping'}
                </button>
              </div>

              {status.error && (
                <div className="p-4 rounded-xl border border-amber-500/30 bg-amber-500/10 text-amber-200 flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div className="text-xs">
                    <p className="font-semibold mb-1">Configuration Notice</p>
                    <p className="opacity-90 leading-relaxed mb-2">{status.error}</p>
                    <button
                      onClick={() => setActiveTab('config')}
                      className="px-2.5 py-1 rounded bg-amber-400/20 hover:bg-amber-400/30 text-amber-100 font-medium text-[11px] transition-colors cursor-pointer"
                    >
                      Enter Valid Credentials →
                    </button>
                  </div>
                </div>
              )}

              {testResult && (
                <div
                  className={`p-4 rounded-xl border flex items-start gap-3 ${
                    testResult.success
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-200'
                      : 'bg-amber-500/10 border-amber-500/30 text-amber-200'
                  }`}
                >
                  {testResult.success ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  )}
                  <div className="text-xs">
                    <p className="font-semibold mb-0.5">
                      {testResult.success ? 'Connection Operational' : 'Action Required'}
                    </p>
                    <p className="opacity-90">{testResult.message}</p>
                  </div>
                </div>
              )}

              {/* Table Schema Verification List */}
              <div className="rounded-xl border border-slate-800 bg-[#151C28] p-4 space-y-3">
                <div className="text-xs font-semibold text-slate-300 flex items-center gap-2">
                  <Layers className="w-4 h-4 text-emerald-400" />
                  Provio Governed Enterprise Tables
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {[
                    { name: 'audit_universes', desc: 'Multi-universe registry' },
                    { name: 'audit_entities', desc: 'Auditable entities & SIRA' },
                    { name: 'audit_engagements', desc: 'Audit files & stages' },
                    { name: 'audit_controls', desc: 'DEA & OET matrices' },
                    { name: 'audit_workpapers', desc: 'Working papers & tests' },
                    { name: 'audit_observations', desc: 'CAP action register' },
                    { name: 'audit_review_comments', desc: 'Maker-checker threads' },
                    { name: 'methodology_logic_nodes', desc: 'Visual logic studio' },
                  ].map((tbl) => (
                    <div
                      key={tbl.name}
                      className="p-2 rounded-lg bg-[#0F141E] border border-slate-800/80 flex items-center justify-between"
                    >
                      <span className="font-mono text-[11px] text-teal-300">{tbl.name}</span>
                      <span className="text-[10px] text-slate-400">{tbl.desc}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'config' && (
            <div className="space-y-4 text-xs text-slate-300">
              <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-700/60">
                <h3 className="font-semibold text-white mb-2 flex items-center gap-2">
                  <Key className="w-4 h-4 text-emerald-400" />
                  What We Require From You
                </h3>
                <p className="leading-relaxed mb-3 text-slate-300">
                  To persist your audit data directly into your Supabase PostgreSQL cluster, provide the following keys in your AI Studio project environment:
                </p>
                <div className="space-y-2.5">
                  <div className="p-2.5 rounded-lg bg-[#0E131C] border border-slate-800">
                    <span className="font-mono text-emerald-400 font-semibold">VITE_SUPABASE_URL</span>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Your Supabase Project URL found under <strong>Project Settings → API</strong> (e.g. <code>https://your-ref.supabase.co</code>)
                    </p>
                  </div>
                  <div className="p-2.5 rounded-lg bg-[#0E131C] border border-slate-800">
                    <span className="font-mono text-emerald-400 font-semibold">VITE_SUPABASE_ANON_KEY</span>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Your public <code>anon</code> / <code>client_api_key</code> with Row Level Security (RLS) enabled.
                    </p>
                  </div>
                </div>
              </div>

              {/* Direct In-App Credentials Form */}
              <div className="p-4 rounded-xl bg-[#151C28] border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold text-white flex items-center gap-2">
                    <Database className="w-4 h-4 text-teal-400" />
                    Connect via In-App Credentials
                  </h4>
                  {status.source === 'storage' && (
                    <button
                      type="button"
                      onClick={handleClearCredentials}
                      className="text-[11px] text-rose-400 hover:text-rose-300 underline cursor-pointer"
                    >
                      Clear Saved Credentials
                    </button>
                  )}
                </div>
                <p className="text-[11px] text-slate-400">
                  You can paste your Supabase Project URL and Anon Key directly below. Credentials are saved locally in your browser session.
                </p>

                <form onSubmit={handleSaveCredentials} className="space-y-3 pt-1">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">
                      Supabase Project URL
                    </label>
                    <input
                      type="url"
                      placeholder="https://xyzcompany.supabase.co"
                      value={inputUrl}
                      onChange={(e) => setInputUrl(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-[#0E131C] border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-400"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">
                      Supabase Anon Public API Key
                    </label>
                    <input
                      type="password"
                      placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                      value={inputKey}
                      onChange={(e) => setInputKey(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-[#0E131C] border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-400"
                    />
                  </div>

                  {saveMessage && (
                    <div
                      className={`p-2.5 rounded-lg text-xs ${
                        saveMessage.type === 'success'
                          ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30'
                          : 'bg-rose-500/10 text-rose-300 border border-rose-500/30'
                      }`}
                    >
                      {saveMessage.text}
                    </div>
                  )}

                  <div className="flex justify-end pt-1">
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 font-semibold text-xs transition-colors cursor-pointer"
                    >
                      Save & Connect
                    </button>
                  </div>
                </form>
              </div>

              <div className="p-4 rounded-xl bg-teal-500/10 border border-teal-500/30 text-teal-200">
                <div className="flex items-center gap-2 font-semibold mb-1">
                  <Shield className="w-4 h-4 text-teal-400" />
                  Enterprise Security Model
                </div>
                <p className="text-[11px] leading-relaxed">
                  Provio runs client-side authentication with strict Row Level Security policies. Your database password and service role keys are never exposed in browser bundles.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'schema' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">
                  Execute this SQL in your Supabase project's SQL Editor:
                </span>
                <button
                  onClick={copySchemaToClipboard}
                  className="px-3 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  {copied ? 'Copied!' : 'Copy SQL Schema'}
                </button>
              </div>
              <div className="p-3 bg-[#0B0F17] rounded-xl border border-slate-800 text-[11px] font-mono text-slate-300 max-h-72 overflow-y-auto custom-scrollbar">
                <pre>{schemaSQL}</pre>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-[#10151E] flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <Server className="w-3.5 h-3.5 text-slate-400" />
            PostgreSQL v15+ · Supabase Cloud
          </div>
          <button
            onClick={() => setSupabaseModalOpen(false)}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
