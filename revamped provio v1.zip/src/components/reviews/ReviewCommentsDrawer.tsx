import React, { useState } from 'react';
import {
  X,
  MessageSquare,
  CheckCircle2,
  Clock,
  Send,
  Paperclip,
  Filter,
  FileText,
  AlertCircle,
  PlusCircle,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const ReviewCommentsDrawer: React.FC = () => {
  const {
    reviewDrawerOpen,
    setReviewDrawerOpen,
    reviewComments,
    addReplyToComment,
    addReviewNote,
    resolveReviewComment,
    activeUser,
  } = useApp();

  const [activeTabFilter, setActiveTabFilter] = useState<'all' | 'open' | 'resolved'>('open');
  const [selectedCommentId, setSelectedCommentId] = useState<number | string | null>(null);
  const [replyText, setReplyText] = useState<{ [key: string]: string }>({});

  // New Note Modal state inside drawer
  const [isCreatingNote, setIsCreatingNote] = useState(false);
  const [newDocName, setNewDocName] = useState('WP-103: Operating Effectiveness Testing');
  const [newCommentBody, setNewCommentBody] = useState('');

  if (!reviewDrawerOpen) return null;

  const filteredComments = reviewComments.filter((c) => {
    if (activeTabFilter === 'open') return c.status === 'open';
    if (activeTabFilter === 'resolved') return c.status === 'resolved';
    return true;
  });

  const openCount = reviewComments.filter((c) => c.status === 'open').length;
  const resolvedCount = reviewComments.filter((c) => c.status === 'resolved').length;

  const handleSendReply = (commentId: number | string) => {
    const text = replyText[commentId]?.trim();
    if (!text) return;
    addReplyToComment(commentId, text);
    setReplyText((prev) => ({ ...prev, [commentId]: '' }));
  };

  const handleCreateNewNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentBody.trim()) return;
    addReviewNote(`doc_${Date.now()}`, newDocName, newCommentBody.trim());
    setNewCommentBody('');
    setIsCreatingNote(false);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-black/45 backdrop-blur-sm transition-opacity animate-in fade-in duration-200"
      onClick={() => setReviewDrawerOpen(false)}
    >
      <div
        className="w-full max-w-xl h-full bg-[#12161F] text-slate-100 shadow-2xl flex flex-col border-l border-slate-700/60 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-800/80 bg-gradient-to-b from-[#181F2C] to-[#12161F] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-teal-500/10 border border-teal-500/30 flex items-center justify-center text-teal-400">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-semibold text-white tracking-wide">
                  Executive Review Comments
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold tracking-wider uppercase bg-teal-500/15 text-teal-300 border border-teal-500/30">
                  Live Audit Trail
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Peer review notes, maker-checker sign-offs & working paper challenges
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsCreatingNote(true)}
              className="px-3 py-1.5 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 text-xs font-semibold flex items-center gap-1.5 transition-all shadow-md shadow-teal-500/20 active:scale-95 cursor-pointer"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              New Note
            </button>
            <button
              onClick={() => setReviewDrawerOpen(false)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/60 transition-colors cursor-pointer"
              title="Close drawer (Esc)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="px-6 py-3 border-b border-slate-800/60 bg-[#131923] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTabFilter('open')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-2 transition-all cursor-pointer ${
                activeTabFilter === 'open'
                  ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
              Open Challenges
              <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300">
                {openCount}
              </span>
            </button>
            <button
              onClick={() => setActiveTabFilter('resolved')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-2 transition-all cursor-pointer ${
                activeTabFilter === 'resolved'
                  ? 'bg-teal-500/15 text-teal-300 border border-teal-500/30 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-teal-400" />
              Resolved & Signed Off
              <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-teal-500/20 text-teal-300">
                {resolvedCount}
              </span>
            </button>
            <button
              onClick={() => setActiveTabFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                activeTabFilter === 'all'
                  ? 'bg-slate-800 text-white border border-slate-700'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All ({reviewComments.length})
            </button>
          </div>
          <div className="text-[11px] text-slate-500 flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
            IIA Maker-Checker
          </div>
        </div>

        {/* New Note Inline Drawer Panel */}
        {isCreatingNote && (
          <form
            onSubmit={handleCreateNewNote}
            className="p-5 border-b border-teal-500/30 bg-gradient-to-b from-[#16232D] to-[#121A24] space-y-3 animate-in fade-in slide-in-from-top-3 duration-200"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-semibold text-teal-300">
                <Sparkles className="w-3.5 h-3.5 text-teal-400" />
                Raise Reviewer Challenge / Maker Note
              </div>
              <button
                type="button"
                onClick={() => setIsCreatingNote(false)}
                className="text-slate-400 hover:text-white text-xs cursor-pointer"
              >
                Cancel
              </button>
            </div>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Target Document / Working Paper Ref</label>
              <input
                type="text"
                value={newDocName}
                onChange={(e) => setNewDocName(e.target.value)}
                className="w-full px-3 py-1.5 bg-[#0D121B] border border-slate-700/80 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
                placeholder="e.g. WP-102: DEA Walkthrough Matrix"
              />
            </div>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Challenge Observation / Review Inquiry</label>
              <textarea
                rows={3}
                value={newCommentBody}
                onChange={(e) => setNewCommentBody(e.target.value)}
                className="w-full px-3 py-2 bg-[#0D121B] border border-slate-700/80 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
                placeholder="Specify missing evidence, sample expansion request, or methodology non-conformance..."
                required
              />
            </div>
            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="submit"
                className="px-3.5 py-1.5 rounded-lg bg-teal-500 hover:bg-teal-400 text-slate-950 font-semibold text-xs transition-colors cursor-pointer"
              >
                Publish Review Challenge
              </button>
            </div>
          </form>
        )}

        {/* Content List */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4 custom-scrollbar">
          {filteredComments.length === 0 ? (
            <div className="py-16 text-center">
              <CheckCircle2 className="w-10 h-10 text-slate-600 mx-auto mb-3" />
              <p className="text-sm font-medium text-slate-300">No {activeTabFilter} review comments</p>
              <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                All working papers under this view have completed formal maker-checker review sign-off.
              </p>
            </div>
          ) : (
            filteredComments.map((comment) => {
              const isResolved = comment.status === 'resolved';
              return (
                <div
                  key={comment.id}
                  className={`rounded-xl border p-4.5 transition-all ${
                    isResolved
                      ? 'bg-[#151C26]/70 border-slate-800/80 opacity-80'
                      : 'bg-[#161E2C] border-slate-700/80 hover:border-slate-600 shadow-lg shadow-black/20'
                  }`}
                >
                  {/* Top Bar: Target Document & Status */}
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-2">
                      <span className="p-1 rounded-md bg-slate-800 text-slate-400">
                        <FileText className="w-3.5 h-3.5" />
                      </span>
                      <span className="text-xs font-semibold text-teal-300 tracking-tight">
                        {comment.doc}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      {isResolved ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-teal-500/10 text-teal-300 border border-teal-500/30">
                          <CheckCircle2 className="w-3 h-3" />
                          Resolved
                        </span>
                      ) : (
                        <button
                          onClick={() => resolveReviewComment(comment.id)}
                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-500/15 text-amber-300 border border-amber-500/30 hover:bg-amber-500/25 transition-colors cursor-pointer"
                          title="Click to mark resolved & sign off"
                        >
                          <Clock className="w-3 h-3" />
                          Open Action · Resolve
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Comment Author Header */}
                  <div className="flex items-center gap-2.5 mb-2">
                    <div className="w-7 h-7 rounded-full bg-slate-700 border border-slate-600 flex items-center justify-center text-[11px] font-bold text-slate-200">
                      {comment.initials}
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-white flex items-center gap-1.5">
                        {comment.author}
                        <span className="text-[10px] font-normal text-slate-400">· {comment.role}</span>
                      </div>
                      <span className="text-[10px] text-slate-500">{comment.time}</span>
                    </div>
                  </div>

                  {/* Main Comment Text */}
                  <div className="text-xs text-slate-200 leading-relaxed pl-9 mb-3">
                    {comment.comment}
                  </div>

                  {/* Attachments if any */}
                  {comment.attachments && comment.attachments.length > 0 && (
                    <div className="pl-9 mb-3 space-y-1">
                      {comment.attachments.map((att, i) => (
                        <div
                          key={i}
                          className="inline-flex items-center gap-2 px-2.5 py-1 rounded-md bg-slate-800/90 border border-slate-700/60 text-[11px] text-slate-300 mr-2"
                        >
                          <Paperclip className="w-3 h-3 text-slate-400" />
                          <span>{att.name}</span>
                          <span className="text-[9px] text-slate-500">({att.size})</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Replies Thread */}
                  {comment.replies && comment.replies.length > 0 && (
                    <div className="pl-9 mt-3 pt-3 border-t border-slate-800/80 space-y-3">
                      {comment.replies.map((reply) => (
                        <div key={reply.id} className="bg-[#0F141E] rounded-lg p-3 border border-slate-800">
                          <div className="flex items-center justify-between mb-1.5">
                            <div className="flex items-center gap-2">
                              <span className="w-5 h-5 rounded-full bg-teal-900/60 text-teal-300 text-[10px] font-bold flex items-center justify-center">
                                {reply.initials}
                              </span>
                              <span className="text-xs font-semibold text-slate-200">{reply.author}</span>
                              {reply.self && (
                                <span className="px-1.5 py-0.2 rounded text-[9px] bg-slate-800 text-slate-400">
                                  You
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-slate-500">{reply.time}</span>
                          </div>
                          <p className="text-xs text-slate-300 pl-7 leading-relaxed">{reply.text}</p>
                          {reply.attachments && reply.attachments.length > 0 && (
                            <div className="pl-7 mt-1.5">
                              {reply.attachments.map((a, j) => (
                                <div
                                  key={j}
                                  className="inline-flex items-center gap-1.5 text-[10px] text-teal-400 bg-teal-950/40 border border-teal-800/40 rounded px-2 py-0.5"
                                >
                                  <Paperclip className="w-3 h-3" />
                                  {a.name} ({a.size})
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Reply Input Box */}
                  <div className="pl-9 mt-3">
                    <div className="relative flex items-center">
                      <input
                        type="text"
                        value={replyText[comment.id] || ''}
                        onChange={(e) =>
                          setReplyText((prev) => ({ ...prev, [comment.id]: e.target.value }))
                        }
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleSendReply(comment.id);
                        }}
                        placeholder={`Reply as ${activeUser.name}...`}
                        className="w-full pr-20 pl-3 py-2 bg-[#0E131C] border border-slate-800 focus:border-teal-500/70 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none"
                      />
                      <div className="absolute right-1.5 flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => handleSendReply(comment.id)}
                          className="px-2 py-1 rounded bg-teal-500 hover:bg-teal-400 text-slate-950 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                        >
                          <Send className="w-3 h-3" />
                          Send
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer info */}
        <div className="px-6 py-3.5 border-t border-slate-800/80 bg-[#10151E] flex items-center justify-between text-[11px] text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Active Auditor: <strong className="text-slate-200">{activeUser.name}</strong> ({activeUser.roleTitle})</span>
          </div>
          <button
            onClick={() => setReviewDrawerOpen(false)}
            className="text-xs text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            Close (Esc)
          </button>
        </div>
      </div>
    </div>
  );
};
