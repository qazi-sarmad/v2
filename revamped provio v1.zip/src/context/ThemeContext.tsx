import React, { createContext, useContext, useState, useEffect } from 'react';

export interface ThemeTokens {
  bg: string;
  card: string;
  cardSunken: string;
  textPrimary: string;
  textSecondary: string;
  hairline: string;
  hairlineStrong: string;
  verdigris: string;
  cinnabar: string;
  blueAccent: string;
  overlay: string;
  mode: 'dark' | 'light';
}

export const TOKENS: Record<'dark' | 'light', ThemeTokens> = {
  light: {
    bg: '#F7F6F3',
    card: '#FFFFFF',
    cardSunken: '#F1EFEA',
    textPrimary: '#12151C',
    textSecondary: '#5B6272',
    hairline: 'rgba(18,21,28,0.09)',
    hairlineStrong: 'rgba(18,21,28,0.18)',
    verdigris: '#4E8778',
    cinnabar: '#C6521E',
    blueAccent: '#3B72A4',
    overlay: 'rgba(18,21,28,0.48)',
    mode: 'light',
  },
  dark: {
    bg: '#25211D',
    card: '#2F2A25',
    cardSunken: '#201C18',
    textPrimary: '#F2EFE9',
    textSecondary: '#A39B8F',
    hairline: 'rgba(242,239,233,0.09)',
    hairlineStrong: 'rgba(242,239,233,0.18)',
    verdigris: '#6FA694',
    cinnabar: '#E07B49',
    blueAccent: '#7EAFDB',
    overlay: 'rgba(0,0,0,0.68)',
    mode: 'dark',
  },
};

export const FONTS = {
  serif: "'Source Serif 4', Georgia, serif",
  sans: "'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif",
  mono: "'JetBrains Mono', 'SF Mono', monospace",
};

export const SPRING = 'cubic-bezier(0.34, 1.56, 0.64, 1)';
export const EASE = 'cubic-bezier(0.16, 1, 0.3, 1)';
export const HOVER_EASE = 'cubic-bezier(0.22, 1, 0.36, 1)';
export const HOVER_DUR = '0.3s';

interface ThemeContextType {
  mode: 'dark' | 'light';
  setMode: (mode: 'dark' | 'light') => void;
  toggleMode: () => void;
  t: ThemeTokens;
}

const ThemeContext = createContext<ThemeContextType | null>(null);

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider');
  return ctx;
}

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [mode, setMode] = useState<'dark' | 'light'>('dark');
  const t = TOKENS[mode];

  const toggleMode = () => setMode((m) => (m === 'dark' ? 'light' : 'dark'));

  useEffect(() => {
    document.documentElement.classList.toggle('dark', mode === 'dark');
  }, [mode]);

  return (
    <ThemeContext.Provider value={{ mode, setMode, toggleMode, t }}>
      <div
        style={{
          background: t.bg,
          color: t.textPrimary,
          minHeight: '100vh',
          fontFamily: FONTS.sans,
          transition: 'background-color 0.35s ease, color 0.35s ease',
        }}
      >
        {children}
      </div>
    </ThemeContext.Provider>
  );
}
