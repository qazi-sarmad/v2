import React, { createContext, useContext, useState, useMemo, useCallback } from 'react';
import {
  AuditEngagement,
  AuditEntity,
  AuditStage,
  AuditStatus,
  AuditUniverse,
  DepartmentSummary,
  LogicNode,
  Observation,
  Person,
  ReviewComment,
  Role,
  StepStatus,
} from '../types';
import {
  INITIAL_AUDITS,
  INITIAL_AUDIT_UNIVERSE,
  INITIAL_DEPARTMENTS,
  INITIAL_LOGIC_NODES,
  INITIAL_PEOPLE,
  INITIAL_REVIEW_COMMENTS,
  INITIAL_ROLES,
  INITIAL_UNIVERSES,
} from '../data/initialData';

export type TabId =
  | 'dashboard'
  | 'calendar'
  | 'plan'
  | 'universe'
  | 'tasks'
  | 'issues'
  | 'logic';

interface AppContextType {
  // Navigation
  activeTab: TabId;
  setActiveTab: (tab: TabId) => void;
  navigateBack: () => void;
  navigateForward: () => void;
  tabHistory: TabId[];
  historyIndex: number;

  // People & Access
  people: Person[];
  roles: Role[];
  activeUserId: string;
  activeUser: Person;
  setActiveUserId: (id: string) => void;
  updatePersonRole: (personId: string, roleId: string) => void;
  updatePersonPermissions: (personId: string, permissions: Person['permissions']) => void;
  addPerson: (person: Omit<Person, 'id' | 'activeAuditsCount'>) => void;
  peopleModalOpen: boolean;
  setPeopleModalOpen: (open: boolean) => void;

  // Audit Universes & Entities
  universes: AuditUniverse[];
  activeUniverseId: string;
  setActiveUniverseId: (id: string) => void;
  addUniverse: (u: Omit<AuditUniverse, 'id'>) => void;
  entities: AuditEntity[];
  addEntity: (entity: Omit<AuditEntity, 'id'>) => void;
  removeEntity: (id: string) => void;
  updateEntity: (id: string, updates: Partial<AuditEntity>) => void;
  regenerateUniverseTimeline: () => void;
  scopedEntityForAudit: AuditEntity | null;
  setScopedEntityForAudit: (entity: AuditEntity | null) => void;
  openAuditFileForEntity: (entityId: string) => void;

  // Audits & Test Steps
  audits: AuditEngagement[];
  updateAudit: (id: string | number, updates: Partial<AuditEngagement>) => void;
  toggleAuditStep: (auditId: string | number, stepKey: 'planning' | 'fieldwork' | 'review' | 'signoff') => void;
  addAudit: (audit: Omit<AuditEngagement, 'id'>) => void;
  selectedAuditForModal: AuditEngagement | null;
  setSelectedAuditForModal: (audit: AuditEngagement | null) => void;
  issueAuditReport: (auditId: string | number, details: { opinion: 'Satisfactory' | 'Needs Improvement' | 'Unsatisfactory'; summary: string; distribution?: string[] }) => void;

  // Action Items / Departments / Observations
  departments: DepartmentSummary[];
  selectedObservation: Observation | null;
  setSelectedObservation: (obs: Observation | null) => void;
  updateObservation: (deptId: string, obsId: string, updates: Partial<Observation>) => void;
  markCAPClosure: (obsId: string, details: { rectificationText: string; closureDate: string; attachments?: any[] }) => void;
  addReviewComment: (obsId: string, text: string) => void;

  // Review Comments Drawer
  reviewComments: ReviewComment[];
  reviewDrawerOpen: boolean;
  setReviewDrawerOpen: (open: boolean) => void;
  addReplyToComment: (commentId: number | string, text: string, attachments?: any[]) => void;
  addReviewNote: (docId: string, docName: string, comment: string, attachments?: any[]) => void;
  resolveReviewComment: (commentId: number | string) => void;

  // Visual Logic Studio
  logicNodes: LogicNode[];
  updateNodeParam: (nodeId: string, paramKey: string, newValue: any) => void;
  selectedNodeForEdit: LogicNode | null;
  setSelectedNodeForEdit: (node: LogicNode | null) => void;
  isSimulatingLogic: boolean;
  runLogicSimulation: () => void;
  simulationResults: any | null;

  // Time Warp / Gantt
  timeWarpYear: number;
  isWarping: boolean;
  triggerTimeWarp: (year: number) => void;

  // Modals & Keyboard
  commandPaletteOpen: boolean;
  setCommandPaletteOpen: (open: boolean) => void;
  shortcutsModalOpen: boolean;
  setShortcutsModalOpen: (open: boolean) => void;
  supabaseModalOpen: boolean;
  setSupabaseModalOpen: (open: boolean) => void;
  closeActiveModal: () => boolean;

  // Toast
  toastMessage: string | null;
  showToast: (msg: string) => void;
}

const AppContext = createContext<AppContextType | null>(null);

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [activeTab, setActiveTabState] = useState<TabId>('dashboard');
  const [tabHistory, setTabHistory] = useState<TabId[]>(['dashboard']);
  const [historyIndex, setHistoryIndex] = useState<number>(0);

  const [people, setPeople] = useState<Person[]>(INITIAL_PEOPLE);
  const [roles] = useState<Role[]>(INITIAL_ROLES);
  const [activeUserId, setActiveUserId] = useState<string>('riya_anand');
  const [peopleModalOpen, setPeopleModalOpen] = useState(false);

  // Multi-universe state
  const [universes, setUniverses] = useState<AuditUniverse[]>(INITIAL_UNIVERSES);
  const [activeUniverseId, setActiveUniverseId] = useState<string>('meridian_retail');
  const [entities, setEntities] = useState<AuditEntity[]>(INITIAL_AUDIT_UNIVERSE);
  const [scopedEntityForAudit, setScopedEntityForAudit] = useState<AuditEntity | null>(null);

  const [audits, setAudits] = useState<AuditEngagement[]>(INITIAL_AUDITS);
  const [departments, setDepartments] = useState<DepartmentSummary[]>(INITIAL_DEPARTMENTS);
  const [reviewComments, setReviewComments] = useState<ReviewComment[]>(INITIAL_REVIEW_COMMENTS);
  const [reviewDrawerOpen, setReviewDrawerOpen] = useState(false);
  const [logicNodes, setLogicNodes] = useState<LogicNode[]>(INITIAL_LOGIC_NODES);

  const [selectedAuditForModal, setSelectedAuditForModal] = useState<AuditEngagement | null>(null);
  const [selectedObservation, setSelectedObservation] = useState<Observation | null>(null);
  const [selectedNodeForEdit, setSelectedNodeForEdit] = useState<LogicNode | null>(null);

  const [isSimulatingLogic, setIsSimulatingLogic] = useState(false);
  const [simulationResults, setSimulationResults] = useState<any | null>(null);

  const [timeWarpYear, setTimeWarpYear] = useState<number>(2026);
  const [isWarping, setIsWarping] = useState<boolean>(false);

  const [commandPaletteOpen, setCommandPaletteOpen] = useState(false);
  const [shortcutsModalOpen, setShortcutsModalOpen] = useState(false);
  const [supabaseModalOpen, setSupabaseModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3200);
  }, []);

  const setActiveTab = useCallback((tab: TabId) => {
    setActiveTabState(tab);
    setTabHistory((h) => {
      const next = [...h.slice(0, historyIndex + 1), tab];
      setHistoryIndex(next.length - 1);
      return next;
    });
  }, [historyIndex]);

  const navigateBack = useCallback(() => {
    if (historyIndex > 0) {
      const newIdx = historyIndex - 1;
      setHistoryIndex(newIdx);
      setActiveTabState(tabHistory[newIdx]);
    }
  }, [historyIndex, tabHistory]);

  const navigateForward = useCallback(() => {
    if (historyIndex < tabHistory.length - 1) {
      const newIdx = historyIndex + 1;
      setHistoryIndex(newIdx);
      setActiveTabState(tabHistory[newIdx]);
    }
  }, [historyIndex, tabHistory]);

  const activeUser = useMemo(() => {
    return people.find((p) => p.id === activeUserId) || people[0];
  }, [people, activeUserId]);

  // Strict role security: Audit Lead cannot change their own role or their boss's role!
  const updatePersonRole = useCallback((personId: string, roleId: string) => {
    const targetPerson = people.find((p) => p.id === personId);
    if (!targetPerson) return;

    // RBAC Rule: Only CAE (level 1) can edit leadership roles or own role
    if (activeUser.level > 1) {
      if (personId === activeUser.id) {
        showToast('Access Denied: You cannot modify your own role. CAE authorization required.');
        return;
      }
      if (targetPerson.level <= activeUser.level) {
        showToast(`Access Denied: You cannot modify the role of senior leadership (${targetPerson.name}).`);
        return;
      }
    }

    const role = roles.find((r) => r.id === roleId);
    if (!role) return;
    setPeople((prev) =>
      prev.map((p) =>
        p.id === personId
          ? {
              ...p,
              roleId,
              roleTitle: role.title,
              level: role.level,
              permissions: { ...role.defaultPermissions },
            }
          : p
      )
    );
    showToast(`Updated role for ${targetPerson.name} to ${role.title}`);
  }, [activeUser, people, roles, showToast]);

  const updatePersonPermissions = useCallback((personId: string, perms: Person['permissions']) => {
    if (activeUser.level > 1 && personId === activeUser.id) {
      showToast('Access Denied: You cannot elevate your own permissions.');
      return;
    }
    setPeople((prev) =>
      prev.map((p) => (p.id === personId ? { ...p, permissions: perms } : p))
    );
    showToast('Updated access permissions matrix');
  }, [activeUser, showToast]);

  const addPerson = useCallback((personData: Omit<Person, 'id' | 'activeAuditsCount'>) => {
    const newId = `usr_${Date.now()}`;
    const newPerson: Person = {
      ...personData,
      id: newId,
      activeAuditsCount: 0,
    };
    setPeople((prev) => [newPerson, ...prev]);
    showToast(`Invited ${newPerson.name} to audit team`);
  }, [showToast]);

  // Multi-universe management
  const addUniverse = useCallback((uData: Omit<AuditUniverse, 'id'>) => {
    const newId = `univ_${Date.now()}`;
    const newUniverse: AuditUniverse = { ...uData, id: newId };
    setUniverses((prev) => [newUniverse, ...prev]);
    setActiveUniverseId(newId);
    showToast(`Created audit universe "${newUniverse.name}"`);
  }, [showToast]);

  // Universe Entities
  const addEntity = useCallback((entityData: Omit<AuditEntity, 'id'>) => {
    const newId = `ent_${Date.now()}`;
    const entity: AuditEntity = { ...entityData, id: newId };
    setEntities((prev) => [entity, ...prev]);
    showToast(`Added entity "${entity.name}" to Audit Universe`);
  }, [showToast]);

  const removeEntity = useCallback((id: string) => {
    const target = entities.find((e) => e.id === id);
    setEntities((prev) => prev.filter((e) => e.id !== id));
    showToast(`Removed "${target?.name || 'entity'}" from Audit Universe`);
  }, [entities, showToast]);

  const updateEntity = useCallback((id: string, updates: Partial<AuditEntity>) => {
    setEntities((prev) => prev.map((e) => (e.id === id ? { ...e, ...updates } : e)));
    showToast('Updated entity profile');
  }, [showToast]);

  const regenerateUniverseTimeline = useCallback(() => {
    setEntities((prev) =>
      prev.map((e) => {
        let status = e.status;
        if (e.inherentRisk === 'critical') status = 'covered';
        else if (e.inherentRisk === 'high') status = 'scheduled';
        return { ...e, status };
      })
    );
    showToast(`Regenerated multi-year audit cycle timeline across ${entities.length} entities`);
  }, [entities.length, showToast]);

  // Clicking entity opens its corresponding audit file!
  const openAuditFileForEntity = useCallback((entityId: string) => {
    const targetEntity = entities.find((e) => e.id === entityId);
    if (!targetEntity) return;

    // Find existing engagement or synthesize an active audit file for this entity
    let matchingAudit = audits.find((a) => a.entityId === entityId);
    if (!matchingAudit) {
      const newAudit: AuditEngagement = {
        id: `audit_ent_${entityId}`,
        title: `${targetEntity.name} — Comprehensive Audit File`,
        dept: targetEntity.businessUnit,
        entityId: targetEntity.id,
        universeId: targetEntity.universeId,
        start: targetEntity.nextAuditTarget || '2026-09-01',
        end: '2026-10-30',
        status: 'in_progress',
        stage: 'scoping',
        leadAuditorId: activeUser.id,
        leadAuditorName: activeUser.name,
        steps: { planning: 'in_progress', fieldwork: 'not_started', review: 'not_started', signoff: 'not_started' },
        scopeSummary: targetEntity.scopeNotes || 'Entity risk-based operational and regulatory testing file.',
        sampleSize: 60,
        exceptionsCount: 0,
        controlsTotal: 12,
        controlsTested: 4,
        dea: { status: 'in_progress', effective: 4, ineffective: 0, notes: 'Scoping and preliminary walkthrough in progress.' },
        oet: { status: 'not_started', effective: 0, ineffective: 0 },
        reportIssued: false,
        reportIssuedDate: null,
        siraScore: targetEntity.siraScore,
      };
      setAudits((prev) => [newAudit, ...prev]);
      matchingAudit = newAudit;
    }

    setScopedEntityForAudit(targetEntity);
    setSelectedAuditForModal(matchingAudit);
    showToast(`Opened Audit File for "${targetEntity.name}"`);
  }, [activeUser, audits, entities, showToast]);

  // Audits & Steps
  const updateAudit = useCallback((id: string | number, updates: Partial<AuditEngagement>) => {
    setAudits((prev) => prev.map((a) => (String(a.id) === String(id) ? { ...a, ...updates } : a)));
    setSelectedAuditForModal((prev) => {
      if (!prev || String(prev.id) !== String(id)) return prev;
      return { ...prev, ...updates };
    });
  }, []);

  const toggleAuditStep = useCallback((auditId: string | number, stepKey: 'planning' | 'fieldwork' | 'review' | 'signoff') => {
    setAudits((prev) =>
      prev.map((a) => {
        if (String(a.id) !== String(auditId)) return a;
        const current = a.steps[stepKey] || 'not_started';
        const next: StepStatus =
          current === 'not_started'
            ? 'in_progress'
            : current === 'in_progress'
            ? 'reviewed'
            : 'not_started';
        const updatedSteps = { ...a.steps, [stepKey]: next };

        let stage: AuditStage = a.stage;
        if (updatedSteps.signoff === 'reviewed') stage = 'signoff';
        else if (updatedSteps.review === 'reviewed') stage = 'reporting';
        else if (updatedSteps.fieldwork === 'in_progress') stage = 'fieldwork';

        let status: AuditStatus = a.status;
        if (updatedSteps.signoff === 'reviewed') status = 'concluded_this_year';

        const updated = { ...a, steps: updatedSteps, stage, status };
        setSelectedAuditForModal((curr) => (curr && String(curr.id) === String(auditId) ? updated : curr));
        return updated;
      })
    );
    showToast(`Test step "${stepKey}" updated`);
  }, [showToast]);

  const addAudit = useCallback((auditData: Omit<AuditEngagement, 'id'>) => {
    const newId = String(Date.now());
    const newAudit: AuditEngagement = {
      ...auditData,
      id: newId,
      reportIssued: false,
      controlsTotal: auditData.controlsTotal || 10,
      controlsTested: auditData.controlsTested || 0,
      dea: auditData.dea || { status: 'not_started', effective: 0, ineffective: 0 },
      oet: auditData.oet || { status: 'not_started', effective: 0, ineffective: 0 },
    };
    setAudits((prev) => [newAudit, ...prev]);
    showToast(`Scheduled new engagement "${newAudit.title}"`);
  }, [showToast]);

  // Finalize & Issue Audit Report Lifecycle:
  // Fulfills Requirement 1: Issues only enter the Issues Register after a report is finalized & issued!
  const issueAuditReport = useCallback((auditId: string | number, details: { opinion: 'Satisfactory' | 'Needs Improvement' | 'Unsatisfactory'; summary: string; distribution?: string[] }) => {
    const todayStr = new Date().toISOString().slice(0, 10);
    setAudits((prev) =>
      prev.map((a) => {
        if (String(a.id) !== String(auditId)) return a;
        return {
          ...a,
          status: 'concluded_this_year',
          stage: 'signoff',
          reportIssued: true,
          reportIssuedDate: todayStr,
          executiveOpinion: details.opinion,
          reportSummary: details.summary,
          reportAuthor: `${activeUser.name} & Marcus Vance (CAE)`,
          steps: { ...a.steps, review: 'reviewed', signoff: 'reviewed' },
        };
      })
    );

    // Promote findings originating from this audit to reportIssued: true
    setDepartments((prev) =>
      prev.map((dept) => ({
        ...dept,
        observations: dept.observations.map((obs) => {
          if (String(obs.reportId) === String(auditId)) {
            return {
              ...obs,
              reportIssued: true,
              isDraft: false,
            };
          }
          return obs;
        }),
      }))
    );

    // Update modal state if open
    setSelectedAuditForModal((prev) => {
      if (!prev || String(prev.id) !== String(auditId)) return prev;
      return {
        ...prev,
        status: 'concluded_this_year',
        stage: 'signoff',
        reportIssued: true,
        reportIssuedDate: todayStr,
        executiveOpinion: details.opinion,
        reportSummary: details.summary,
        steps: { ...prev.steps, review: 'reviewed', signoff: 'reviewed' },
      };
    });

    showToast(`Final Audit Report Issued! Observations officially promoted to Board Issues Register.`);
  }, [activeUser.name, showToast]);

  // Observations / CAP Register
  const updateObservation = useCallback((deptId: string, obsId: string, updates: Partial<Observation>) => {
    setDepartments((prev) =>
      prev.map((dept) => {
        if (dept.id !== deptId) return dept;
        return {
          ...dept,
          observations: dept.observations.map((obs) => (obs.id === obsId ? { ...obs, ...updates } : obs)),
        };
      })
    );
    showToast('Updated observation details');
  }, [showToast]);

  const addReviewComment = useCallback((obsId: string, text: string) => {
    const newComment = {
      id: `comm_${Date.now()}`,
      author: activeUser.name,
      timestamp: 'Today · Just now',
      text,
    };
    setDepartments((prev) =>
      prev.map((d) => ({
        ...d,
        observations: d.observations.map((o) => {
          if (o.id !== obsId) return o;
          return {
            ...o,
            comments: [...(o.comments || []), newComment],
          };
        }),
      }))
    );
    setSelectedObservation((prev) => {
      if (!prev || prev.id !== obsId) return prev;
      return {
        ...prev,
        comments: [...(prev.comments || []), newComment],
      };
    });
    showToast('Review comment logged to audit trail');
  }, [activeUser, showToast]);

  const markCAPClosure = useCallback((obsId: string, details: { rectificationText: string; closureDate: string; attachments?: any[] }) => {
    setDepartments((prev) =>
      prev.map((dept) => ({
        ...dept,
        observations: dept.observations.map((obs) => {
          if (obs.id !== obsId) return obs;
          return {
            ...obs,
            closureDate: details.closureDate,
            overdue: false,
            approval: 'Approved',
            rectificationText: details.rectificationText,
            attachments: details.attachments || [],
          };
        }),
      }))
    );
    showToast('CAP successfully closed and verified with supporting evidence');
  }, [showToast]);

  // Review Comments Popout / Drawer
  const addReplyToComment = useCallback((commentId: number | string, text: string, attachments: any[] = []) => {
    setReviewComments((prev) =>
      prev.map((c) => {
        if (String(c.id) !== String(commentId)) return c;
        const newReply = {
          id: Date.now(),
          author: activeUser.name,
          initials: activeUser.initials,
          time: 'Just now',
          self: true,
          text,
          attachments,
        };
        return { ...c, replies: [...c.replies, newReply] };
      })
    );
    showToast('Reply published to working paper review thread');
  }, [activeUser, showToast]);

  const addReviewNote = useCallback((docId: string, docName: string, comment: string, attachments: any[] = []) => {
    const newNote: ReviewComment = {
      id: Date.now(),
      docId,
      doc: docName,
      author: activeUser.name,
      role: activeUser.roleTitle,
      comment,
      status: 'open',
      time: 'Just now',
      initials: activeUser.initials,
      attachments,
      replies: [],
    };
    setReviewComments((prev) => [newNote, ...prev]);
    showToast(`Review note logged for ${docName}`);
  }, [activeUser, showToast]);

  const resolveReviewComment = useCallback((commentId: number | string) => {
    setReviewComments((prev) =>
      prev.map((c) => (String(c.id) === String(commentId) ? { ...c, status: 'resolved' } : c))
    );
    showToast('Review comment marked as resolved and signed off');
  }, [showToast]);

  // Visual Logic Studio
  const updateNodeParam = useCallback((nodeId: string, paramKey: string, newValue: any) => {
    setLogicNodes((prev) =>
      prev.map((n) => {
        if (n.id !== nodeId) return n;
        return {
          ...n,
          parameters: n.parameters.map((p) => (p.key === paramKey ? { ...p, value: newValue } : p)),
        };
      })
    );
    showToast('Methodology logic parameter calibrated');
  }, [showToast]);

  const runLogicSimulation = useCallback(() => {
    setIsSimulatingLogic(true);
    showToast('Executing visual logic engine simulation...');
    setTimeout(() => {
      setIsSimulatingLogic(false);
      setSimulationResults({
        executionTimeMs: 142,
        evaluatedEntities: entities.length,
        sampleSizeOutput: 75,
        confidencePct: 95,
        escalationFired: true,
        summary: 'Underwriting sample calibrated to 75 files with automatic dual sign-off enforced.',
      });
      showToast('Simulation complete: All rule gates verified nominal.');
    }, 1200);
  }, [entities.length, showToast]);

  // Time Warp
  const triggerTimeWarp = useCallback((year: number) => {
    setIsWarping(true);
    setTimeWarpYear(year);
    showToast(`Engaging Hyperloop Time Warp to ${year}...`);
    setTimeout(() => {
      setIsWarping(false);
      showToast(`Arrived at ${year} timeline.`);
    }, 900);
  }, [showToast]);

  // Modal closer
  const closeActiveModal = useCallback(() => {
    if (shortcutsModalOpen) {
      setShortcutsModalOpen(false);
      return true;
    }
    if (supabaseModalOpen) {
      setSupabaseModalOpen(false);
      return true;
    }
    if (reviewDrawerOpen) {
      setReviewDrawerOpen(false);
      return true;
    }
    if (commandPaletteOpen) {
      setCommandPaletteOpen(false);
      return true;
    }
    if (peopleModalOpen) {
      setPeopleModalOpen(false);
      return true;
    }
    if (selectedAuditForModal) {
      setSelectedAuditForModal(null);
      return true;
    }
    if (selectedObservation) {
      setSelectedObservation(null);
      return true;
    }
    if (selectedNodeForEdit) {
      setSelectedNodeForEdit(null);
      return true;
    }
    return false;
  }, [
    shortcutsModalOpen,
    supabaseModalOpen,
    reviewDrawerOpen,
    commandPaletteOpen,
    peopleModalOpen,
    selectedAuditForModal,
    selectedObservation,
    selectedNodeForEdit,
  ]);

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        navigateBack,
        navigateForward,
        tabHistory,
        historyIndex,

        people,
        roles,
        activeUserId,
        activeUser,
        setActiveUserId,
        updatePersonRole,
        updatePersonPermissions,
        addPerson,
        peopleModalOpen,
        setPeopleModalOpen,

        universes,
        activeUniverseId,
        setActiveUniverseId,
        addUniverse,
        entities,
        addEntity,
        removeEntity,
        updateEntity,
        regenerateUniverseTimeline,
        scopedEntityForAudit,
        setScopedEntityForAudit,
        openAuditFileForEntity,

        audits,
        updateAudit,
        toggleAuditStep,
        addAudit,
        selectedAuditForModal,
        setSelectedAuditForModal,
        issueAuditReport,

        departments,
        selectedObservation,
        setSelectedObservation,
        updateObservation,
        markCAPClosure,
        addReviewComment,

        reviewComments,
        reviewDrawerOpen,
        setReviewDrawerOpen,
        addReplyToComment,
        addReviewNote,
        resolveReviewComment,

        logicNodes,
        updateNodeParam,
        selectedNodeForEdit,
        setSelectedNodeForEdit,
        isSimulatingLogic,
        runLogicSimulation,
        simulationResults,

        timeWarpYear,
        isWarping,
        triggerTimeWarp,

        commandPaletteOpen,
        setCommandPaletteOpen,
        shortcutsModalOpen,
        setShortcutsModalOpen,
        supabaseModalOpen,
        setSupabaseModalOpen,
        closeActiveModal,

        toastMessage,
        showToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}
