/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { AppProvider, useApp, TabId } from './context/AppContext';
import { HeaderBar } from './components/common/HeaderBar';
import { NavStrip } from './components/common/NavStrip';
import { ExecutiveDashboardTab } from './components/dashboard/ExecutiveDashboardTab';
import { PendingTasksTab } from './components/tasks/PendingTasksTab';
import { AuditCalendarTab } from './components/calendar/AuditCalendarTab';
import { AuditUniverseTab } from './components/universe/AuditUniverseTab';
import { VisualLogicStudioTab } from './components/logic/VisualLogicStudioTab';
import { IssuesRegisterTab } from './components/issues/IssuesRegisterTab';
import { AuditPlanTab } from './components/plan/AuditPlanTab';
import { PeopleAccessModal } from './components/people/PeopleAccessModal';
import { AuditFileModal } from './components/audit/AuditFileModal';
import { ReviewCommentsDrawer } from './components/reviews/ReviewCommentsDrawer';
import { SupabaseModal } from './components/supabase/SupabaseModal';
import { KeyboardShortcutsModal } from './components/common/KeyboardShortcutsModal';
import { CommandPalette } from './components/common/CommandPalette';

function AppContent() {
  const { t } = useTheme();
  const {
    activeTab,
    setActiveTab,
    navigateBack,
    navigateForward,
    setShortcutsModalOpen,
    setCommandPaletteOpen,
    selectedAuditForModal,
    setSelectedAuditForModal,
    selectedObservation,
    setSelectedObservation,
    peopleModalOpen,
    setPeopleModalOpen,
    reviewDrawerOpen,
    setReviewDrawerOpen,
    supabaseModalOpen,
    setSupabaseModalOpen,
    shortcutsModalOpen,
    commandPaletteOpen,
    selectedNodeForEdit,
    setSelectedNodeForEdit,
    toastMessage,
  } = useApp();

  // Keyboard navigation: Backspace, Esc, Arrow keys, Cmd/Ctrl+K, ?
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      // If user is typing in an input or textarea, don't hijack keys
      const tag = (e.target as HTMLElement)?.tagName?.toLowerCase();
      const isInput = tag === 'input' || tag === 'textarea' || tag === 'select';

      // Cmd/Ctrl + K command palette
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setCommandPaletteOpen(!commandPaletteOpen);
        return;
      }

      // Escape key closes modals/drawers
      if (e.key === 'Escape') {
        if (commandPaletteOpen) {
          setCommandPaletteOpen(false);
          return;
        }
        if (reviewDrawerOpen) {
          setReviewDrawerOpen(false);
          return;
        }
        if (supabaseModalOpen) {
          setSupabaseModalOpen(false);
          return;
        }
        if (shortcutsModalOpen) {
          setShortcutsModalOpen(false);
          return;
        }
        if (peopleModalOpen) {
          setPeopleModalOpen(false);
          return;
        }
        if (selectedAuditForModal) {
          setSelectedAuditForModal(null);
          return;
        }
        if (selectedObservation) {
          setSelectedObservation(null);
          return;
        }
        if (selectedNodeForEdit) {
          setSelectedNodeForEdit(null);
          return;
        }
      }

      if (isInput) return;

      // Question mark for shortcuts
      if (e.key === '?') {
        e.preventDefault();
        setShortcutsModalOpen(!shortcutsModalOpen);
        return;
      }

      // Backspace goes back in history (or closes modal)
      if (e.key === 'Backspace') {
        if (selectedAuditForModal || selectedObservation || peopleModalOpen || selectedNodeForEdit || reviewDrawerOpen || supabaseModalOpen) {
          e.preventDefault();
          setSelectedAuditForModal(null);
          setSelectedObservation(null);
          setPeopleModalOpen(false);
          setSelectedNodeForEdit(null);
          setReviewDrawerOpen(false);
          setSupabaseModalOpen(false);
          return;
        }
        e.preventDefault();
        navigateBack();
        return;
      }

      // Tab navigation via Arrow Left / Arrow Right
      if (e.key === 'ArrowLeft' && !e.metaKey && !e.ctrlKey) {
        const tabList: TabId[] = ['dashboard', 'calendar', 'universe', 'logic', 'issues', 'plan'];
        const curIdx = tabList.indexOf(activeTab);
        if (curIdx > 0) {
          e.preventDefault();
          setActiveTab(tabList[curIdx - 1]);
        }
      } else if (e.key === 'ArrowRight' && !e.metaKey && !e.ctrlKey) {
        const tabList: TabId[] = ['dashboard', 'calendar', 'universe', 'logic', 'issues', 'plan'];
        const curIdx = tabList.indexOf(activeTab);
        if (curIdx < tabList.length - 1) {
          e.preventDefault();
          setActiveTab(tabList[curIdx + 1]);
        }
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [
    activeTab,
    setActiveTab,
    navigateBack,
    commandPaletteOpen,
    setCommandPaletteOpen,
    reviewDrawerOpen,
    setReviewDrawerOpen,
    supabaseModalOpen,
    setSupabaseModalOpen,
    shortcutsModalOpen,
    setShortcutsModalOpen,
    peopleModalOpen,
    setPeopleModalOpen,
    selectedAuditForModal,
    setSelectedAuditForModal,
    selectedObservation,
    setSelectedObservation,
    selectedNodeForEdit,
    setSelectedNodeForEdit,
  ]);

  return (
    <div
      style={{
        minHeight: '100vh',
        background: t.bg,
        color: t.textPrimary,
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      <HeaderBar />
      <NavStrip />

      <main style={{ flex: 1 }}>
        {activeTab === 'dashboard' && <ExecutiveDashboardTab />}
        {activeTab === 'tasks' && <PendingTasksTab />}
        {activeTab === 'calendar' && <AuditCalendarTab />}
        {activeTab === 'universe' && <AuditUniverseTab />}
        {activeTab === 'logic' && <VisualLogicStudioTab />}
        {activeTab === 'issues' && <IssuesRegisterTab />}
        {activeTab === 'plan' && <AuditPlanTab />}
      </main>

      {/* Global Modals & Floating Overlays */}
      <PeopleAccessModal />
      <AuditFileModal />
      <ReviewCommentsDrawer />
      <SupabaseModal />
      <KeyboardShortcutsModal />
      <CommandPalette />

      {/* Toast Notification Notification Pill */}
      {toastMessage && (
        <div
          style={{
            position: 'fixed',
            bottom: 24,
            right: 28,
            zIndex: 150,
            background: t.card,
            color: t.textPrimary,
            border: `1.5px solid ${t.verdigris}`,
            borderRadius: 12,
            padding: '10px 18px',
            fontSize: 12.5,
            fontWeight: 600,
            boxShadow: '0 16px 36px rgba(0,0,0,0.3)',
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            animation: 'riseIn 0.2s ease',
          }}
        >
          <div
            style={{
              width: 18,
              height: 18,
              borderRadius: '50%',
              background: t.verdigris,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#FFFFFF',
              fontSize: 10,
            }}
          >
            ✓
          </div>
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppProvider>
        <AppContent />
      </AppProvider>
    </ThemeProvider>
  );
}
