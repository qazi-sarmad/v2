export type AuditStatus =
  | 'in_progress'
  | 'overdue'
  | 'upcoming'
  | 'concluded_this_year'
  | 'concluded_prior';

export type AuditStage =
  | 'planning'
  | 'scoping'
  | 'fieldwork'
  | 'review'
  | 'reporting'
  | 'mgmt_comments'
  | 'signoff';

export type StepStatus = 'not_started' | 'in_progress' | 'reviewed';

export interface AuditSteps {
  planning?: StepStatus;
  fieldwork: StepStatus;
  review: StepStatus;
  signoff: StepStatus;
}

export type SamplingMethod =
  | 'Random'
  | 'Systematic'
  | 'Stratified'
  | 'MUS'
  | 'High Value'
  | 'Low Value'
  | 'Haphazard';

export type SamplingEntryMode = 'Algorithmic' | 'Manual';

export interface SampleItem {
  id: string;
  refNo: string;
  date: string;
  counterparty: string;
  amount: number;
  attributesTested: { name: string; passed: boolean }[];
  status: 'pass' | 'exception';
  tickAndTie: string;
  notes?: string;
}

export interface PopulationGate {
  status: 'VERIFIED' | 'UNVERIFIED';
  filename: string;
  totalRecords: number;
  totalAmount: number;
  verifiedAt?: string;
  hashSha256?: string;
}

export interface ControlEvaluation {
  status: 'completed' | 'in_progress' | 'not_started';
  effective: number;
  ineffective: number;
  notes?: string;
}

export interface AuditControlItem {
  id: string;
  code: string;
  name: string;
  objective: string;
  type: 'Preventive' | 'Detective' | 'Corrective';
  frequency: 'Automated Real-time' | 'Daily' | 'Weekly' | 'Monthly' | 'Quarterly' | 'Annual';
  owner: string;
  assignedAuditor?: string;
  deaStatus: 'Effective' | 'Ineffective' | 'Pending Walkthrough';
  deaNotes?: string;
  deaWalkthroughSteps?: { step: number; description: string; result: 'Pass' | 'Fail' | 'Pending' }[];
  oetStatus: 'Effective' | 'Ineffective' | 'Testing In Progress' | 'Not Started';
  sampleSize: number;
  sampleExceptions: number;
  oetNotes?: string;
  populationGate?: PopulationGate;
  samplingMethod?: SamplingMethod;
  samplingEntryMode?: SamplingEntryMode;
  sampleItems?: SampleItem[];
}

export interface AuditWorkpaper {
  id: string;
  ref: string;
  name: string;
  lead: string;
  controlId?: string;
  type?: 'DEA' | 'OET' | 'Scoping' | 'Exceptions' | 'General';
  status: 'Draft' | 'In Review' | 'Reviewed' | 'Signed off';
  testedSampleCount: number;
  exceptionsCount: number;
  signoffLead?: string;
  signoffDate?: string;
  notes?: string;
  attachments?: { name: string; size: string }[];
  sampleItems?: SampleItem[];
  populationGate?: PopulationGate;
}

export interface SiraAssessment {
  financial: number;    // 1 - 5 (Materiality / Balance Sheet)
  regulatory: number;   // 1 - 5 (CFPB, OCC, Fed Scrutiny)
  operational: number;  // 1 - 5 (IT complexity, process manualness)
  reputational: number; // 1 - 5 (Brand & consumer exposure)
  historical?: number;  // 1 - 5 (Prior findings & control failures)
  composite: number;    // weighted 1 - 100
  rationale?: string;
  lastAssessedDate?: string;
  assessedBy?: string;
}

export interface AuditEngagement {
  id: string | number;
  title: string;
  dept: string;
  entityId: string;
  universeId?: string;
  start: string; // ISO YYYY-MM-DD
  end: string;   // ISO YYYY-MM-DD
  status: AuditStatus;
  stage: AuditStage;
  leadAuditorId: string;
  leadAuditorName: string;
  reviewerId?: string;
  reviewerName?: string;
  assignedTeam?: string[];
  steps: AuditSteps;
  scopeSummary: string;
  sampleSize: number;
  exceptionsCount: number;
  rating?: 'Satisfactory' | 'Needs Improvement' | 'Unsatisfactory';
  
  // DEA & OET Controls Testing
  controlsTotal: number;
  controlsTested: number;
  dea: ControlEvaluation;
  oet: ControlEvaluation;
  controlsList?: AuditControlItem[];
  workpapersList?: AuditWorkpaper[];

  // Report Issuance & Governance Lifecycle
  reportIssued: boolean;
  reportIssuedDate?: string | null;
  reportAuthor?: string;
  reportSignoffCae?: string;
  reportSummary?: string;
  executiveOpinion?: 'Satisfactory' | 'Needs Improvement' | 'Unsatisfactory';

  // SIRA
  siraScore?: SiraAssessment;
  workpapers?: { id: string; name: string; status: 'Signed off' | 'In Review' | 'Draft'; lead: string }[];
}

export type Severity = 'critical' | 'high' | 'medium' | 'low';
export type ApprovalStatus =
  | 'Pending review'
  | 'Approved by CIA'
  | 'Approved'
  | 'Under Investigation'
  | 'Sign-off Granted';

export interface ObservationComment {
  id: string;
  author: string;
  timestamp: string;
  text: string;
}

export interface Observation {
  id: string;
  title: string;
  dept: string;
  department?: string;
  owner?: string;
  severity: Severity;
  approval: ApprovalStatus;
  report: string;
  reportId?: string | number;
  closureDate: string | null;
  overdue: boolean;
  dueDate: string;
  rectificationText?: string;
  attachments?: { name: string; size: string }[];
  comments?: ObservationComment[];
  
  // Formal report issuance linkage
  reportIssued: boolean; // True only when parent audit report has been formally finalized & issued!
  isDraft?: boolean;
  rootCause?: string;
  impact?: string;
  capActionPlan?: string;
  capOwner?: string;
}

export interface DepartmentSummary {
  id: string;
  name?: string;
  label: string;
  hue: string;
  hueDark: string;
  observations: Observation[];
}

export type InherentRisk = 'critical' | 'high' | 'medium' | 'low';

export interface AuditUniverse {
  id: string;
  name: string;
  description: string;
  entitiesCount: number;
  highRiskCount: number;
  leadSponsor: string;
  coveragePct: number;
}

export interface AuditEntity {
  id: string;
  universeId: string;
  name: string;
  businessUnit: string;
  inherentRisk: InherentRisk;
  regulatoryTier: string;
  frequencyMonths: 12 | 18 | 24 | 36;
  lastAuditedDate: string;
  nextAuditTarget: string;
  leadOwner: string;
  status: 'covered' | 'scheduled' | 'overdue' | 'unplanned';
  scopeNotes: string;
  siraScore?: SiraAssessment;
  rcmControls?: AuditControlItem[];
}

export interface Role {
  id: string;
  title: string;
  description: string;
  level: number;
  badgeTone: 'verdigris' | 'cinnabar' | 'neutral' | 'blue';
  defaultPermissions: {
    canSignOff: boolean;
    canCloseCAP: boolean;
    canEditMethodology: boolean;
    canCreateAudits: boolean;
    canApproveSample: boolean;
  };
}

export interface Person {
  id: string;
  name: string;
  email: string;
  initials: string;
  roleId: string;
  roleTitle: string;
  department: string;
  avatarBg?: string;
  activeAuditsCount: number;
  level: number; // 1 = CAE, 2 = Audit Lead, 3 = Senior Auditor, 4 = Staff, 5 = Auditee
  permissions: {
    canSignOff: boolean;
    canCloseCAP: boolean;
    canEditMethodology: boolean;
    canCreateAudits: boolean;
    canApproveSample: boolean;
  };
}

export interface LogicNode {
  id: string;
  title: string;
  category: 'trigger' | 'sampling' | 'gate' | 'escalation' | 'signoff';
  description: string;
  parameters: {
    label: string;
    key: string;
    type: 'number' | 'select' | 'toggle' | 'text';
    value: any;
    options?: { label: string; value: any }[];
    unit?: string;
  }[];
  x: number;
  y: number;
  connectedTo: string[];
}

export interface ReviewComment {
  id: number | string;
  docId: string;
  doc: string;
  author: string;
  role: string;
  comment: string;
  status: 'open' | 'resolved';
  time: string;
  initials: string;
  attachments: { name: string; size: string }[];
  replies: {
    id: number | string;
    author: string;
    initials: string;
    time: string;
    self: boolean;
    text: string;
    attachments: { name: string; size: string }[];
  }[];
}
